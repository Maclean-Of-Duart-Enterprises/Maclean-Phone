# Maclean Phone

Maclean Phone is an AGPLv3 Android dialer and CRM from Maclean of Duart Enterprises.

Version 1.4.8 adds a persistent Android folder chooser for manual live-call recordings. Completed AAC/M4A recordings are written directly to the selected folder, verified before success is displayed, and can be opened from the in-call screen. The existing public Music folder remains the default. The application ID remains `com.macleanofduartenterprises.phone`.

See `Maclean-Phone-1.4.8-Release-Notes.md` and the verification reports included with the release for details and device-test boundaries.
