# Maclean Phone 1.4.9

Added Settings > Call screen behavior > External-origin call screen handling (off by default).

When enabled, the default call orchestrator does not explicitly launch the Maclean Phone activity for newly connecting/dialing cellular calls. Call tracking and outgoing call notifications are retained. Incoming call handling is unchanged. No Google Voice package detection or unsupported caller-ID manipulation is attempted.

Limitations: Android Telecom and Google Voice independently control their respective UIs. This setting cannot guarantee that Google Voice displays its in-call UI. Users can still access Maclean Phone through system call UI/notifications. Test on device before enabling permanently.

Build and device tests have not been performed.
