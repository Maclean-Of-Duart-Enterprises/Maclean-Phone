# Maclean Phone 1.4.8 Release Notes

Maclean Phone 1.4.8 is a corrective release for the manual live-call recording feature. It preserves the application ID, signing identity, data stores, calling behavior, Contacts/CRM, SIP/VoIP, Google Voice compatibility, audio routing, accessibility, appearance, navigation, and AGPLv3 license from 1.4.7.

## Call-recording storage correction

- Added **Settings → Call recordings** with Android's system folder chooser.
- A selected folder receives persistent read/write permission, so the choice survives app and device restarts and does not require broad storage permission.
- Manual call recordings are AAC audio in readable `.m4a` files and are created directly in the selected folder.
- The existing `Music/Maclean Phone/Call Recordings` location remains the default when no custom folder is selected.
- File names now include milliseconds to prevent two recordings made within one second from colliding.
- The in-call consent dialog identifies the active destination before recording starts.
- After a manual stop, the in-call screen shows the exact folder and filename and provides **Open recording**.
- A recording is not reported as saved until the recorder stops, the file descriptor closes, MediaStore publication completes when applicable, and the completed file can be reopened.
- Revoked or invalid folder access produces an actionable error directing the user back to the folder setting instead of claiming success.
- Android 8–9 fallback recordings are exposed through the app's secure `content://` FileProvider URI rather than a raw file URI.

## Version and upgrade identity

- Application ID: `com.macleanofduartenterprises.phone`
- Version name: `1.4.8`
- Version code: `19` (1.4.7 used `18`)
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`

The unchanged package and certificate plus the higher version code make this APK eligible to install over the supplied 1.4.7 release without clearing app data.

## Important recording limitation

Android, handset firmware, or carrier policy can prevent third-party apps from capturing the remote side of a cellular call. Maclean Phone continues to try the microphone first and offers **Use speaker & record both voices** so the microphone can hear both sides acoustically. This release corrects file destination, publication, visibility, and access; it cannot bypass operating-system call-audio restrictions. Record only with the consent required by applicable law.
