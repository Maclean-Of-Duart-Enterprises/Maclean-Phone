package com.macleanofduartenterprises.phone.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.edit

object CallRecordingPreferences {
    private const val PREFERENCES_NAME = "call_recording_storage"
    private const val KEY_TREE_URI = "recording_tree_uri"
    private const val KEY_FOLDER_NAME = "recording_folder_name"

    const val DEFAULT_FOLDER_LABEL = "Music/Maclean Phone/Call Recordings"

    data class Destination(
        val treeUri: String = "",
        val folderName: String = "",
    ) {
        val isCustom: Boolean
            get() = treeUri.isNotBlank()

        val displayLabel: String
            get() = if (isCustom) {
                folderName.ifBlank { "Selected Android folder" }
            } else {
                DEFAULT_FOLDER_LABEL
            }
    }

    fun load(context: Context): Destination {
        val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
        return Destination(
            treeUri = preferences.getString(KEY_TREE_URI, "").orEmpty(),
            folderName = preferences.getString(KEY_FOLDER_NAME, "").orEmpty(),
        )
    }

    fun save(context: Context, treeUri: Uri, folderName: String) {
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE).edit {
            putString(KEY_TREE_URI, treeUri.toString())
            putString(KEY_FOLDER_NAME, folderName.trim())
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE).edit {
            remove(KEY_TREE_URI)
            remove(KEY_FOLDER_NAME)
        }
    }

    fun hasPersistedWriteAccess(context: Context, treeUri: Uri): Boolean =
        context.contentResolver.persistedUriPermissions.any { permission ->
            permission.uri == treeUri && permission.isWritePermission
        }

    fun resolveFolderName(context: Context, treeUri: Uri): String {
        val queriedName = runCatching {
            context.contentResolver.query(
                treeUri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                } else {
                    null
                }
            }
        }.getOrNull()

        return queriedName
            ?.takeIf(String::isNotBlank)
            ?: Uri.decode(treeUri.lastPathSegment.orEmpty())
                .substringAfterLast(':')
                .ifBlank { "Selected Android folder" }
    }
}

object CallRecordingFileNames {
    fun forTimestamp(timestampMillis: Long): String =
        "Maclean_Phone_Call_${
            java.text.SimpleDateFormat("yyyyMMdd_HHmmss_SSS", java.util.Locale.US)
                .format(java.util.Date(timestampMillis))
        }.m4a"
}
