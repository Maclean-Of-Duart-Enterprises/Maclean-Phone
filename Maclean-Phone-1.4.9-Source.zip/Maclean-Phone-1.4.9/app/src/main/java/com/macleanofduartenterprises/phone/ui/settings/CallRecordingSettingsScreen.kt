package com.macleanofduartenterprises.phone.ui.settings

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.core.CallRecordingPreferences
import com.macleanofduartenterprises.phone.ui.components.Text

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallRecordingSettingsScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    var destination by remember(context) {
        mutableStateOf(CallRecordingPreferences.load(context))
    }
    var message by remember { mutableStateOf<String?>(null) }

    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { selectedUri ->
        if (selectedUri == null) return@rememberLauncherForActivityResult
        val permissionFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching {
            context.contentResolver.takePersistableUriPermission(selectedUri, permissionFlags)
            check(CallRecordingPreferences.hasPersistedWriteAccess(context, selectedUri)) {
                "Android did not grant lasting write access to this folder."
            }
            val folderName = CallRecordingPreferences.resolveFolderName(context, selectedUri)
            CallRecordingPreferences.save(context, selectedUri, folderName)
            destination = CallRecordingPreferences.load(context)
        }.onSuccess {
            message = "Call recordings will be saved in ${destination.displayLabel}."
        }.onFailure { error ->
            message = error.message
                ?: "Maclean Phone could not retain access to the selected folder."
        }
    }

    fun openSelectedFolder() {
        val treeUri = destination.treeUri.takeIf(String::isNotBlank)?.let(Uri::parse) ?: return
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(treeUri, DocumentsContract.Document.MIME_TYPE_DIR)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
            )
        }.onFailure {
            message = "No installed file manager can open this folder directly. The folder remains selected for recording."
        }
    }

    fun useDefaultFolder() {
        destination.treeUri.takeIf(String::isNotBlank)?.let(Uri::parse)?.let { oldUri ->
            runCatching {
                context.contentResolver.releasePersistableUriPermission(
                    oldUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
        }
        CallRecordingPreferences.clear(context)
        destination = CallRecordingPreferences.load(context)
        message = "The default public Music folder will be used."
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Call recordings") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Recording folder", style = MaterialTheme.typography.titleMedium)
                    Text(destination.displayLabel, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        if (destination.isCustom) {
                            "Maclean Phone has lasting Android permission to create M4A call recordings in this folder."
                        } else {
                            "Default: Files → Music → Maclean Phone → Call Recordings. Choose a folder if you want a different location."
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val initialUri = destination.treeUri
                        .takeIf(String::isNotBlank)
                        ?.let(Uri::parse)
                    folderLauncher.launch(initialUri)
                },
            ) {
                Icon(Icons.Outlined.Folder, contentDescription = null)
                Text(if (destination.isCustom) "Change recording folder" else "Choose recording folder")
            }

            if (destination.isCustom) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = ::openSelectedFolder,
                    ) {
                        Icon(Icons.Outlined.FolderOpen, contentDescription = null)
                        Text("Open folder")
                    }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = ::useDefaultFolder,
                    ) {
                        Icon(Icons.Outlined.Restore, contentDescription = null)
                        Text("Use default")
                    }
                }
            }

            Text(
                "Recordings use AAC audio in a readable .m4a file. A recording is shown as saved only after Android publishes it and Maclean Phone can reopen the completed file.",
            )
            Text(
                "Recording remains manual and requires the consent required by law. Android, the phone manufacturer, or a carrier may restrict capture of the remote caller; Speaker mode can allow the microphone to hear both sides.",
                style = MaterialTheme.typography.bodySmall,
            )
            message?.let { Text(it) }
        }
    }
}
