package com.macleanofduartenterprises.phone.core

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface CallRecordingState {
    data object Idle : CallRecordingState
    data class Recording(
        val displayName: String,
        val startedAtMillis: Long,
        val captureDescription: String,
    ) : CallRecordingState
    data class Saved(
        val displayName: String,
        val uri: String,
        val storageDescription: String,
        val captureDescription: String,
    ) : CallRecordingState
    data class Error(val message: String) : CallRecordingState
}

data class CallRecordingAudioCandidate(
    val audioSource: Int,
    val description: String,
)

object CallRecordingAudioPolicy {
    /**
     * MIC is intentionally first: VOICE_COMMUNICATION produced silent files on
     * some Android dialers. With Speaker selected, MIC captures both voices
     * acoustically. Android may still block concurrent cellular-call capture.
     */
    fun candidates(): List<CallRecordingAudioCandidate> = listOf(
        CallRecordingAudioCandidate(
            MediaRecorder.AudioSource.MIC,
            "Microphone (select Speaker to capture both voices)",
        ),
        CallRecordingAudioCandidate(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            "Microphone compatibility mode",
        ),
        CallRecordingAudioCandidate(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            "Android communication audio source",
        ),
    )
}

private data class RecordingOutput(
    val displayName: String,
    val uri: Uri,
    val descriptor: ParcelFileDescriptor?,
    val filePath: String?,
    val storageDescription: String,
    val requiresMediaStorePublish: Boolean,
)

class CallRecordingController(
    private val context: Context,
) {
    private val _state = MutableStateFlow<CallRecordingState>(CallRecordingState.Idle)
    val state: StateFlow<CallRecordingState> = _state.asStateFlow()

    private var recorder: MediaRecorder? = null
    private var output: RecordingOutput? = null
    private var captureDescription: String? = null

    /**
     * Starts recording only after the user has pressed the in-call recording
     * control and confirmed consent. Call-state changes never invoke this path.
     */
    @Synchronized
    fun startFromManualControl() {
        if (recorder != null) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            _state.value = CallRecordingState.Error(
                "Microphone permission is required before recording can start."
            )
            return
        }

        var lastError: Throwable? = null
        for (candidate in CallRecordingAudioPolicy.candidates()) {
            val newOutput = try {
                createOutput()
            } catch (error: Exception) {
                _state.value = CallRecordingState.Error(
                    error.message ?: "A recording file could not be created."
                )
                return
            }
            val newRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            val result = runCatching {
                newRecorder.setAudioSource(candidate.audioSource)
                newRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                newRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                newRecorder.setAudioChannels(1)
                newRecorder.setAudioEncodingBitRate(192_000)
                newRecorder.setAudioSamplingRate(44_100)
                if (newOutput.descriptor != null) {
                    newRecorder.setOutputFile(newOutput.descriptor.fileDescriptor)
                } else {
                    newRecorder.setOutputFile(requireNotNull(newOutput.filePath))
                }
                newRecorder.prepare()
                newRecorder.start()
            }
            if (result.isSuccess) {
                recorder = newRecorder
                output = newOutput
                captureDescription = candidate.description
                _state.value = CallRecordingState.Recording(
                    displayName = newOutput.displayName,
                    startedAtMillis = System.currentTimeMillis(),
                    captureDescription = candidate.description,
                )
                return
            }
            lastError = result.exceptionOrNull()
            runCatching { newRecorder.release() }
            discard(newOutput)
        }
        _state.value = CallRecordingState.Error(
            lastError?.message ?: "This device or call type does not allow audio recording."
        )
    }

    fun stopFromManualControl() = stopAndSave()

    fun stopForCallEnd() = stopAndSave()

    @Synchronized
    private fun stopAndSave() {
        val currentRecorder = recorder ?: return
        val currentOutput = output
        val currentCaptureDescription = captureDescription
        recorder = null
        output = null
        captureDescription = null
        val stopSucceeded = runCatching { currentRecorder.stop() }.isSuccess
        runCatching { currentRecorder.release() }
        val closeError = runCatching { currentOutput?.descriptor?.close() }.exceptionOrNull()

        if (currentOutput == null) {
            _state.value = CallRecordingState.Idle
        } else if (stopSucceeded && closeError == null) {
            runCatching {
                publishAndVerify(currentOutput)
            }.fold(
                onSuccess = {
                    _state.value = CallRecordingState.Saved(
                        displayName = currentOutput.displayName,
                        uri = currentOutput.uri.toString(),
                        storageDescription = currentOutput.storageDescription,
                        captureDescription = currentCaptureDescription
                            ?: "Microphone compatibility mode",
                    )
                },
                onFailure = { error ->
                    if (currentOutput.requiresMediaStorePublish) {
                        discard(currentOutput.copy(descriptor = null))
                    }
                    _state.value = CallRecordingState.Error(
                        error.message
                            ?: "The call ended, but Android could not publish the recording.",
                    )
                },
            )
        } else {
            discard(currentOutput.copy(descriptor = null))
            _state.value = CallRecordingState.Error(
                closeError?.message
                    ?: "The recording was too short or audio capture is blocked on this device."
            )
        }
    }

    fun clearMessage() {
        if (_state.value !is CallRecordingState.Recording) {
            _state.value = CallRecordingState.Idle
        }
    }

    private fun createOutput(): RecordingOutput {
        val displayName = CallRecordingFileNames.forTimestamp(System.currentTimeMillis())
        val destination = CallRecordingPreferences.load(context)
        if (destination.isCustom) {
            return createCustomFolderOutput(displayName, destination)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(
                    MediaStore.Audio.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MUSIC}/Maclean Phone/Call Recordings",
                )
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = requireNotNull(
                context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ) { "Android could not create the recording in Music." }
            val descriptor = requireNotNull(
                context.contentResolver.openFileDescriptor(uri, "w")
            ) { "Android could not open the recording file." }
            return RecordingOutput(
                displayName = displayName,
                uri = uri,
                descriptor = descriptor,
                filePath = null,
                storageDescription = CallRecordingPreferences.DEFAULT_FOLDER_LABEL,
                requiresMediaStorePublish = true,
            )
        }

        val directory = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MUSIC),
            "Maclean Phone/Call Recordings",
        ).apply { mkdirs() }
        val file = File(directory, displayName)
        return RecordingOutput(
            displayName = displayName,
            uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file,
            ),
            descriptor = null,
            filePath = file.absolutePath,
            storageDescription = CallRecordingPreferences.DEFAULT_FOLDER_LABEL,
            requiresMediaStorePublish = false,
        )
    }

    private fun createCustomFolderOutput(
        displayName: String,
        destination: CallRecordingPreferences.Destination,
    ): RecordingOutput {
        val treeUri = runCatching { destination.treeUri.toUri() }
            .getOrElse { throw IllegalStateException("The selected recording folder is invalid.") }
        check(CallRecordingPreferences.hasPersistedWriteAccess(context, treeUri)) {
            "The selected recording folder is no longer writable. Open Settings → Call recordings and choose the folder again."
        }
        val parentDocumentUri = runCatching {
            DocumentsContract.buildDocumentUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri),
            )
        }.getOrElse {
            throw IllegalStateException(
                "Android could not open the selected recording folder. Choose it again in Settings → Call recordings.",
            )
        }
        val uri = requireNotNull(
            DocumentsContract.createDocument(
                context.contentResolver,
                parentDocumentUri,
                "audio/mp4",
                displayName,
            )
        ) { "Android could not create a recording in ${destination.displayLabel}." }
        val descriptor = context.contentResolver.openFileDescriptor(uri, "rw")
        if (descriptor == null) {
            runCatching { DocumentsContract.deleteDocument(context.contentResolver, uri) }
            error("Android could not write to ${destination.displayLabel}.")
        }
        return RecordingOutput(
            displayName = displayName,
            uri = uri,
            descriptor = descriptor,
            filePath = null,
            storageDescription = destination.displayLabel,
            requiresMediaStorePublish = false,
        )
    }

    private fun publishAndVerify(recordingOutput: RecordingOutput) {
        if (recordingOutput.requiresMediaStorePublish) {
            val updated = context.contentResolver.update(
                recordingOutput.uri,
                ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) },
                null,
                null,
            )
            check(updated > 0) {
                "The call was recorded, but Android could not publish it to Music."
            }
        }

        if (recordingOutput.filePath != null) {
            val file = File(recordingOutput.filePath)
            check(file.isFile && file.length() > 0L) {
                "The recording file is empty or unavailable."
            }
            return
        }

        val size = requireNotNull(
            context.contentResolver.openFileDescriptor(recordingOutput.uri, "r")
        ) { "Android saved the recording but could not reopen it." }.use { it.statSize }
        check(size != 0L) { "The recording file is empty." }
    }

    private fun discard(recordingOutput: RecordingOutput) {
        runCatching { recordingOutput.descriptor?.close() }
        if (recordingOutput.requiresMediaStorePublish) {
            runCatching { context.contentResolver.delete(recordingOutput.uri, null, null) }
        } else if (recordingOutput.filePath != null) {
            runCatching { File(recordingOutput.filePath).delete() }
        } else if (recordingOutput.uri.scheme == "content") {
            runCatching {
                DocumentsContract.deleteDocument(context.contentResolver, recordingOutput.uri)
            }
        }
    }
}
