package com.macleanofduartenterprises.phone.core

import android.content.Context
import android.net.Uri
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment

@RunWith(RobolectricTestRunner::class)
class CallRecordingPreferencesTest {
    private lateinit var context: Context

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        CallRecordingPreferences.clear(context)
    }

    @After
    fun tearDown() {
        CallRecordingPreferences.clear(context)
    }

    @Test
    fun defaultDestinationIsThePublicMusicFolder() {
        val destination = CallRecordingPreferences.load(context)

        assertFalse(destination.isCustom)
        assertEquals(
            "Music/Maclean Phone/Call Recordings",
            destination.displayLabel,
        )
    }

    @Test
    fun chosenFolderPersistsAndCanBeReset() {
        val folder = Uri.parse(
            "content://com.android.externalstorage.documents/tree/primary%3ACallRecordings",
        )

        CallRecordingPreferences.save(context, folder, "  My call recordings  ")

        val saved = CallRecordingPreferences.load(context)
        assertTrue(saved.isCustom)
        assertEquals(folder.toString(), saved.treeUri)
        assertEquals("My call recordings", saved.displayLabel)

        CallRecordingPreferences.clear(context)
        assertFalse(CallRecordingPreferences.load(context).isCustom)
    }

    @Test
    fun generatedNamesAreReadableM4aFilesAndDoNotCollideWithinASecond() {
        val first = CallRecordingFileNames.forTimestamp(1_000L)
        val second = CallRecordingFileNames.forTimestamp(1_001L)

        assertTrue(first.matches(Regex("Maclean_Phone_Call_\\d{8}_\\d{6}_\\d{3}\\.m4a")))
        assertTrue(second.endsWith(".m4a"))
        assertTrue(first != second)
    }
}
