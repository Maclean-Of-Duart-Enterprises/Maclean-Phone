# Maclean Phone 1.4.8 Build Verification Report

## Release identity

| Check | Result |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version | `1.4.8` |
| Version code | `19` |
| Minimum / target / compile SDK | 26 / 36 / 36 |
| Release artifact | `Maclean-Phone-1.4.8-universal.apk` |
| Architectures | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |

The supplied 1.4.7 APK reports the same application ID, version code 18, target/compile SDK 36, and the same four architectures.

## Build environment and commands

- Temurin JDK 21.0.12.1
- Gradle 9.4.0
- Android SDK Platform 36
- Android Build Tools 36.0.0
- Android Gradle Plugin 9.1.0
- Kotlin 2.3.10

The final signed release was produced with:

```text
gradle --no-daemon testDebugUnitTest lintRelease assembleRelease
```

## Automated results

| Verification | Result |
|---|---|
| Unit/Robolectric tests | 79 passed, 0 failed, 0 skipped |
| Recording-storage tests | 3 passed |
| Release lint | Passed; 0 errors, 73 warnings, 1 hint |
| APK zip alignment | Passed |
| APK signature verification | Passed using APK Signature Scheme v2 |
| Signers | 1 |

Lint warnings are non-blocking compatibility, deprecation, typography, and project-maintenance findings already tolerated by the existing application; no fatal or error-severity finding is present.

## Signing and upgrade compatibility

The supplied 1.4.7 APK and the 1.4.8 release both use:

- Subject: `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises`
- Certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`

Static upgrade requirements pass: identical application ID, identical certificate, and monotonically increased version code 18 → 19. No database schema or destructive migration was introduced.

## Environment boundary

No Android handset or emulator was connected to this build environment. Installation over a populated 1.4.7 instance, a real carrier call, provider-specific Storage Access Framework behavior, audio audibility, and post-reboot access therefore require the short physical-device acceptance workflow in the accompanying call-recording test report. These are not represented as device passes.
