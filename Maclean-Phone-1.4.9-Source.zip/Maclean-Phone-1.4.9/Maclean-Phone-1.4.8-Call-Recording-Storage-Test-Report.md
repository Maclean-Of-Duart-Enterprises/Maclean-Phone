# Maclean Phone 1.4.8 Call-Recording Storage Test Report

## Corrected workflow

1. Open **Settings → Call recordings**.
2. Choose any writable local or provider-backed folder with Android's folder picker.
3. Maclean Phone retains the returned read/write permission and displays the selected folder name.
4. During an active or held call, press **Start recording**, review the consent notice and visible destination, and choose the current route or Speaker-assisted recording.
5. On manual stop or call end, Maclean Phone stops the recorder and closes the destination.
6. For the default Music destination, the pending MediaStore item must publish successfully. For every destination, the finished file must reopen and must not be zero bytes before success is shown.
7. After a manual stop, **Open recording** launches an installed audio player through a secure `content://` URI.

## Automated coverage

| Test | Result |
|---|---|
| Default destination resolves to `Music/Maclean Phone/Call Recordings` | Pass |
| Selected tree URI and readable folder label persist | Pass |
| Reset restores the default destination | Pass |
| M4A filename format is readable and contains milliseconds | Pass |
| Two recordings within one second receive distinct names | Pass |
| Existing microphone-first/fallback source policy tests | Pass |
| Full project unit/Robolectric suite | 79/79 pass |

Source-path review also confirmed:

- The folder setting is reachable from the main Settings screen.
- Android's `OpenDocumentTree` contract is used rather than a hard-coded filesystem path.
- Persisted URI permission is required again when recording starts; revoked access cannot produce false success.
- Custom-folder files are created with MIME type `audio/mp4` and an `.m4a` extension.
- Default Android 10+ output uses MediaStore's public Music collection.
- Completed custom, MediaStore, and legacy FileProvider URIs can be passed to another app with temporary read permission.
- Recorder setup failures discard the incomplete output, and a failed finalization is reported instead of displayed as saved.

## Physical-device acceptance checklist

These steps require the target handset and a lawful test call:

- Install 1.4.8 directly over the signed 1.4.7 APK and confirm contacts, groups, preferences, calling accounts, and history remain present.
- Select a folder in internal storage, close Maclean Phone, reopen it, and confirm the folder remains selected.
- Restart the handset and confirm the same folder remains selected.
- Place a test call, record for at least ten seconds, stop manually, tap **Open recording**, and confirm the file plays.
- In a file manager, confirm the `.m4a` is present in the chosen folder and remains after Maclean Phone restarts.
- Repeat while ending the call without pressing Stop; confirm the file is finalized in the same folder.
- Test both the current audio route and Speaker-assisted capture, then verify the local and remote levels supported by that handset.
- Revoke the folder permission or remove the storage provider and confirm Maclean Phone reports the folder as unwritable instead of claiming that it saved a recording.
- Reset to the default and confirm a new recording appears under `Music/Maclean Phone/Call Recordings` on Android 10 or later.

Because no physical device was attached, the checklist is intentionally recorded as pending rather than passed.
