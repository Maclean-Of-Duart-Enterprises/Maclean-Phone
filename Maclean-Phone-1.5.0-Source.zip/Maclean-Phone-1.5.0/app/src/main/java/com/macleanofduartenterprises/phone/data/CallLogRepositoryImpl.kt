package com.macleanofduartenterprises.phone.data

import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.CallLog
import androidx.core.database.getStringOrNull
import androidx.core.net.toUri
import com.macleanofduartenterprises.phone.di.IODispatcher
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import com.macleanofduartenterprises.phone.domain.entity.CallLogData
import com.macleanofduartenterprises.phone.domain.entity.CallLogFilter
import com.macleanofduartenterprises.phone.domain.entity.CallLogType
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.repo.CallLogRepository
import com.macleanofduartenterprises.phone.domain.repo.ContactDetailProvider
import com.macleanofduartenterprises.phone.domain.repo.ContactPhotoProvider
import com.macleanofduartenterprises.phone.domain.repo.SimInfoProvider
import com.macleanofduartenterprises.phone.ui.extensions.getStringOrEmpty
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import java.util.Date
import javax.inject.Inject

/**
 * Created by Muhammad Usman : msusman97@gmail.com on 11/21/2023.
 */


class CallLogRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    @IODispatcher private val ioDispatcher: CoroutineDispatcher,
    private val simInfoProvider: SimInfoProvider,
    private val contactPhotoProvider: ContactPhotoProvider,
    private val contactDetailProvider: ContactDetailProvider
) : CallLogRepository {
    val contentResolver: ContentResolver = context.contentResolver

    @SuppressLint("MissingPermission")
    override suspend fun getCallLogsPaged(
        limit: Int,
        offset: Int,
        filter: CallLogFilter,
    ): List<CallLogData> = withContext(ioDispatcher) {
        val (selection, selectionArgs) = filter.toSelection(
            callerIdSpamEnabled = PhoneSettingsPrefs.callerIdSpamEnabled(context),
            supportsBlockReason = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q,
        )
        queryCallLogs(
            selection = selection,
            selectionArgs = selectionArgs,
            sortOrder = "${CallLog.Calls.DATE} DESC LIMIT $limit OFFSET $offset"
        )
    }

    @SuppressLint("MissingPermission")
    override suspend fun getCallLogsByPhone(phone: String): List<CallLogData> = withContext(ioDispatcher) {
        queryCallLogs(
            selection = "${CallLog.Calls.NUMBER} = ?",
            selectionArgs = arrayOf(phone),
            sortOrder = "${CallLog.Calls.DATE} DESC"
        )
    }

    @SuppressLint("MissingPermission")
    override suspend fun deleteCallLogsByPhone(phone: String): Int = withContext(ioDispatcher) {
        contentResolver.delete(
            CallLog.Calls.CONTENT_URI,
            "${CallLog.Calls.NUMBER} = ?",
            arrayOf(phone)
        )
    }

    @SuppressLint("MissingPermission")
    override suspend fun deleteAllCallLogs(): Int = withContext(ioDispatcher) {
        contentResolver.delete(
            CallLog.Calls.CONTENT_URI,
            null,
            null
        )
    }

    @SuppressLint("MissingPermission")
    override suspend fun getFrequentCalledContacts(): List<Contact> =
        withContext(ioDispatcher) {

            val callCounts = mutableMapOf<String, Int>() // phone -> count

            val projection = arrayOf(
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME
            )

            val now = System.currentTimeMillis()
            val oneMonthAgo = now - 30L * 24 * 60 * 60 * 1000 // last 30 days

            val selection = """
            ${CallLog.Calls.TYPE} != ${CallLog.Calls.MISSED_TYPE}
            AND ${CallLog.Calls.DATE} >= ?
            AND ${CallLog.Calls.CACHED_NAME} IS NOT NULL
        """.trimIndent()

            val selectionArgs = arrayOf(oneMonthAgo.toString())

            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                null
            )?.use { cursor ->

                val numberIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER)

                while (cursor.moveToNext()) {
                    val number = cursor.getString(numberIdx) ?: continue
                    callCounts[number] = (callCounts[number] ?: 0) + 1
                }
            }

            // Top 10 most frequently called saved numbers
            val topNumbers = callCounts.entries
                .sortedByDescending { it.value }
                .distinct()
                .take(10)
                .map { it.key }

            // Safe: all numbers are guaranteed to be saved contacts
            return@withContext topNumbers.mapNotNull {
                contactDetailProvider.getContactByPhone(it)
            }.distinctBy { it.id }
        }

    @SuppressLint("MissingPermission")
    override suspend fun searchCallLogContacts(
        query: String,
        limit: Int,
        offset: Int
    ): List<Contact> = withContext(ioDispatcher) {
        if (query.isBlank()) return@withContext emptyList()

        val normalizedQuery = query.trim()
        val selection = """
            ${CallLog.Calls.NUMBER} LIKE ?
            OR ${CallLog.Calls.CACHED_NAME} LIKE ?
        """.trimIndent()
        val selectionArgs = arrayOf("%$normalizedQuery%", "%$normalizedQuery%")

        contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.CACHED_PHOTO_URI
            ),
            selection,
            selectionArgs,
            "${CallLog.Calls.DATE} DESC LIMIT $limit OFFSET $offset"
        )?.use { cursor ->
            val numberIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
            val nameIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
            val photoIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_PHOTO_URI)
            val byNumber = LinkedHashMap<String, Contact>()

            while (cursor.moveToNext()) {
                val phone = cursor.getString(numberIndex).orEmpty()
                if (phone.isBlank() || byNumber.containsKey(phone)) continue

                val savedContact = contactDetailProvider.getContactByPhone(phone)
                val fallbackName = cursor.getStringOrNull(nameIndex).orEmpty().ifBlank { "Unknown" }
                val fallbackImage = cursor.getStringOrNull(photoIndex)?.toUri()

                byNumber[phone] = savedContact ?: Contact(
                    id = -1,
                    name = fallbackName,
                    phone = phone,
                    image = fallbackImage
                )
            }

            byNumber.values.toList()
        } ?: emptyList()
    }


    private suspend fun queryCallLogs(
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String
    ): List<CallLogData> {
        val simsInfo = simInfoProvider.getSimsInfo()
        val contactsByPhone = mutableMapOf<String, Contact?>()

        return contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            PROJECTION,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            val numberColumnIndex = cursor.getColumnIndex(CallLog.Calls.NUMBER)
            val idColumnIndex = cursor.getColumnIndex(CallLog.Calls._ID)
            val dateColumnIndex = cursor.getColumnIndex(CallLog.Calls.DATE)
            val durationColumnIndex = cursor.getColumnIndex(CallLog.Calls.DURATION)
            val phoneTypeColumnIndex = cursor.getColumnIndex(CallLog.Calls.TYPE)
            val accountIdColumnIndex = cursor.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_ID)
            val cachedPhotoUriIndex = cursor.getColumnIndex(CallLog.Calls.CACHED_PHOTO_URI)
            val cachedLookupUriIndex = cursor.getColumnIndex(CallLog.Calls.CACHED_LOOKUP_URI)

            buildList {
                while (cursor.moveToNext()) {
                    val phone = cursor.getString(numberColumnIndex)
                    var simSlot: Int? = null
                    if (simsInfo.size > 1) {
                        simSlot = simsInfo
                            .find { it.accountId == cursor.getStringOrNull(accountIdColumnIndex) }
                            ?.simSlotIndex ?: -1
                    }
                    val contactIdFromLog = cursor.getStringOrNull(cachedLookupUriIndex)
                        ?.toUri()
                        ?.let { uri -> runCatching { ContentUris.parseId(uri) }.getOrNull() }
                    // Resolve the current contact on every page load. Android's call-log
                    // CACHED_NAME is a historical snapshot and is not updated when a
                    // contact is created or renamed after the call.
                    val currentContact = contactsByPhone.getOrPut(phone) {
                        contactDetailProvider.getContactByPhone(phone)
                    }
                    val resolvedContactId = currentContact?.id ?: contactIdFromLog

                    add(
                        CallLogData(
                            id = cursor.getLong(idColumnIndex),
                            contactId = resolvedContactId,
                            name = currentContact?.name?.takeIf { it.isNotBlank() }
                                ?: cursor.getStringOrEmpty(CallLog.Calls.CACHED_NAME),
                            phone = phone,
                            time = Date(cursor.getLong(dateColumnIndex)),
                            callDuration = cursor.getLong(durationColumnIndex),
                            callLogType = CallLogType.fromInt(cursor.getInt(phoneTypeColumnIndex)),
                            simSlot = simSlot,
                            image = currentContact?.image
                                ?: cursor.getStringOrNull(cachedPhotoUriIndex)?.toUri()
                                ?: contactPhotoProvider.getContactPhotoUri(phone)
                        )
                    )
                }
            }
        } ?: emptyList()
    }

    companion object {
        private fun CallLogFilter.toSelection(
            callerIdSpamEnabled: Boolean,
            supportsBlockReason: Boolean,
        ): Pair<String?, Array<String>?> {
            val callerLabelClause = if (callerIdSpamEnabled) {
                "OR IFNULL(${CallLog.Calls.CACHED_NAME}, '') LIKE ? COLLATE NOCASE"
            } else {
                ""
            }
            val blockReasonClause = if (supportsBlockReason) {
                "OR IFNULL(${CallLog.Calls.BLOCK_REASON}, ${CallLog.Calls.BLOCK_REASON_NOT_BLOCKED}) = ${CallLog.Calls.BLOCK_REASON_CALL_SCREENING_SERVICE}"
            } else {
                ""
            }
            val spamClause = "(${CallLog.Calls.TYPE} = ${CallLog.Calls.BLOCKED_TYPE} $blockReasonClause $callerLabelClause)"
            val spamArgs = if (callerIdSpamEnabled) arrayOf("%spam%") else null

            return when (this) {
                CallLogFilter.ALL -> null to null
                CallLogFilter.MISSED -> {
                    "${CallLog.Calls.TYPE} IN (?, ?)" to arrayOf(
                        CallLog.Calls.MISSED_TYPE.toString(),
                        CallLog.Calls.REJECTED_TYPE.toString(),
                    )
                }

                CallLogFilter.CONTACTS -> {
                    "${CallLog.Calls.CACHED_LOOKUP_URI} IS NOT NULL" to null
                }

                CallLogFilter.NON_SPAM -> "NOT $spamClause" to spamArgs
                CallLogFilter.SPAM -> spamClause to spamArgs
            }
        }

        private val PROJECTION = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.TYPE,
            CallLog.Calls.PHONE_ACCOUNT_ID,
            CallLog.Calls.CACHED_PHOTO_URI,
            CallLog.Calls.CACHED_LOOKUP_URI,
        )
    }

}
