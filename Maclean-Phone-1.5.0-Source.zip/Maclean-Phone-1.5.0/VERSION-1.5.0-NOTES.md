# Maclean Phone 1.5.0 — Recent-call contact name refresh

- Resolves current saved contact names and IDs for historical call-log rows, instead of relying solely on stale Android `CACHED_NAME`.
- Uses current contact photos when available.
- Refreshes Recents when the screen resumes so newly saved or renamed contacts appear without making another call.
- Preserves call-log records, phone numbers, calling-account information, and existing UI.
- Version name 1.5.0; version code 21.

## Build

Open this Gradle project in Android Studio or build with `./gradlew :app:assembleDebug` after configuring the Android SDK. No signing keys are included.

## Validation

Build and device tests were not executed here. Verify creating a contact from an unknown recent number, returning to Recents, and checking the contact name.

Note: The Contacts-only call-log filter still uses Android's cached lookup URI and may not include older calls until the provider updates its cache.
