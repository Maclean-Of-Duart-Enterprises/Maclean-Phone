# Third-party notices

## Linphone SDK for Android

- Component: `org.linphone:linphone-sdk-android:5.4.124`
- Project: <https://gitlab.linphone.org/BC/public/linphone-sdk>
- License: GNU General Public License, version 3
- License text: [COPYING.GPL-3.0](COPYING.GPL-3.0)

Linphone provides the SIP registration, incoming-call media, DTMF event, prompt
player, and SIP REFER transfer capabilities used by this modification.

## Original Amadz application

- Project: <https://github.com/msusman1/Amadz>
- Base release: `1.1.5`, commit `483f8d74238c5c1677549734215ce15a74384195`
- License: Apache License 2.0
- License text: [LICENSE.txt](LICENSE.txt)

All other Android and Kotlin dependencies are declared in
`gradle/libs.versions.toml` and resolved from their configured Maven
repositories.
