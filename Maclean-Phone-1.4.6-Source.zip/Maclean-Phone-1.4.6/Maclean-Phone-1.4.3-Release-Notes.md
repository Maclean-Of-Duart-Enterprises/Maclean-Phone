# Maclean Phone 1.4.3 Release Notes

Release date: 2026-09-15

## Group calling

- Added separate **Add call** and **Merge calls** buttons to the in-call screen.
- Added support for keeping multiple Android Telecom calls attached to the
  in-call UI instead of replacing the first call when a second call appears.
- Added carrier-capability-aware conference merging. **Merge calls** becomes
  available only when Android Telecom reports a mergeable call relationship or
  conference merge capability.
- Added active/held call switching and carrier conference swapping.
- Added a participant-management dialog with stable per-call identity,
  participant status, switch, separate, and end controls when the calling
  account exposes those capabilities.
- Added direct conference-participant requests on Android 12 and later when the
  connection service exposes participant-add capability.
- Added accurate operation feedback: the app reports requests as pending and
  reports a connected conference only after Telecom exposes conference state.
- Preserved the phone account that owns the live call when placing an additional
  call, including carrier, multi-SIM, and compatible redirecting accounts.
- Made caller-number extraction safe for gateway and redirected calls.
- Added graceful permission handling when resolving a selected calling account.

## Compatibility and preservation

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version is `1.4.3` with version code `14`.
- Signed with the existing Maclean Phone release identity, allowing an in-place
  update from correctly signed 1.4.1 or 1.4.2 installations.
- No CRM database schema or migration was changed; existing contacts, groups,
  preferences, and app data remain intact during upgrade.
- Existing CRM, VCF, SIP/VoIP IVR, caller ID, voicemail, forwarding, recording,
  accessibility, appearance, AGPLv3 license, and audio-route behavior are
  retained.

## Calling-account limitations

Group calling is provided through Android Telecom. The carrier or VoIP
connection service decides whether a second call, hold, merge, swap, participant
separation, and individual participant disconnection are available. Emergency
calls and some Google Voice, SIP, prepaid, roaming, or Wi-Fi calling routes may
not expose these capabilities. Unsupported controls remain disabled and the app
shows an explanatory message instead of claiming success.

