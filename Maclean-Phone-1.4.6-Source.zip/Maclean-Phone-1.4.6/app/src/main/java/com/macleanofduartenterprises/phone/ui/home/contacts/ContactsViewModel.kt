package com.macleanofduartenterprises.phone.ui.home.contacts

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.macleanofduartenterprises.phone.crm.ContactStorage
import com.macleanofduartenterprises.phone.crm.CrmContact
import com.macleanofduartenterprises.phone.crm.CrmGroup
import com.macleanofduartenterprises.phone.crm.CrmOperationResult
import com.macleanofduartenterprises.phone.crm.CrmRepository
import com.macleanofduartenterprises.phone.crm.CrmSharedFile
import com.macleanofduartenterprises.phone.crm.CrmSnapshot
import com.macleanofduartenterprises.phone.crm.CrmSortField
import com.macleanofduartenterprises.phone.crm.DuplicateMatch
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ContactsUiState(
    val snapshot: CrmSnapshot = CrmSnapshot(),
    val query: String = "",
    val sortField: CrmSortField = CrmSortField.FIRST_NAME,
    val ascending: Boolean = true,
    val selectedGroupId: Long? = null,
    val favoritesOnly: Boolean = false,
    val selectedIds: Set<String> = emptySet(),
    val duplicateMatches: List<DuplicateMatch> = emptyList(),
    val loading: Boolean = true,
    val working: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val shareFile: CrmSharedFile? = null,
) {
    val selectionMode: Boolean get() = selectedIds.isNotEmpty()
    val selectedCount: Int get() = selectedIds.size
}

@HiltViewModel
class ContactsViewModel @Inject constructor(
    private val repository: CrmRepository,
    @ApplicationContext context: Context,
) : ViewModel() {
    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val initialSort = runCatching {
        CrmSortField.valueOf(
            preferences.getString(KEY_SORT, CrmSortField.FIRST_NAME.name)
                ?: CrmSortField.FIRST_NAME.name,
        )
    }.getOrDefault(CrmSortField.FIRST_NAME)
    private val _state = MutableStateFlow(
        ContactsUiState(
            sortField = initialSort,
            ascending = preferences.getBoolean(KEY_ASCENDING, true),
        ),
    )
    val state: StateFlow<ContactsUiState> = _state.asStateFlow()
    private val selectedContacts = linkedMapOf<String, CrmContact>()
    private var refreshJob: Job? = null

    init { refresh() }

    fun refresh(debounceMillis: Long = 0) {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            if (debounceMillis > 0) delay(debounceMillis)
            val request = _state.value
            _state.update { it.copy(loading = true, error = null) }
            runCatching {
                repository.loadSnapshot(
                    query = request.query,
                    sortField = request.sortField,
                    ascending = request.ascending,
                    groupId = request.selectedGroupId,
                    favoritesOnly = request.favoritesOnly,
                )
            }.onSuccess { snapshot ->
                snapshot.contacts.forEach { contact ->
                    if (contact.stableId in _state.value.selectedIds) {
                        selectedContacts[contact.stableId] = contact
                    }
                }
                _state.update { it.copy(snapshot = snapshot, loading = false) }
            }.onFailure { error ->
                _state.update { it.copy(loading = false, error = error.readableMessage()) }
            }
        }
    }

    fun setQuery(query: String) {
        _state.update { it.copy(query = query) }
        refresh(180)
    }

    fun setSort(field: CrmSortField, ascending: Boolean) {
        preferences.edit().putString(KEY_SORT, field.name)
            .putBoolean(KEY_ASCENDING, ascending).apply()
        _state.update { it.copy(sortField = field, ascending = ascending) }
        refresh()
    }

    fun setGroupFilter(groupId: Long?) {
        _state.update { it.copy(selectedGroupId = groupId, favoritesOnly = false) }
        refresh()
    }

    fun setFavoritesFilter() {
        _state.update { it.copy(selectedGroupId = null, favoritesOnly = true) }
        refresh()
    }

    fun toggleSelection(contact: CrmContact) {
        val id = contact.stableId
        if (id in _state.value.selectedIds) {
            selectedContacts.remove(id)
            _state.update { it.copy(selectedIds = it.selectedIds - id) }
        } else {
            selectedContacts[id] = contact
            _state.update { it.copy(selectedIds = it.selectedIds + id) }
        }
    }

    fun selectOnly(contact: CrmContact) {
        selectedContacts.clear()
        selectedContacts[contact.stableId] = contact
        _state.update { it.copy(selectedIds = setOf(contact.stableId)) }
    }

    fun selectAll() {
        _state.value.snapshot.contacts.forEach { selectedContacts[it.stableId] = it }
        _state.update { it.copy(selectedIds = selectedContacts.keys.toSet()) }
    }

    fun clearSelection() {
        selectedContacts.clear()
        _state.update { it.copy(selectedIds = emptySet()) }
    }

    fun selected(): List<CrmContact> = _state.value.selectedIds.mapNotNull(selectedContacts::get)

    fun saveContact(contact: CrmContact, onSuccess: () -> Unit) {
        launchOperation(
            operation = { repository.saveContact(contact) },
            successMessage = { "${it.displayName} saved." },
            onSuccess = { onSuccess() },
        )
    }

    fun importVCard(uri: Uri, storage: ContactStorage) {
        launchOperation(
            operation = { repository.importVCard(uri, storage) },
            successMessage = { result ->
                buildString {
                    append("Imported ${result.imported} contact${if (result.imported == 1) "" else "s"}")
                    if (result.failed > 0) append("; ${result.failed} failed")
                    append('.')
                    if (result.messages.isNotEmpty()) append(" ${result.messages.joinToString(" ")}")
                }
            },
        )
    }

    fun delete(contacts: List<CrmContact> = selected(), onSuccess: () -> Unit = {}) {
        launchOperation(
            operation = { repository.deleteContacts(contacts) },
            successMessage = { it.operationMessage("Deleted") },
            onSuccess = {
                clearSelection()
                onSuccess()
            },
        )
    }

    fun copy(
        contacts: List<CrmContact> = selected(),
        storage: ContactStorage = ContactStorage.APP,
    ) {
        launchOperation(
            operation = { repository.copyContacts(contacts, storage) },
            successMessage = { it.operationMessage("Copied") },
            onSuccess = { clearSelection() },
        )
    }

    fun setFavorite(contact: CrmContact, favorite: Boolean) {
        launchOperation(
            operation = { repository.setFavorite(contact, favorite) },
            successMessage = { if (favorite) "Added to favorites." else "Removed from favorites." },
        )
    }

    fun updateGroups(
        contacts: List<CrmContact>,
        groupIds: Set<Long>,
        add: Boolean,
    ) {
        launchOperation(
            operation = { repository.updateGroupMembership(contacts, groupIds, add) },
            successMessage = { it.operationMessage(if (add) "Updated groups for" else "Removed groups from") },
            onSuccess = { clearSelection() },
        )
    }

    fun export(uri: Uri, contacts: List<CrmContact>) {
        launchOperation(
            operation = { repository.exportContacts(uri, contacts, _state.value.snapshot.groups) },
            successMessage = { result ->
                "Exported ${result.exported} contact${if (result.exported == 1) "" else "s"}" +
                    if (result.failed > 0) "; ${result.failed} failed. ${result.messages.joinToString(" ")}" else "."
            },
            onSuccess = { clearSelection() },
            refreshAfter = false,
        )
    }

    fun exportAll(uri: Uri) {
        launchOperation(
            operation = {
                val snapshot = repository.loadSnapshot(
                    sortField = _state.value.sortField,
                    ascending = _state.value.ascending,
                )
                repository.exportContacts(uri, snapshot.contacts, snapshot.groups)
            },
            successMessage = { "Exported ${it.exported} contact${if (it.exported == 1) "" else "s"}." },
            refreshAfter = false,
        )
    }

    fun exportGroup(uri: Uri, groupId: Long) {
        launchOperation(
            operation = {
                val snapshot = repository.loadSnapshot(
                    sortField = _state.value.sortField,
                    ascending = _state.value.ascending,
                    groupId = groupId,
                )
                repository.exportContacts(uri, snapshot.contacts, snapshot.groups)
            },
            successMessage = { "Exported ${it.exported} group contact${if (it.exported == 1) "" else "s"}." },
            refreshAfter = false,
        )
    }

    fun share(contacts: List<CrmContact>, label: String = "Maclean-Contacts") {
        launchOperation(
            operation = { repository.createShareFile(contacts, _state.value.snapshot.groups, label) },
            successMessage = { "Prepared ${it.export.exported} contact${if (it.export.exported == 1) "" else "s"} to share." },
            onSuccess = { shared ->
                _state.update { it.copy(shareFile = shared) }
                clearSelection()
            },
            refreshAfter = false,
        )
    }

    fun shareGroup(group: CrmGroup) {
        launchOperation(
            operation = {
                val snapshot = repository.loadSnapshot(groupId = group.id)
                repository.createShareFile(snapshot.contacts, snapshot.groups, group.name)
            },
            successMessage = { "Prepared ${it.export.exported} group contact${if (it.export.exported == 1) "" else "s"} to share." },
            onSuccess = { shared -> _state.update { it.copy(shareFile = shared) } },
            refreshAfter = false,
        )
    }

    fun consumeShareFile() {
        _state.update { it.copy(shareFile = null) }
    }

    fun merge(contacts: List<CrmContact> = selected()) {
        launchOperation(
            operation = { repository.mergeContacts(contacts) },
            successMessage = { result ->
                buildString {
                    append("Merged into ${result.mergedContact.displayName}; removed ${result.deletedSources} source")
                    if (result.deletedSources != 1) append('s')
                    if (result.failedDeletes > 0) append("; ${result.failedDeletes} source deletions failed")
                    append('.')
                    if (result.messages.isNotEmpty()) append(" ${result.messages.joinToString(" ")}")
                }
            },
            onSuccess = { clearSelection() },
        )
    }

    fun scanDuplicates() {
        launchOperation(
            operation = { repository.findSuspectedDuplicates(_state.value.snapshot.contacts) },
            successMessage = { if (it.isEmpty()) "No duplicate candidates found." else "Found ${it.size} duplicate candidate set${if (it.size == 1) "" else "s"}." },
            onSuccess = { matches -> _state.update { it.copy(duplicateMatches = matches) } },
            refreshAfter = false,
        )
    }

    fun clearDuplicates() {
        _state.update { it.copy(duplicateMatches = emptyList()) }
    }

    fun selectDuplicate(match: DuplicateMatch) {
        clearSelection()
        match.contacts.forEach { contact ->
            selectedContacts[contact.stableId] = contact
        }
        _state.update { it.copy(selectedIds = match.contacts.map(CrmContact::stableId).toSet()) }
    }

    fun saveGroup(group: CrmGroup, onSuccess: () -> Unit = {}) {
        launchOperation(
            operation = { repository.saveGroup(group) },
            successMessage = { "Group saved." },
            onSuccess = { onSuccess() },
        )
    }

    fun deleteGroup(groupId: Long) {
        launchOperation(
            operation = { repository.deleteGroup(groupId) },
            successMessage = { "Group removed; contacts were kept." },
            onSuccess = {
                _state.update { state ->
                    state.copy(selectedGroupId = state.selectedGroupId.takeUnless { it == groupId })
                }
            },
        )
    }

    fun moveGroup(groupId: Long, direction: Int) {
        launchOperation(
            operation = { repository.moveGroup(groupId, direction) },
            successMessage = { "Group order saved." },
        )
    }

    fun clearNotice() {
        _state.update { it.copy(message = null, error = null) }
    }

    private fun <T> launchOperation(
        operation: suspend () -> T,
        successMessage: (T) -> String,
        onSuccess: (T) -> Unit = {},
        refreshAfter: Boolean = true,
    ) {
        viewModelScope.launch {
            _state.update { it.copy(working = true, error = null, message = null) }
            runCatching { operation() }.onSuccess { result ->
                _state.update { it.copy(working = false, message = successMessage(result)) }
                onSuccess(result)
                if (refreshAfter) refresh()
            }.onFailure { error ->
                _state.update { it.copy(working = false, error = error.readableMessage()) }
            }
        }
    }

    companion object {
        private const val PREFS_NAME = "maclean_crm_preferences"
        private const val KEY_SORT = "contact_sort"
        private const val KEY_ASCENDING = "contact_sort_ascending"
    }
}

private fun CrmOperationResult.operationMessage(verb: String): String = buildString {
    append("$verb $succeeded contact${if (succeeded == 1) "" else "s"}")
    if (failed > 0) append("; $failed failed")
    append('.')
    if (messages.isNotEmpty()) append(" ${messages.joinToString(" ")}")
}

private fun Throwable.readableMessage(): String =
    message?.takeIf(String::isNotBlank) ?: "The contact operation could not be completed."
