package com.macleanofduartenterprises.phone.domain

import android.telecom.Call
import com.macleanofduartenterprises.phone.domain.entity.CallState
import com.macleanofduartenterprises.phone.domain.entity.GroupCallState
import kotlinx.coroutines.flow.StateFlow

interface CallOrchestrator {
    val callState: StateFlow<CallState>
    val groupCallState: StateFlow<GroupCallState>

    fun onAction(callAction: CallAction)
    fun setCallServiceAudioDelegate(audioController: CallServiceAudioDelegate)
    fun selectAudioRoute(routeId: String)
    fun onCallAdded(call: Call)
    fun onCallRemoved(call: Call)
    fun onCanAddCallChanged(canAddCall: Boolean)
    fun onDestroy()
}
