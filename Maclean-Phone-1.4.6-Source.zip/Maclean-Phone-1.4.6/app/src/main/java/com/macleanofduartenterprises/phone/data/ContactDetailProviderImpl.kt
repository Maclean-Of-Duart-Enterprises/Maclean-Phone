package com.macleanofduartenterprises.phone.data

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.util.LruCache
import androidx.core.net.toUri
import com.macleanofduartenterprises.phone.di.IODispatcher
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.entity.ContactPhone
import com.macleanofduartenterprises.phone.domain.entity.ContactPhoneChoicePolicy
import com.macleanofduartenterprises.phone.domain.repo.ContactDetailProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContactDetailProviderImpl @Inject constructor(
    @ApplicationContext context: Context,
    @IODispatcher private val ioDispatcher: CoroutineDispatcher
) : ContactDetailProvider {

    private val appContext = context
    private val contentResolver = context.contentResolver

    /**
     * Cache both FOUND and NOT FOUND results.
     * null values are cached explicitly.
     */
    private val cache = LruCache<String, Contact?>(100)

    override suspend fun getContactByPhone(phone: String): Contact? =
        withContext(ioDispatcher) {

            // 1. Cache hit (including null)
            if (cache.snapshot().containsKey(phone)) {
                return@withContext cache[phone]
            }

            val contact = queryContact(phone)
            if (contact != null) {
                cache.put(phone, contact)
            }
            return@withContext contact
        }

    // ----------------------------
    // Internal query (single lookup)
    // ----------------------------

    private fun queryContact(phone: String): Contact? {

        val lookupUri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phone)
        )

        val projection = arrayOf(
            ContactsContract.PhoneLookup._ID,
            ContactsContract.PhoneLookup.DISPLAY_NAME,
            ContactsContract.PhoneLookup.NUMBER,
            ContactsContract.PhoneLookup.PHOTO_URI
        )

        contentResolver.query(
            lookupUri,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val contactId = cursor.getLong(0)
                val matchedNumber = cursor.getString(2) ?: phone
                val phones = loadPhoneNumbers(contactId, matchedNumber)
                return Contact(
                    id = contactId,
                    name = cursor.getString(1) ?: phone,
                    phone = phones.firstOrNull()?.number ?: matchedNumber,
                    image = cursor.getString(3)?.toUri(),
                    phoneNumbers = phones,
                )
            }
        }

        return null
    }

    private fun loadPhoneNumbers(contactId: Long, fallback: String): List<ContactPhone> {
        val rows = mutableListOf<ContactPhone>()
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.LABEL,
                ContactsContract.CommonDataKinds.Phone.IS_PRIMARY,
            ),
            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
            arrayOf(contactId.toString()),
            "${ContactsContract.CommonDataKinds.Phone.IS_PRIMARY} DESC",
        )?.use { cursor ->
            val numberIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
            val labelIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)
            val primaryIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.IS_PRIMARY)
            while (cursor.moveToNext()) {
                val number = cursor.getString(numberIndex).orEmpty()
                if (number.isBlank()) continue
                rows += ContactPhone(
                    number = number,
                    label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                        appContext.resources,
                        cursor.getInt(typeIndex),
                        cursor.getString(labelIndex),
                    ).toString(),
                    isPrimary = cursor.getInt(primaryIndex) != 0,
                )
            }
        }
        return ContactPhoneChoicePolicy.choices(fallback, rows)
    }
}
