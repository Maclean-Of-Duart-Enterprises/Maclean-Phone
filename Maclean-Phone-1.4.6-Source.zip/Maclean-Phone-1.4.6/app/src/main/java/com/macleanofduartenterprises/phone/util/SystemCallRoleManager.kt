package com.macleanofduartenterprises.phone.util

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build

/** Android system roles that must always be granted by the device owner. */
object SystemCallRoleManager {
    enum class CallRole(val label: String) {
        CALLER_ID_AND_SPAM("Caller ID & spam"),
    }

    fun isAvailable(context: Context, role: CallRole): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val roleManager = context.getSystemService(RoleManager::class.java) ?: return false
        return roleManager.isRoleAvailable(role.roleName())
    }

    fun isHeld(context: Context, role: CallRole): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val roleManager = context.getSystemService(RoleManager::class.java) ?: return false
        return roleManager.isRoleAvailable(role.roleName()) &&
            roleManager.isRoleHeld(role.roleName())
    }

    fun requestIntent(context: Context, role: CallRole): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val roleManager = context.getSystemService(RoleManager::class.java) ?: return null
        val roleName = role.roleName()
        if (!roleManager.isRoleAvailable(roleName) || roleManager.isRoleHeld(roleName)) {
            return null
        }
        return roleManager.createRequestRoleIntent(roleName)
    }

    private fun CallRole.roleName(): String = when (this) {
        CallRole.CALLER_ID_AND_SPAM -> RoleManager.ROLE_CALL_SCREENING
    }
}
