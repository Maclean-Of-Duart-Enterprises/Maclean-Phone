package com.macleanofduartenterprises.phone.crm

import android.net.Uri
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.entity.ContactPhone
import java.util.Locale

enum class ContactStorage(val label: String) {
    APP("Maclean Phone app"),
    PHONE("Phone contacts"),
    SIM("SIM card"),
}

enum class CrmFieldType(val label: String) {
    PHONE("Phone"),
    EMAIL("Email"),
    ADDRESS("Mailing address"),
    FAX("Fax"),
    WEBSITE("Website"),
    CUSTOM("Custom"),
}

enum class CrmSortField(val label: String) {
    FIRST_NAME("First name"),
    LAST_NAME("Last name"),
    COMPANY("Company"),
    RECENTLY_UPDATED("Recently updated"),
    DATE_ADDED("Date added"),
}

data class CrmCustomField(
    val id: Long = 0,
    val type: CrmFieldType = CrmFieldType.CUSTOM,
    val label: String = "Custom field",
    val value: String = "",
    val countryCode: String = "",
    val position: Int = 0,
) {
    fun completeValue(): String {
        val valueTrimmed = value.trim()
        val codeTrimmed = countryCode.trim()
        return if (
            type in setOf(CrmFieldType.PHONE, CrmFieldType.FAX) &&
            codeTrimmed.isNotEmpty() &&
            valueTrimmed.isNotEmpty() &&
            !valueTrimmed.startsWith("+")
        ) {
            "${if (codeTrimmed.startsWith("+")) codeTrimmed else "+$codeTrimmed"}$valueTrimmed"
        } else {
            valueTrimmed
        }
    }
}

data class CrmGroup(
    val id: Long = 0,
    val name: String,
    val colorArgb: Long = 0xFF2E6F60,
    val position: Int = 0,
)

data class CrmContact(
    val id: Long = 0,
    val systemContactId: Long? = null,
    val rawContactId: Long? = null,
    val storage: ContactStorage = ContactStorage.APP,
    val firstName: String = "",
    val middleName: String = "",
    val lastName: String = "",
    val nickname: String = "",
    val household: String = "",
    val company: String = "",
    val birthday: String = "",
    val notes: String = "",
    val photoUri: String? = null,
    val stage: String = CRM_STAGES.first(),
    val service: String = "",
    val source: String = "",
    val representative: String = "",
    val nextAction: String = "",
    val favorite: Boolean = false,
    val readOnly: Boolean = false,
    val customFields: List<CrmCustomField> = listOf(
        CrmCustomField(type = CrmFieldType.PHONE, label = "Mobile", position = 0),
        CrmCustomField(type = CrmFieldType.EMAIL, label = "Email", position = 1),
    ),
    val groupIds: Set<Long> = emptySet(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val systemOnly: Boolean = false,
) {
    val displayName: String
        get() {
            val personalName = listOf(firstName, middleName, lastName)
                .map(String::trim)
                .filter(String::isNotEmpty)
                .joinToString(" ")
            return personalName.ifBlank {
                nickname.trim().ifBlank {
                    company.trim().ifBlank {
                        household.trim().ifBlank { "Unnamed contact" }
                    }
                }
            }
        }

    val primaryPhone: String
        get() = customFields.firstOrNull {
            it.type == CrmFieldType.PHONE && it.value.isNotBlank()
        }?.completeValue().orEmpty()

    val primaryEmail: String
        get() = customFields.firstOrNull {
            it.type == CrmFieldType.EMAIL && it.value.isNotBlank()
        }?.value.orEmpty()

    /** Stable, collision-free UI identity; Android and CRM IDs occupy different namespaces. */
    val stableId: String
        get() = when {
            id > 0L -> "crm:$id"
            rawContactId != null -> "raw:$rawContactId"
            systemContactId != null -> "android:$systemContactId"
            else -> "draft:${System.identityHashCode(this)}"
        }

    fun searchableText(groups: List<CrmGroup>): String = buildString {
        append(displayName)
        append(' ')
        append(nickname)
        append(' ')
        append(company)
        append(' ')
        append(household)
        append(' ')
        append(notes)
        append(' ')
        append(stage)
        append(' ')
        append(service)
        append(' ')
        append(source)
        append(' ')
        append(representative)
        append(' ')
        append(nextAction)
        append(' ')
        append(birthday)
        append(' ')
        customFields.forEach {
            append(it.label)
            append(' ')
            append(it.completeValue())
            append(' ')
        }
        groups.filter { it.id in groupIds }.forEach {
            append(it.name)
            append(' ')
        }
    }.lowercase(Locale.ROOT)

    fun toLegacyContact(): Contact = Contact(
        id = systemContactId ?: -id.coerceAtLeast(1L),
        name = displayName,
        phone = primaryPhone,
        image = photoUri?.let(Uri::parse),
        phoneNumbers = customFields
            .filter { it.type == CrmFieldType.PHONE && it.value.isNotBlank() }
            .mapIndexed { index, field ->
                ContactPhone(
                    number = field.completeValue(),
                    label = field.label.ifBlank { "Phone" },
                    isPrimary = index == 0,
                )
            },
    )
}

data class ContactStorageOption(
    val storage: ContactStorage,
    val enabled: Boolean = true,
    val detail: String,
)

data class CrmSnapshot(
    val contacts: List<CrmContact> = emptyList(),
    val groups: List<CrmGroup> = emptyList(),
    val storageOptions: List<ContactStorageOption> = emptyList(),
)

data class VCardImportResult(
    val imported: Int,
    val failed: Int,
    val messages: List<String> = emptyList(),
)

data class CrmOperationResult(
    val succeeded: Int,
    val failed: Int = 0,
    val messages: List<String> = emptyList(),
) {
    val isSuccess: Boolean get() = failed == 0
}

data class CrmExportResult(
    val exported: Int,
    val failed: Int = 0,
    val messages: List<String> = emptyList(),
)

data class CrmSharedFile(
    val uri: Uri,
    val export: CrmExportResult,
    val displayName: String,
)

data class CrmMergeResult(
    val mergedContact: CrmContact,
    val deletedSources: Int,
    val failedDeletes: Int = 0,
    val messages: List<String> = emptyList(),
)

data class DuplicateMatch(
    val contacts: List<CrmContact>,
    val reasons: Set<String>,
)

val CRM_STAGES = listOf("New lead", "Qualified", "Assessment", "Proposal", "Client")
