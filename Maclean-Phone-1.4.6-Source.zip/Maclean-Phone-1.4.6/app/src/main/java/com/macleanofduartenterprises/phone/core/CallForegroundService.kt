package com.macleanofduartenterprises.phone.core

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.app.ServiceCompat
import com.macleanofduartenterprises.phone.domain.NotificationController
import com.macleanofduartenterprises.phone.domain.RingToneController
import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val TAG = "CallForegroundService"

@AndroidEntryPoint
class CallForegroundService : Service() {

    @Inject
    lateinit var notificationController: NotificationController

    @Inject
    lateinit var ringToneController: RingToneController

    @Inject
    lateinit var callerIdAnnouncer: CallerIdAnnouncer

    private val scope = MainScope()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY
        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        val duration = intent.getIntExtra(EXTRA_DURATION_SECONDS, 0)
        val localLine = CalledLineInfo(
            number = intent.getStringExtra(EXTRA_LOCAL_NUMBER).orEmpty(),
            accountLabel = intent.getStringExtra(EXTRA_LOCAL_ACCOUNT_LABEL).orEmpty(),
        )

        scope.launch {
            when (action) {
                ACTION_SHOW_INCOMING -> {
                    if (phone.isBlank()) return@launch
                    ringToneController.playCallRingTone()
                    callerIdAnnouncer.announce(phone)
                    val notification = notificationController.buildIncomingCallNotification(
                        phone,
                        localLine,
                    )
                    startCallForeground(notification)
                }

                ACTION_SHOW_OUTGOING -> {
                    if (phone.isBlank()) return@launch
                    ringToneController.stepCallRingTone()
                    val notification = notificationController.buildOutgoingCallNotification(
                        phone,
                        localLine,
                    )
                    startCallForeground(notification)
                }

                ACTION_SHOW_ONGOING -> {
                    if (phone.isBlank()) return@launch
                    ringToneController.stepCallRingTone()
                    val notification = notificationController.buildOngoingCallNotification(
                        phone,
                        duration,
                        localLine,
                    )
                    startCallForeground(notification)
                }

                ACTION_STOP_CALL_UI -> stopServiceInternal()
            }
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        ringToneController.stepCallRingTone()
        scope.cancel()
        super.onDestroy()
    }

    private fun startCallForeground(notification: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                ONGOING_CALL_NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
            )
        } else {
            startForeground(ONGOING_CALL_NOTIFICATION_ID, notification)
        }
    }

    private fun stopServiceInternal() {
        Log.d(TAG, "Stopping call foreground service")
        ringToneController.stepCallRingTone()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {
        const val ONGOING_CALL_NOTIFICATION_ID = 124

        private const val EXTRA_PHONE = "extra_phone"
        private const val EXTRA_DURATION_SECONDS = "extra_duration_seconds"
        private const val EXTRA_LOCAL_NUMBER = "extra_local_number"
        private const val EXTRA_LOCAL_ACCOUNT_LABEL = "extra_local_account_label"

        private const val ACTION_SHOW_INCOMING = "com.macleanofduartenterprises.phone.call.SHOW_INCOMING"
        private const val ACTION_SHOW_OUTGOING = "com.macleanofduartenterprises.phone.call.SHOW_OUTGOING"
        private const val ACTION_SHOW_ONGOING = "com.macleanofduartenterprises.phone.call.SHOW_ONGOING"
        private const val ACTION_STOP_CALL_UI = "com.macleanofduartenterprises.phone.call.STOP_UI"

        fun showIncoming(context: Context, phone: String, calledLine: CalledLineInfo) {
            context.startCallForegroundService(
                Intent(context, CallForegroundService::class.java).apply {
                    action = ACTION_SHOW_INCOMING
                    putExtra(EXTRA_PHONE, phone)
                    putExtra(EXTRA_LOCAL_NUMBER, calledLine.number)
                    putExtra(EXTRA_LOCAL_ACCOUNT_LABEL, calledLine.accountLabel)
                }
            )
        }

        fun showOutgoing(context: Context, phone: String, callingLine: CalledLineInfo) {
            context.startCallForegroundService(
                Intent(context, CallForegroundService::class.java).apply {
                    action = ACTION_SHOW_OUTGOING
                    putExtra(EXTRA_PHONE, phone)
                    putExtra(EXTRA_LOCAL_NUMBER, callingLine.number)
                    putExtra(EXTRA_LOCAL_ACCOUNT_LABEL, callingLine.accountLabel)
                }
            )
        }

        fun showOngoing(
            context: Context,
            phone: String,
            durationSeconds: Int,
            callingLine: CalledLineInfo,
        ) {
            context.startCallForegroundService(
                Intent(context, CallForegroundService::class.java).apply {
                    action = ACTION_SHOW_ONGOING
                    putExtra(EXTRA_PHONE, phone)
                    putExtra(EXTRA_DURATION_SECONDS, durationSeconds)
                    putExtra(EXTRA_LOCAL_NUMBER, callingLine.number)
                    putExtra(EXTRA_LOCAL_ACCOUNT_LABEL, callingLine.accountLabel)
                }
            )
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, CallForegroundService::class.java).apply {
                    action = ACTION_STOP_CALL_UI
                }
            )
        }

        private fun Context.startCallForegroundService(intent: Intent) {
            ContextCompat.startForegroundService(this, intent)
        }
    }
}
