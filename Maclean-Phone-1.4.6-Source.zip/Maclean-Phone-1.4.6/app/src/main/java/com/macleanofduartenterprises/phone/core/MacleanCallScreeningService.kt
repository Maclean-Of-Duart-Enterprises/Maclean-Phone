package com.macleanofduartenterprises.phone.core

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.annotation.RequiresApi
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Android's system-bound Caller ID and spam entry point.
 * The service is eligible for the system Caller ID & spam role and always
 * returns a decision synchronously so an incoming call is never stalled.
 */
@AndroidEntryPoint
@RequiresApi(Build.VERSION_CODES.Q)
class MacleanCallScreeningService : CallScreeningService() {
    @Inject
    lateinit var llamaCallerAssistant: LlamaCallerAssistant

    override fun onScreenCall(callDetails: Call.Details) {
        val response = runCatching {
            val isIncoming = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                callDetails.callDirection == Call.Details.DIRECTION_INCOMING
            } else {
                true
            }
            if (!isIncoming) return@runCatching allowResponse()

            val phone = callDetails.handle?.schemeSpecificPart.orEmpty()
            val assessment = llamaCallerAssistant.assess(phone)
            val spamProtectionOn = PhoneSettingsPrefs.callerIdSpamEnabled(this)
            val blocked = assessment.category == CallerCategory.BLOCKED
            val silenceLikelySpam = spamProtectionOn &&
                PhoneSettingsPrefs.llamaAutoSilenceEnabled(this) &&
                assessment.shouldSilence

            CallResponse.Builder()
                .setDisallowCall(blocked)
                .setRejectCall(blocked)
                .setSilenceCall(!blocked && silenceLikelySpam)
                .setSkipCallLog(false)
                .setSkipNotification(blocked)
                .build()
        }.getOrElse { allowResponse() }

        respondToCall(callDetails, response)
    }

    private fun allowResponse(): CallResponse = CallResponse.Builder()
        .setDisallowCall(false)
        .setRejectCall(false)
        .setSilenceCall(false)
        .setSkipCallLog(false)
        .setSkipNotification(false)
        .build()
}
