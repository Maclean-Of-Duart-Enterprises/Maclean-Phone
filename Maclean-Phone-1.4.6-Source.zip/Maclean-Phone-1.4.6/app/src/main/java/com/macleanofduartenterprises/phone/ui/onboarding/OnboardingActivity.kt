package com.macleanofduartenterprises.phone.ui.onboarding

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.macleanofduartenterprises.phone.MainActivity
import com.macleanofduartenterprises.phone.ui.theme.MacleanPhoneTheme
import com.macleanofduartenterprises.phone.util.PermissionChecker
import com.macleanofduartenterprises.phone.util.SystemCallRoleManager
import com.macleanofduartenterprises.phone.util.SystemCallRoleManager.CallRole
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class OnboardingActivity : ComponentActivity() {

    private val dialerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                PermissionChecker.setVoipOnlyMode(this, false)
                requestCallerIdRole()
            }
        }

    private val callerIdLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            navigateToMain()
        }

    private val dialerRequestIntent: Intent
        get() = PermissionChecker.changeDialogRequestUiIntent(this)

    private fun requestCallerIdRole() {
        val intent = SystemCallRoleManager.requestIntent(this, CallRole.CALLER_ID_AND_SPAM)
        if (intent == null) navigateToMain() else callerIdLauncher.launch(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MacleanPhoneTheme {
                OnboardingScreen(
                    onRequestDialerPermission = {
                        dialerLauncher.launch(dialerRequestIntent)
                    },
                    onUseVoipOnly = {
                        PermissionChecker.setVoipOnlyMode(this, true)
                        navigateToMain()
                    }
                )
            }
        }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

}
