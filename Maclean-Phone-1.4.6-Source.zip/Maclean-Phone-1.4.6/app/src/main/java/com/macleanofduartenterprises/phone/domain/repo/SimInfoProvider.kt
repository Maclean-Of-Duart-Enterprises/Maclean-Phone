package com.macleanofduartenterprises.phone.domain.repo

import com.macleanofduartenterprises.phone.domain.entity.SimInfo

interface SimInfoProvider {
    fun getSimsInfo(): List<SimInfo>
}