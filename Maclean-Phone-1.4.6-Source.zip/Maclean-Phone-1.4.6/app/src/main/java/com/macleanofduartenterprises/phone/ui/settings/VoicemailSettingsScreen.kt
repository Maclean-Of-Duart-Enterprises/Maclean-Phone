package com.macleanofduartenterprises.phone.ui.settings

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.telecom.TelecomManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.PhoneForwarded
import androidx.compose.material.icons.outlined.SettingsPhone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.macleanofduartenterprises.phone.core.CarrierForwardingController
import com.macleanofduartenterprises.phone.core.CarrierForwardingResult
import com.macleanofduartenterprises.phone.core.VoicemailPreferences
import com.macleanofduartenterprises.phone.domain.entity.SimInfo
import com.macleanofduartenterprises.phone.util.PermissionChecker

private data class CarrierCodeStep(
    val code: String,
    val condition: VoicemailPreferences.ForwardingCondition,
)

private data class PendingCarrierCodeSequence(
    val steps: List<CarrierCodeStep>,
    val currentStepIndex: Int,
    val actionLabel: String,
    val sim: SimInfo,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoicemailSettingsScreen(
    onBackClick: () -> Unit,
    loadSims: () -> List<SimInfo>,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var settings by remember(context) { mutableStateOf(VoicemailPreferences.load(context)) }
    var message by remember { mutableStateOf<String?>(null) }
    var pendingCarrierCodes by remember { mutableStateOf<PendingCarrierCodeSequence?>(null) }
    var isSendingCarrierCode by remember { mutableStateOf(false) }
    var refreshToken by remember { mutableIntStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        refreshToken++
        message = if (
            PermissionChecker.hasCallPhonePermission(context) &&
            PermissionChecker.hasReadPhoneStatePermission(context)
        ) {
            "Phone access granted. Select the cellular SIM and try again."
        } else {
            "Phone and phone-state permissions are required for carrier forwarding."
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refreshToken++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val sims = remember(refreshToken) {
        loadSims().sortedBy(SimInfo::simSlotIndex)
    }
    val selectedSim = sims.firstOrNull { it.accountId == settings.forwardingAccountId }
        ?: sims.singleOrNull()

    LaunchedEffect(sims, settings.forwardingAccountId) {
        if (settings.forwardingAccountId.isBlank() && sims.size == 1) {
            settings = settings.copy(forwardingAccountId = sims.single().accountId)
        }
    }

    fun simLabel(sim: SimInfo): String =
        sim.displayName?.takeIf(String::isNotBlank) ?: "SIM ${sim.simSlotIndex + 1}"

    fun prepareCarrierCodes(steps: List<CarrierCodeStep>, actionLabel: String) {
        when {
            steps.isEmpty() -> {
                message = "Select at least one forwarding reason."
            }
            !PermissionChecker.hasCallPhonePermission(context) ||
                !PermissionChecker.hasReadPhoneStatePermission(context) -> {
                permissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_PHONE_STATE,
                    )
                )
            }
            selectedSim == null -> {
                message = "No physical cellular SIM is available for carrier forwarding."
            }
            else -> {
                val updated = settings.copy(forwardingAccountId = selectedSim.accountId)
                settings = updated
                VoicemailPreferences.save(context, updated)
                pendingCarrierCodes = PendingCarrierCodeSequence(
                    steps = steps,
                    currentStepIndex = 0,
                    actionLabel = actionLabel,
                    sim = selectedSim,
                )
            }
        }
    }

    fun dialNormally(value: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", value, null)))
        }.onFailure { message = "No phone app is available to dial this number." }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Voicemail & incoming forwarding") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Voicemail number")
            OutlinedTextField(
                value = settings.voicemailNumber,
                onValueChange = { settings = settings.copy(voicemailNumber = it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Phone number") },
                supportingText = { Text("The number used to retrieve your carrier voicemail") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
            )
            OutlinedButton(
                enabled = settings.voicemailNumber.isNotBlank(),
                onClick = { dialNormally(settings.voicemailNumber) },
            ) {
                Icon(Icons.Outlined.Call, contentDescription = null)
                Text("Call voicemail")
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Carrier call forwarding", modifier = Modifier.weight(1f))
                        Switch(
                            checked = settings.forwardingEnabled,
                            onCheckedChange = {
                                settings = settings.copy(forwardingEnabled = it)
                            },
                        )
                    }
                    Text(
                        "Forward incoming calls on a physical SIM to another number. Your carrier must support the selected forwarding code.",
                    )
                    Text(
                        "Google Voice can remain Android's Call redirecting app. Maclean Phone sends these incoming-forwarding codes directly through the selected SIM without changing Google Voice routing.",
                        style = MaterialTheme.typography.bodySmall,
                    )

                    Text("Cellular SIM")
                    if (sims.isEmpty()) {
                        Text(
                            "No physical SIM is available. Google Voice and other internet-calling accounts cannot activate carrier forwarding.",
                            color = MaterialTheme.colorScheme.error,
                        )
                        OutlinedButton(
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.CALL_PHONE,
                                        Manifest.permission.READ_PHONE_STATE,
                                    )
                                )
                            },
                        ) {
                            Text("Grant phone access")
                        }
                    } else {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            sims.forEach { sim ->
                                FilterChip(
                                    selected = selectedSim?.accountId == sim.accountId,
                                    onClick = {
                                        settings = settings.copy(
                                            forwardingAccountId = sim.accountId,
                                        )
                                    },
                                    label = { Text(simLabel(sim)) },
                                )
                            }
                        }
                        Text(
                            "The code will be sent directly through the selected physical SIM, not through Google Voice.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }

                    Text("Forward when (select one or more)")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoicemailPreferences.ForwardingCondition.entries.forEach { condition ->
                            FilterChip(
                                selected = condition in settings.forwardingConditions,
                                onClick = {
                                    settings = settings.copy(
                                        forwardingConditions = VoicemailPreferences.toggleCondition(
                                            settings.forwardingConditions,
                                            condition,
                                        ),
                                    )
                                },
                                label = { Text(condition.label) },
                            )
                        }
                    }
                    Text(
                        "Busy, unanswered, and unavailable may be selected together. All calls replaces conditional selections because it forwards before those conditions occur.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    OutlinedTextField(
                        value = settings.forwardingNumber,
                        onValueChange = { settings = settings.copy(forwardingNumber = it) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = settings.forwardingEnabled,
                        label = { Text("Forward-to phone number") },
                        supportingText = { Text("Include country code when required") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                    )
                    Button(
                        enabled = settings.forwardingEnabled &&
                            settings.forwardingNumber.any(Char::isDigit) &&
                            settings.forwardingConditions.isNotEmpty() &&
                            sims.isNotEmpty(),
                        onClick = {
                            prepareCarrierCodes(
                                VoicemailPreferences.selectedConditions(settings).map { condition ->
                                    CarrierCodeStep(
                                        code = VoicemailPreferences.activationCode(
                                            settings,
                                            condition,
                                        ),
                                        condition = condition,
                                    )
                                },
                                "Activate",
                            )
                        },
                    ) {
                        Icon(Icons.Outlined.PhoneForwarded, contentDescription = null)
                        Text("Activate forwarding through SIM")
                    }
                    OutlinedButton(
                        enabled = settings.forwardingConditions.isNotEmpty() && sims.isNotEmpty(),
                        onClick = {
                            prepareCarrierCodes(
                                VoicemailPreferences.selectedConditions(settings).map { condition ->
                                    CarrierCodeStep(
                                        code = VoicemailPreferences.deactivationCode(condition),
                                        condition = condition,
                                    )
                                },
                                "Turn off",
                            )
                        },
                    ) {
                        Text("Turn off forwarding through SIM")
                    }
                }
            }

            Button(
                onClick = {
                    val updated = selectedSim?.let {
                        settings.copy(forwardingAccountId = it.accountId)
                    } ?: settings
                    settings = updated
                    VoicemailPreferences.save(context, updated)
                    message = "Voicemail and forwarding choices saved."
                },
            ) { Text("Save settings") }

            OutlinedButton(
                onClick = {
                    runCatching {
                        context.startActivity(Intent(TelecomManager.ACTION_SHOW_CALL_SETTINGS))
                    }.onFailure {
                        message = "Carrier call settings are not available on this device."
                    }
                },
            ) {
                Icon(Icons.Outlined.SettingsPhone, contentDescription = null)
                Text("Open carrier call settings")
            }
            Text(
                "Maclean Phone sends each selected code directly to the physical SIM and displays the carrier response. When several reasons are selected, confirm each code in sequence. Your carrier decides whether each condition is supported and activated.",
            )
            Text("SIP/VoIP forwarding is configured separately under Business IVR.")
            message?.let { Text(it) }
        }
    }

    pendingCarrierCodes?.let { pending ->
        val step = pending.steps[pending.currentStepIndex]
        val stepNumber = pending.currentStepIndex + 1
        AlertDialog(
            onDismissRequest = {
                if (!isSendingCarrierCode) pendingCarrierCodes = null
            },
            title = { Text("${pending.actionLabel} selected call forwarding?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (pending.steps.size > 1) {
                        Text("Reason $stepNumber of ${pending.steps.size}")
                    }
                    Text(step.condition.label, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Send this carrier code through ${simLabel(pending.sim)}?",
                    )
                    Text(step.code, style = MaterialTheme.typography.titleMedium)
                    Text("Carrier forwarding charges and carrier-specific restrictions may apply.")
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isSendingCarrierCode,
                    onClick = {
                        val hasNextStep = stepNumber < pending.steps.size
                        isSendingCarrierCode = true
                        CarrierForwardingController.send(
                            context = context,
                            accountId = pending.sim.accountId,
                            carrierCode = step.code,
                        ) { result ->
                            isSendingCarrierCode = false
                            when (result) {
                                is CarrierForwardingResult.Success -> {
                                    pendingCarrierCodes = if (hasNextStep) {
                                        pending.copy(
                                            currentStepIndex = pending.currentStepIndex + 1,
                                        )
                                    } else {
                                        null
                                    }
                                    val response = result.networkResponse
                                        .takeIf(String::isNotBlank)
                                        ?.let { " Carrier response: $it" }
                                        .orEmpty()
                                    message = if (hasNextStep) {
                                        "Reason $stepNumber of ${pending.steps.size} completed through ${simLabel(pending.sim)}.$response Confirm the next reason when ready."
                                    } else {
                                        "All selected incoming-forwarding codes completed through ${simLabel(pending.sim)}.$response"
                                    }
                                }
                                is CarrierForwardingResult.Failure -> {
                                    pendingCarrierCodes = pending
                                    message = "${result.message} Google Voice routing was left unchanged. You can also use Open carrier call settings."
                                }
                            }
                        }
                    },
                ) {
                    Text(
                        when {
                            isSendingCarrierCode -> "Sending…"
                            stepNumber == 1 -> "Send code"
                            else -> "Send next code"
                        }
                    )
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isSendingCarrierCode,
                    onClick = { pendingCarrierCodes = null },
                ) {
                    Text("Cancel")
                }
            },
        )
    }
}
