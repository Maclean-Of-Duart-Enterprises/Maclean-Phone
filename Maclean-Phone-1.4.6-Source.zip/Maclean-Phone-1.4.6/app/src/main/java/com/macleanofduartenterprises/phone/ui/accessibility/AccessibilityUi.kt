package com.macleanofduartenterprises.phone.ui.accessibility

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.core.AccessibilityPreferences

val LocalAccessibilitySettings = staticCompositionLocalOf {
    AccessibilityPreferences.Snapshot()
}

val AccessibilityPreferences.Snapshot.minimumControlSize: Dp
    get() = if (largeControls) 72.dp else 48.dp

val AccessibilityPreferences.Snapshot.primaryCallControlSize: Dp
    get() = if (largeControls) 76.dp else 56.dp
