package com.macleanofduartenterprises.phone.core

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.telecom.Call
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo

/** Selects called-line metadata without ever falling back to the remote caller's number. */
internal object CalledLinePolicy {
    fun firstNonBlank(vararg candidates: String?): String =
        candidates.firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()

    fun withoutDuplicateLabel(number: String, label: String): String =
        label.takeUnless { number.isNotBlank() && it.equals(number, ignoreCase = true) }.orEmpty()

    fun notificationSummary(calledLine: CalledLineInfo): String? = when {
        calledLine.hasNumber && calledLine.hasAccountLabel ->
            "Called ${calledLine.number} via ${calledLine.accountLabel}"
        calledLine.hasNumber -> "Called ${calledLine.number}"
        calledLine.hasAccountLabel -> "Called line: ${calledLine.accountLabel}"
        else -> null
    }

    fun outgoingSummary(callingLine: CalledLineInfo): String? = when {
        callingLine.hasNumber && callingLine.hasAccountLabel ->
            "From ${callingLine.number} via ${callingLine.accountLabel}"
        callingLine.hasNumber -> "From ${callingLine.number}"
        callingLine.hasAccountLabel -> "From ${callingLine.accountLabel}"
        else -> null
    }
}

/**
 * Resolves the number/account receiving [call] from its Telecom PhoneAccount.
 * [Call.callerPhone] is intentionally not consulted, because that is the remote party.
 */
@SuppressLint("MissingPermission")
fun Context.resolveCalledLine(call: Call): CalledLineInfo {
    val handle = call.details.accountHandle ?: return CalledLineInfo.Unknown
    val fallbackAppLabel = phoneAccountApplicationLabel(handle)
    val canReadPhoneState = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.READ_PHONE_STATE,
    ) == PackageManager.PERMISSION_GRANTED
    val canReadPhoneNumbers = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.READ_PHONE_NUMBERS,
    ) == PackageManager.PERMISSION_GRANTED
    val canReadPhoneAccounts = canReadPhoneState || canReadPhoneNumbers
    val account = if (canReadPhoneAccounts) {
        runCatching {
            getSystemService(TelecomManager::class.java)?.getPhoneAccount(handle)
        }.getOrNull()
    } else {
        null
    }

    val number = CalledLinePolicy.firstNonBlank(
        account?.subscriptionAddress.displayValue(),
        account?.address.displayValue(),
    )
    val label = CalledLinePolicy.firstNonBlank(
        account?.label?.toString(),
        account?.shortDescription?.toString(),
        fallbackAppLabel,
    )
    return CalledLineInfo(
        number = number,
        accountLabel = CalledLinePolicy.withoutDuplicateLabel(number, label),
    )
}

/** Resolves the local identity used for an outgoing call without changing the remote callee. */
fun Context.resolveCallingLine(call: Call): CalledLineInfo = resolveCalledLine(call)

private fun Uri?.displayValue(): String {
    if (this == null) return ""
    val encodedValue = schemeSpecificPart?.takeIf(String::isNotBlank) ?: toString()
    return Uri.decode(encodedValue).trim()
}

@Suppress("DEPRECATION")
private fun Context.phoneAccountApplicationLabel(handle: PhoneAccountHandle): String =
    runCatching {
        val applicationInfo = packageManager.getApplicationInfo(
            handle.componentName.packageName,
            0,
        )
        packageManager.getApplicationLabel(applicationInfo).toString().trim()
    }.getOrDefault("")
