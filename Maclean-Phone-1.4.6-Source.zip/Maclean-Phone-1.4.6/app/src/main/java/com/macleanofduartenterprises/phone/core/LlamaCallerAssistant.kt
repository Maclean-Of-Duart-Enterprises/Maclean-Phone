package com.macleanofduartenterprises.phone.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.telephony.PhoneNumberUtils
import androidx.core.content.ContextCompat
import com.macleanofduartenterprises.phone.domain.repo.BlockedNumberRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

enum class CallerCategory {
    BLOCKED,
    LIKELY_SPAM,
    CAUTION,
    KNOWN,
    UNKNOWN,
}

data class CallerAssessment(
    val category: CallerCategory,
    val displayLabel: String,
    val explanation: String,
    val riskScore: Int,
    val modelName: String = LlamaCallerRiskModel.MODEL_NAME,
) {
    val shouldSilence: Boolean
        get() = category == CallerCategory.LIKELY_SPAM && riskScore >= 80

    companion object {
        val Unavailable = CallerAssessment(
            category = CallerCategory.UNKNOWN,
            displayLabel = "Caller information unavailable",
            explanation = "No phone number was supplied.",
            riskScore = 0,
        )
    }
}

data class CallerSignals(
    val isBlocked: Boolean = false,
    val isSavedContact: Boolean = false,
    val isAnonymous: Boolean = false,
    val isTollFree: Boolean = false,
    val hasCachedSpamLabel: Boolean = false,
    val connectedCallCount: Int = 0,
    val outgoingCallCount: Int = 0,
    val recentMissedCallCount: Int = 0,
    val digitCount: Int = 0,
)

/**
 * Compact, deterministic caller-intelligence model used by Llama Local.
 *
 * The model uses only on-device signals. It performs no network requests and
 * never uploads phone numbers, contacts, or call history.
 */
object LlamaCallerRiskModel {
    const val MODEL_NAME = "Llama Local Caller Intelligence 1.0"

    fun assess(signals: CallerSignals): CallerAssessment {
        if (signals.isBlocked) {
            return CallerAssessment(
                category = CallerCategory.BLOCKED,
                displayLabel = "Blocked caller",
                explanation = "This number is in your Maclean Phone blocked list.",
                riskScore = 100,
            )
        }
        if (signals.isSavedContact) {
            return CallerAssessment(
                category = CallerCategory.KNOWN,
                displayLabel = "Saved contact",
                explanation = "This number matches a contact stored on your phone.",
                riskScore = 0,
            )
        }
        if (signals.hasCachedSpamLabel) {
            return CallerAssessment(
                category = CallerCategory.LIKELY_SPAM,
                displayLabel = "Likely spam",
                explanation = "Android's local call history contains a spam label for this caller.",
                riskScore = 96,
            )
        }

        var risk = 22
        val reasons = mutableListOf<String>()
        when {
            signals.isAnonymous -> {
                risk += 63
                reasons += "The caller hid or did not provide a usable number."
            }
            signals.digitCount in 1..6 -> {
                risk += 28
                reasons += "The caller number is unusually short."
            }
        }
        if (signals.recentMissedCallCount >= 3) {
            risk += 40
            reasons += "This number made several recent unanswered calls."
        } else if (signals.recentMissedCallCount == 2) {
            risk += 18
            reasons += "This number made repeated recent calls."
        }
        if (signals.connectedCallCount > 0) {
            risk -= 28
            reasons += "You previously completed a call with this number."
        }
        if (signals.outgoingCallCount > 0) {
            risk -= 25
            reasons += "You previously called this number."
        }
        if (signals.isTollFree) {
            risk -= 2
            reasons += "This appears to be a North American toll-free number."
        }
        risk = risk.coerceIn(0, 100)

        val category = when {
            risk >= 80 -> CallerCategory.LIKELY_SPAM
            risk >= 55 -> CallerCategory.CAUTION
            signals.connectedCallCount > 0 || signals.outgoingCallCount > 0 ->
                CallerCategory.KNOWN
            else -> CallerCategory.UNKNOWN
        }
        val label = when (category) {
            CallerCategory.BLOCKED -> "Blocked caller"
            CallerCategory.LIKELY_SPAM -> "Likely spam"
            CallerCategory.CAUTION -> "Use caution"
            CallerCategory.KNOWN -> "Known caller"
            CallerCategory.UNKNOWN -> if (signals.isTollFree) {
                "Toll-free caller"
            } else {
                "Unknown caller"
            }
        }
        return CallerAssessment(
            category = category,
            displayLabel = label,
            explanation = reasons.firstOrNull()
                ?: "No strong spam or trust signal was found in local phone data.",
            riskScore = risk,
        )
    }
}

@Singleton
class LlamaCallerAssistant @Inject constructor(
    @ApplicationContext private val context: Context,
    private val blockedNumberRepository: BlockedNumberRepository,
) {
    private data class CacheEntry(val createdAt: Long, val assessment: CallerAssessment)

    private val cache = ConcurrentHashMap<String, CacheEntry>()

    fun assess(rawPhone: String): CallerAssessment {
        if (!PhoneSettingsPrefs.llamaCallerAssistantEnabled(context)) {
            return CallerAssessment(
                category = CallerCategory.UNKNOWN,
                displayLabel = "Llama Local is off",
                explanation = "Enable the local caller assistant in Caller ID & spam settings.",
                riskScore = 0,
            )
        }
        val cacheKey = rawPhone.trim()
        if (cacheKey.isBlank()) return LlamaCallerRiskModel.assess(
            CallerSignals(isAnonymous = true, digitCount = 0)
        )
        cache[cacheKey]?.takeIf {
            System.currentTimeMillis() - it.createdAt <= CACHE_MILLIS
        }?.let { return it.assessment }

        val normalized = PhoneNumberUtils.normalizeNumber(rawPhone).orEmpty()
        val digits = normalized.filter(Char::isDigit)
        val history = readHistory(rawPhone)
        val assessment = LlamaCallerRiskModel.assess(
            CallerSignals(
                isBlocked = blockedNumberRepository.isBlocked(rawPhone),
                isSavedContact = hasSavedContact(rawPhone),
                isAnonymous = digits.isBlank(),
                isTollFree = digits.isNorthAmericanTollFree(),
                hasCachedSpamLabel = history.hasCachedSpamLabel,
                connectedCallCount = history.connectedCallCount,
                outgoingCallCount = history.outgoingCallCount,
                recentMissedCallCount = history.recentMissedCallCount,
                digitCount = digits.length,
            )
        )
        cache[cacheKey] = CacheEntry(System.currentTimeMillis(), assessment)
        return assessment
    }

    fun invalidate(rawPhone: String? = null) {
        if (rawPhone == null) cache.clear() else cache.remove(rawPhone.trim())
    }

    private fun hasSavedContact(phone: String): Boolean {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        return runCatching {
            val lookupUri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phone),
            )
            context.contentResolver.query(
                lookupUri,
                arrayOf(ContactsContract.PhoneLookup._ID),
                null,
                null,
                null,
            )?.use { it.moveToFirst() } ?: false
        }.getOrDefault(false)
    }

    private data class HistorySignals(
        val connectedCallCount: Int,
        val outgoingCallCount: Int,
        val recentMissedCallCount: Int,
        val hasCachedSpamLabel: Boolean,
    )

    private fun readHistory(phone: String): HistorySignals {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return HistorySignals(0, 0, 0, false)
        }
        return runCatching {
            var connected = 0
            var outgoing = 0
            var recentMissed = 0
            var cachedSpam = false
            val recentThreshold = System.currentTimeMillis() - RECENT_WINDOW_MILLIS
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DATE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.CACHED_NAME,
                ),
                "${CallLog.Calls.NUMBER} = ?",
                arrayOf(phone),
                "${CallLog.Calls.DATE} DESC LIMIT 20",
            )?.use { cursor ->
                val typeIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE)
                val dateIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.DATE)
                val durationIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION)
                val nameIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
                while (cursor.moveToNext()) {
                    val type = cursor.getInt(typeIndex)
                    val duration = cursor.getLong(durationIndex)
                    val date = cursor.getLong(dateIndex)
                    if (duration > 0L) connected++
                    if (type == CallLog.Calls.OUTGOING_TYPE) outgoing++
                    if (
                        date >= recentThreshold &&
                        (type == CallLog.Calls.MISSED_TYPE ||
                            type == CallLog.Calls.REJECTED_TYPE)
                    ) {
                        recentMissed++
                    }
                    if (cursor.getString(nameIndex).orEmpty().contains("spam", ignoreCase = true)) {
                        cachedSpam = true
                    }
                }
            }
            HistorySignals(connected, outgoing, recentMissed, cachedSpam)
        }.getOrDefault(HistorySignals(0, 0, 0, false))
    }

    private fun String.isNorthAmericanTollFree(): Boolean {
        val national = when (length) {
            10 -> this
            11 -> if (startsWith("1")) drop(1) else return false
            else -> return false
        }
        return national.take(3) in setOf("800", "833", "844", "855", "866", "877", "888")
    }

    companion object {
        private const val CACHE_MILLIS = 30_000L
        private const val RECENT_WINDOW_MILLIS = 48L * 60L * 60L * 1000L
    }
}
