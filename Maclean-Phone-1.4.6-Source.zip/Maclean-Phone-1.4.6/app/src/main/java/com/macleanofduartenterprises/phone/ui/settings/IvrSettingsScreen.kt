package com.macleanofduartenterprises.phone.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.macleanofduartenterprises.phone.ivr.DirectoryAction
import com.macleanofduartenterprises.phone.ivr.DirectoryEntry
import com.macleanofduartenterprises.phone.ivr.CallForwardingTargetType
import com.macleanofduartenterprises.phone.ivr.IvrConfig
import com.macleanofduartenterprises.phone.ivr.IvrLanguage
import com.macleanofduartenterprises.phone.ivr.IvrMenuRouter
import com.macleanofduartenterprises.phone.ivr.IvrPromptBuilder
import com.macleanofduartenterprises.phone.ivr.IvrRouteCommand
import com.macleanofduartenterprises.phone.ivr.IvrServicePhase
import com.macleanofduartenterprises.phone.ivr.SipTransport

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IvrSettingsScreen(
    onBackClick: () -> Unit,
    vm: IvrSettingsViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val config = state.config
    var editingEntry by remember { mutableStateOf<DirectoryEntry?>(null) }
    var originalDigit by remember { mutableStateOf<String?>(null) }
    var showEntryDialog by remember { mutableStateOf(false) }
    var showSimulator by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Business IVR") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                StatusCard(state)
            }

            item {
                SectionTitle("SIP account")
                Text(
                    text = "Enter the registration details supplied by your VoIP provider. " +
                        "Your password is encrypted with Android Keystore.",
                    modifier = Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            item {
                IvrTextField(
                    value = config.sipServer,
                    onValueChange = { vm.updateConfig(config.copy(sipServer = it)) },
                    label = "SIP server",
                    supporting = "Example: sip.provider.com"
                )
            }
            item {
                IvrTextField(
                    value = config.sipDomain,
                    onValueChange = { vm.updateConfig(config.copy(sipDomain = it)) },
                    label = "SIP domain",
                    supporting = "Leave blank only when it is the same as the server"
                )
            }
            item {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        modifier = Modifier.weight(1f),
                        value = config.sipPort.toString(),
                        onValueChange = {
                            vm.updateConfig(config.copy(sipPort = it.filter(Char::isDigit).toIntOrNull() ?: 0))
                        },
                        label = { Text("Port") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                FlowRow(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SipTransport.entries.forEach { transport ->
                        FilterChip(
                            selected = config.transport == transport,
                            onClick = {
                                val defaultPort = if (transport == SipTransport.TLS) 5061 else 5060
                                vm.updateConfig(config.copy(transport = transport, sipPort = defaultPort))
                            },
                            label = { Text(transport.name) }
                        )
                    }
                }
            }
            item {
                IvrTextField(
                    value = config.username,
                    onValueChange = { vm.updateConfig(config.copy(username = it)) },
                    label = "SIP username / extension"
                )
            }
            item {
                IvrTextField(
                    value = config.authUsername,
                    onValueChange = { vm.updateConfig(config.copy(authUsername = it)) },
                    label = "Authorization username",
                    supporting = "Optional; defaults to the SIP username"
                )
            }
            item {
                OutlinedTextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    value = state.password,
                    onValueChange = vm::updatePassword,
                    label = { Text("SIP password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
            }
            item {
                IvrTextField(
                    value = config.outboundProxy,
                    onValueChange = { vm.updateConfig(config.copy(outboundProxy = it)) },
                    label = "Outbound proxy",
                    supporting = "Optional"
                )
            }
            item {
                IvrTextField(
                    value = config.displayName,
                    onValueChange = { vm.updateConfig(config.copy(displayName = it)) },
                    label = "Line display name"
                )
            }

            item {
                SectionTitle("Incoming SIP call forwarding")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Forward every incoming VoIP call")
                        Text(
                            "When on, the IVR menu is bypassed.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(
                        checked = config.callForwardingEnabled,
                        onCheckedChange = {
                            vm.updateConfig(config.copy(callForwardingEnabled = it))
                        },
                    )
                }
            }
            if (config.callForwardingEnabled) {
                item {
                    FlowRow(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = config.callForwardingTargetType ==
                                CallForwardingTargetType.PHONE_NUMBER,
                            onClick = {
                                vm.updateConfig(
                                    config.copy(
                                        callForwardingTargetType =
                                            CallForwardingTargetType.PHONE_NUMBER
                                    )
                                )
                            },
                            label = { Text("Phone number") },
                        )
                        FilterChip(
                            selected = config.callForwardingTargetType ==
                                CallForwardingTargetType.SIP_DESTINATION,
                            onClick = {
                                vm.updateConfig(
                                    config.copy(
                                        callForwardingTargetType =
                                            CallForwardingTargetType.SIP_DESTINATION
                                    )
                                )
                            },
                            label = { Text("SIP address / extension") },
                        )
                    }
                }
                item {
                    if (config.callForwardingTargetType ==
                        CallForwardingTargetType.PHONE_NUMBER
                    ) {
                        IvrTextField(
                            value = config.callForwardingPhoneNumber,
                            onValueChange = {
                                vm.updateConfig(config.copy(callForwardingPhoneNumber = it))
                            },
                            label = "Forward-to phone number",
                            supporting = "Include the country code. Your SIP provider must allow PSTN transfers.",
                        )
                    } else {
                        IvrTextField(
                            value = config.callForwardingSipDestination,
                            onValueChange = {
                                vm.updateConfig(config.copy(callForwardingSipDestination = it))
                            },
                            label = "SIP destination or extension",
                            supporting = "Example: 101 or sip:reception@example.com",
                        )
                    }
                }
            }

            item { SectionTitle("Language greeting") }
            item {
                IvrTextField(
                    value = config.englishGreeting,
                    onValueChange = { vm.updateConfig(config.copy(englishGreeting = it)) },
                    label = "English greeting",
                    supporting = "“Press 1 for English” is appended automatically",
                    singleLine = false
                )
            }
            item {
                IvrTextField(
                    value = config.russianGreeting,
                    onValueChange = { vm.updateConfig(config.copy(russianGreeting = it)) },
                    label = "Russian greeting",
                    supporting = "“Press 2 for Russian” is appended automatically",
                    singleLine = false
                )
            }

            item {
                SectionTitle("Directory")
                Text(
                    text = "After callers choose 1 for English or 2 for Russian, these " +
                        "numbers transfer, repeat the menu, or end the call.",
                    modifier = Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (config.directory.isEmpty()) {
                item {
                    Text(
                        text = "No directory entries yet.",
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            items(config.directory, key = { it.digit }) { entry ->
                DirectoryEntryRow(
                    entry = entry,
                    onEdit = {
                        editingEntry = entry
                        originalDigit = entry.digit
                        showEntryDialog = true
                    },
                    onDelete = { vm.removeDirectoryEntry(entry.digit) }
                )
            }

            item {
                FlowRow(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            editingEntry = null
                            originalDigit = null
                            showEntryDialog = true
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("Add entry")
                    }
                    OutlinedButton(
                        onClick = { showSimulator = true },
                        enabled = config.directory.isNotEmpty()
                    ) {
                        Icon(Icons.Default.PhoneInTalk, contentDescription = null)
                        Text("Test menu")
                    }
                }
            }

            item { SectionTitle("Call behavior") }
            item {
                NumberSetting(
                    label = "Answer delay (seconds)",
                    value = config.answerDelaySeconds,
                    onValueChange = { vm.updateConfig(config.copy(answerDelaySeconds = it)) }
                )
            }
            item {
                NumberSetting(
                    label = "Input timeout (seconds)",
                    value = config.noInputTimeoutSeconds,
                    onValueChange = { vm.updateConfig(config.copy(noInputTimeoutSeconds = it)) }
                )
            }
            item {
                NumberSetting(
                    label = "Attempts before fallback",
                    value = config.maxInvalidAttempts,
                    onValueChange = { vm.updateConfig(config.copy(maxInvalidAttempts = it)) }
                )
            }
            item {
                IvrTextField(
                    value = config.fallbackDestination,
                    onValueChange = { vm.updateConfig(config.copy(fallbackDestination = it)) },
                    label = "Fallback extension",
                    supporting = "Optional; the call ends when blank"
                )
            }

            if (state.validationErrors.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            text = state.validationErrors.joinToString("\n") { "• $it" },
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            state.message?.let { message ->
                item {
                    Text(
                        text = message,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 32.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = vm::save, enabled = state.dirty) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Text("Save")
                    }
                    Button(
                        onClick = vm::saveAndStart,
                        enabled = state.validationErrors.isEmpty()
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Text(if (config.enabled) "Save & restart" else "Save & start")
                    }
                    if (config.enabled) {
                        OutlinedButton(onClick = vm::stop) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Text("Stop")
                        }
                    }
                }
            }
        }
    }

    if (showEntryDialog) {
        DirectoryEntryDialog(
            entry = editingEntry,
            onDismiss = { showEntryDialog = false },
            onSave = { entry ->
                vm.upsertDirectoryEntry(originalDigit, entry)
                showEntryDialog = false
            }
        )
    }

    if (showSimulator) {
        IvrSimulatorDialog(
            config = config,
            onDismiss = { showSimulator = false }
        )
    }
}

@Composable
private fun StatusCard(state: IvrSettingsUiState) {
    val isError = state.runtimeStatus.phase == IvrServicePhase.ERROR
    val isReady = state.runtimeStatus.phase == IvrServicePhase.REGISTERED
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isError -> MaterialTheme.colorScheme.errorContainer
                isReady -> MaterialTheme.colorScheme.primaryContainer
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = state.runtimeStatus.phase.name.replace('_', ' '),
                style = MaterialTheme.typography.titleMedium
            )
            Text(state.runtimeStatus.detail)
            state.runtimeStatus.caller?.let { Text("Caller: $it") }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
        style = MaterialTheme.typography.titleLarge
    )
}

@Composable
private fun IvrTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    supporting: String? = null,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        supportingText = supporting?.let { { Text(it) } },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 2
    )
}

@Composable
private fun NumberSetting(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit
) {
    OutlinedTextField(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        value = value.toString(),
        onValueChange = {
            onValueChange(it.filter(Char::isDigit).toIntOrNull() ?: 0)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
private fun DirectoryEntryRow(
    entry: DirectoryEntry,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable(onClick = onEdit)
    ) {
        ListItem(
            headlineContent = {
                Text("${entry.digit} — ${entry.englishLabel} / ${entry.russianLabel}")
            },
            supportingContent = {
                Text(
                    when (entry.action) {
                        DirectoryAction.TRANSFER -> "Transfer to ${entry.destination}"
                        DirectoryAction.REPEAT_MENU -> "Repeat the directory"
                        DirectoryAction.HANG_UP -> "End the call"
                    }
                )
            },
            trailingContent = {
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit entry")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete entry")
                    }
                }
            }
        )
    }
}

@Composable
private fun DirectoryEntryDialog(
    entry: DirectoryEntry?,
    onDismiss: () -> Unit,
    onSave: (DirectoryEntry) -> Unit
) {
    var digit by remember(entry) { mutableStateOf(entry?.digit.orEmpty()) }
    var englishLabel by remember(entry) { mutableStateOf(entry?.englishLabel.orEmpty()) }
    var russianLabel by remember(entry) { mutableStateOf(entry?.russianLabel.orEmpty()) }
    var destination by remember(entry) { mutableStateOf(entry?.destination.orEmpty()) }
    var action by remember(entry) { mutableStateOf(entry?.action ?: DirectoryAction.TRANSFER) }
    val valid = digit.singleOrNull() in IvrConfig.VALID_DIRECTORY_DIGITS &&
        englishLabel.isNotBlank() &&
        russianLabel.isNotBlank() &&
        (action != DirectoryAction.TRANSFER || destination.isNotBlank())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (entry == null) "Add directory entry" else "Edit directory entry") },
        text = {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = digit,
                    onValueChange = { newValue ->
                        digit = newValue.filter { it in IvrConfig.VALID_DIRECTORY_DIGITS }.take(1)
                    },
                    label = { Text("Caller presses") },
                    supportingText = { Text("0–9 or #. Star is reserved for repeat.") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = englishLabel,
                    onValueChange = { englishLabel = it },
                    label = { Text("English label") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = russianLabel,
                    onValueChange = { russianLabel = it },
                    label = { Text("Russian label") },
                    singleLine = true
                )
                Text("Action", style = MaterialTheme.typography.labelLarge)
                DirectoryAction.entries.forEach { candidate ->
                    FilterChip(
                        selected = action == candidate,
                        onClick = { action = candidate },
                        label = {
                            Text(
                                when (candidate) {
                                    DirectoryAction.TRANSFER -> "Transfer"
                                    DirectoryAction.REPEAT_MENU -> "Repeat menu"
                                    DirectoryAction.HANG_UP -> "Hang up"
                                }
                            )
                        }
                    )
                }
                if (action == DirectoryAction.TRANSFER) {
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        label = { Text("Extension or SIP address") },
                        supportingText = { Text("Example: 101 or sip:agent@example.com") },
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        DirectoryEntry(
                            digit = digit,
                            englishLabel = englishLabel.trim(),
                            russianLabel = russianLabel.trim(),
                            action = action,
                            destination = destination.trim()
                        )
                    )
                },
                enabled = valid
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun IvrSimulatorDialog(
    config: IvrConfig,
    onDismiss: () -> Unit
) {
    var router by remember(config) { mutableStateOf(IvrMenuRouter(config)) }
    var output by remember(config) {
        mutableStateOf(
            "${IvrPromptBuilder.languageEnglish(config)}\n\n" +
                IvrPromptBuilder.languageRussian(config)
        )
    }

    fun press(digit: Char) {
        val decision = router.accept(digit)
        output = when (decision.command) {
            IvrRouteCommand.PLAY_LANGUAGE_MENU ->
                "${IvrPromptBuilder.languageEnglish(config)}\n\n" +
                    IvrPromptBuilder.languageRussian(config)

            IvrRouteCommand.PLAY_DIRECTORY ->
                IvrPromptBuilder.directory(
                    config,
                    decision.language ?: IvrLanguage.ENGLISH
                )

            IvrRouteCommand.TRANSFER -> "Transfer to ${decision.destination}"
            IvrRouteCommand.HANG_UP -> "End the call"
        }
        if (decision.invalidSelection) {
            output = "Invalid selection.\n\n$output"
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Caller menu test") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(output)
                listOf(
                    listOf('1', '2', '3'),
                    listOf('4', '5', '6'),
                    listOf('7', '8', '9'),
                    listOf('*', '0', '#')
                ).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        row.forEach { digit ->
                            AssistChip(
                                onClick = { press(digit) },
                                label = { Text(digit.toString()) }
                            )
                        }
                    }
                }
                OutlinedButton(
                    onClick = {
                        router = IvrMenuRouter(config)
                        output = "${IvrPromptBuilder.languageEnglish(config)}\n\n" +
                            IvrPromptBuilder.languageRussian(config)
                    }
                ) {
                    Text("Reset")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}
