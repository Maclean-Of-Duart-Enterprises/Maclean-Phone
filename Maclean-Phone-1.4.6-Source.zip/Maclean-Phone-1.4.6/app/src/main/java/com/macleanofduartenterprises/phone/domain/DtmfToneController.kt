package com.macleanofduartenterprises.phone.domain

interface DtmfToneGenerator {
    fun startTone(digit: Char)
    fun stopTone()
}