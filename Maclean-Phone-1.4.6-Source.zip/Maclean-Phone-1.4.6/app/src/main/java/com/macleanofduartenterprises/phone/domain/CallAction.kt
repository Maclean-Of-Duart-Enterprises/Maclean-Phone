package com.macleanofduartenterprises.phone.domain

sealed class CallAction {
    object Answer : CallAction()
    object Hangup : CallAction()
    data class Hold(val enabled: Boolean) : CallAction()
    data class Mute(val enabled: Boolean) : CallAction()
    data class Speaker(val enabled: Boolean) : CallAction()
    data class StartDialTone(val char: Char) : CallAction()
    data object StopDialTone : CallAction()
    data class AddCall(val phone: String) : CallAction()
    data object MergeCalls : CallAction()
    data object SwapCalls : CallAction()
    data class FocusCall(val callId: String) : CallAction()
    data class SeparateFromConference(val callId: String) : CallAction()
    data class DisconnectParticipant(val callId: String) : CallAction()
    data object ClearGroupCallMessage : CallAction()
}
