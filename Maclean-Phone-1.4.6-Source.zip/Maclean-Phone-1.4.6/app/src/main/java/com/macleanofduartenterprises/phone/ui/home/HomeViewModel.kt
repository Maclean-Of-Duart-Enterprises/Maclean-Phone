package com.macleanofduartenterprises.phone.ui.home

import androidx.lifecycle.ViewModel
import com.macleanofduartenterprises.phone.domain.entity.SimInfo
import com.macleanofduartenterprises.phone.domain.repo.SimInfoProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val simInfoProvider: SimInfoProvider
) : ViewModel() {

    fun getSimsInfo(): List<SimInfo> = simInfoProvider.getSimsInfo()
}
