package com.macleanofduartenterprises.phone.ivr

import kotlinx.serialization.Serializable

@Serializable
enum class SipTransport {
    TLS,
    TCP,
    UDP
}

@Serializable
enum class DirectoryAction {
    TRANSFER,
    REPEAT_MENU,
    HANG_UP
}

@Serializable
enum class CallForwardingTargetType {
    PHONE_NUMBER,
    SIP_DESTINATION,
}

@Serializable
data class DirectoryEntry(
    val digit: String,
    val englishLabel: String,
    val russianLabel: String,
    val action: DirectoryAction = DirectoryAction.TRANSFER,
    val destination: String = ""
)

@Serializable
data class IvrConfig(
    val enabled: Boolean = false,
    val sipServer: String = "",
    val sipDomain: String = "",
    val sipPort: Int = 5061,
    val transport: SipTransport = SipTransport.TLS,
    val username: String = "",
    val authUsername: String = "",
    val outboundProxy: String = "",
    val displayName: String = "Maclean Phone",
    val callForwardingEnabled: Boolean = false,
    val callForwardingTargetType: CallForwardingTargetType =
        CallForwardingTargetType.PHONE_NUMBER,
    val callForwardingPhoneNumber: String = "",
    val callForwardingSipDestination: String = "",
    val englishGreeting: String = "Thank you for calling.",
    val russianGreeting: String = "Спасибо за ваш звонок.",
    val answerDelaySeconds: Int = 1,
    val noInputTimeoutSeconds: Int = 15,
    val maxInvalidAttempts: Int = 3,
    val fallbackDestination: String = "",
    val directory: List<DirectoryEntry> = emptyList()
) {
    fun normalized(): IvrConfig = copy(
        sipServer = sipServer.trim()
            .removePrefix("sip:")
            .removePrefix("sips:")
            .trimEnd('/'),
        sipDomain = sipDomain.trim()
            .removePrefix("sip:")
            .removePrefix("sips:")
            .trimEnd('/'),
        username = username.trim(),
        authUsername = authUsername.trim(),
        outboundProxy = outboundProxy.trim(),
        displayName = displayName.trim(),
        callForwardingPhoneNumber = normalizePhoneNumber(callForwardingPhoneNumber),
        callForwardingSipDestination = callForwardingSipDestination.trim(),
        englishGreeting = englishGreeting.trim(),
        russianGreeting = russianGreeting.trim(),
        answerDelaySeconds = answerDelaySeconds.coerceIn(0, 30),
        noInputTimeoutSeconds = noInputTimeoutSeconds.coerceIn(5, 60),
        maxInvalidAttempts = maxInvalidAttempts.coerceIn(1, 9),
        fallbackDestination = fallbackDestination.trim(),
        directory = directory
            .map {
                it.copy(
                    digit = it.digit.trim().take(1),
                    englishLabel = it.englishLabel.trim(),
                    russianLabel = it.russianLabel.trim(),
                    destination = it.destination.trim()
                )
            }
            .sortedBy { it.digit }
    )

    fun validationErrors(password: String): List<String> {
        val config = normalized()
        return buildList {
            if (config.sipServer.isBlank()) add("SIP server is required.")
            if (config.domain.isBlank()) add("SIP domain is required.")
            if (config.sipPort !in 1..65535) add("SIP port must be between 1 and 65535.")
            if (config.username.isBlank()) add("SIP username is required.")
            if (password.isBlank()) add("SIP password is required.")
            if (!config.callForwardingEnabled && config.directory.isEmpty()) {
                add("Add at least one directory entry.")
            }
            if (config.callForwardingEnabled) {
                when (config.callForwardingTargetType) {
                    CallForwardingTargetType.PHONE_NUMBER -> {
                        if (config.callForwardingPhoneNumber.count(Char::isDigit) < 3) {
                            add("Enter a valid forwarding phone number.")
                        }
                    }

                    CallForwardingTargetType.SIP_DESTINATION -> {
                        if (config.callForwardingSipDestination.isBlank()) {
                            add("Enter a SIP forwarding destination.")
                        }
                    }
                }
            }
            val duplicateDigits = config.directory
                .groupingBy { it.digit }
                .eachCount()
                .filterValues { it > 1 }
                .keys
            if (duplicateDigits.isNotEmpty()) {
                add("Each directory digit must be unique.")
            }
            config.directory.forEach { entry ->
                if (entry.digit.length != 1 || entry.digit.first() !in VALID_DIRECTORY_DIGITS) {
                    add("Directory digits must be 0–9 or #.")
                }
                if (entry.englishLabel.isBlank() || entry.russianLabel.isBlank()) {
                    add("Every directory entry needs English and Russian labels.")
                }
                if (entry.action == DirectoryAction.TRANSFER && entry.destination.isBlank()) {
                    add("Every transfer entry needs a SIP extension or address.")
                }
            }
        }.distinct()
    }

    val domain: String
        get() = sipDomain.ifBlank {
            sipServer
                .substringBefore(':')
                .substringBefore(';')
        }

    fun forwardingDestination(): String = when (callForwardingTargetType) {
        CallForwardingTargetType.PHONE_NUMBER -> callForwardingPhoneNumber
        CallForwardingTargetType.SIP_DESTINATION -> callForwardingSipDestination
    }

    companion object {
        val VALID_DIRECTORY_DIGITS = ('0'..'9').toSet() + '#'

        fun normalizePhoneNumber(value: String): String {
            val trimmed = value.trim()
            val hasLeadingPlus = trimmed.startsWith('+')
            val digits = trimmed.filter(Char::isDigit)
            return if (hasLeadingPlus && digits.isNotBlank()) "+$digits" else digits
        }
    }
}

enum class IvrLanguage {
    ENGLISH,
    RUSSIAN
}

enum class IvrMenuStage {
    LANGUAGE,
    DIRECTORY,
    COMPLETE
}

enum class IvrRouteCommand {
    PLAY_LANGUAGE_MENU,
    PLAY_DIRECTORY,
    TRANSFER,
    HANG_UP
}

data class IvrRouteDecision(
    val command: IvrRouteCommand,
    val language: IvrLanguage? = null,
    val destination: String = "",
    val invalidSelection: Boolean = false
)

enum class IvrServicePhase {
    STOPPED,
    STARTING,
    PREPARING_VOICES,
    REGISTERING,
    REGISTERED,
    ANSWERING,
    IN_CALL,
    TRANSFERRING,
    ERROR
}

data class IvrRuntimeStatus(
    val phase: IvrServicePhase = IvrServicePhase.STOPPED,
    val detail: String = "IVR is off",
    val caller: String? = null
)
