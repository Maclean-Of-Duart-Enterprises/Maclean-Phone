package com.macleanofduartenterprises.phone.core

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.Call
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.app.ActivityCompat
import androidx.core.content.getSystemService

/**
 * Created by Muhammad Usman : msusman97@gmail.com on 11/17/2023.
 */


fun Call.callerName(): String {
    return this.details.callerDisplayName?.takeIf { it.isNotEmpty() } ?: "Unknown"

}

fun Call.callerPhone(): String {
    val address = details.gatewayInfo?.originalAddress ?: details.handle ?: return ""
    return Uri.decode(address.schemeSpecificPart.orEmpty())
}

@SuppressLint("MissingPermission")
fun Context.hasDefaultCallingSimConfigured(): Boolean {
    val telecomManager = this.getSystemService<TelecomManager>() ?: return false
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        runCatching {
            telecomManager.userSelectedOutgoingPhoneAccount != null
        }.getOrDefault(false)
    } else {
        runCatching {
            SubscriptionManager.getDefaultVoiceSubscriptionId() !=
                    SubscriptionManager.INVALID_SUBSCRIPTION_ID
        }.getOrDefault(false)
    }
}

fun Context.dial(phone: String, accountKey: String? = null): Boolean {
    val telecomManager = this.getSystemService<TelecomManager>() ?: return false
    var accountHandle: PhoneAccountHandle? = null
    if (accountKey != null) {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE,
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        val matchingHandle: PhoneAccountHandle? =
            CallingAccountCatalog.resolve(this, accountKey)?.handle
        if (matchingHandle == null) return false
        accountHandle = matchingHandle
    }
    return placePhoneCall(phone, accountHandle)
}

/** Places an additional Telecom call through the account that owns the live call. */
fun Context.dialAdditionalCall(phone: String, accountHandle: PhoneAccountHandle?): Boolean =
    placePhoneCall(phone, accountHandle)

private fun Context.placePhoneCall(
    phone: String,
    accountHandle: PhoneAccountHandle?,
): Boolean {
    val telecomManager = getSystemService<TelecomManager>() ?: return false
    val cleanedPhone = phone.trim()
    if (cleanedPhone.isEmpty()) return false
    val assistedPhone = PhoneSettingsPrefs.applyAssistedDialing(this, cleanedPhone)
    val uri = Uri.fromParts("tel", assistedPhone, null)
    val extras = Bundle().apply {
        putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, false)
        if (accountHandle != null) {
            putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, accountHandle)
        }
    }
    if (ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED
    ) {
        return false
    }
    return runCatching { telecomManager.placeCall(uri, extras) }.isSuccess
}


fun Int.toSimStateReadable(): String {
    return when (this) {
        TelephonyManager.SIM_STATE_ABSENT -> "No Sim available"
        TelephonyManager.SIM_STATE_CARD_IO_ERROR -> "Card Io error"
        TelephonyManager.SIM_STATE_CARD_RESTRICTED -> "Sim card restricted"
        TelephonyManager.SIM_STATE_NETWORK_LOCKED -> "Network locked"
        TelephonyManager.SIM_STATE_NOT_READY -> "Sim not ready"
        TelephonyManager.SIM_STATE_PERM_DISABLED -> "PERM disabled"
        TelephonyManager.SIM_STATE_PIN_REQUIRED -> "PIN Required"
        TelephonyManager.SIM_STATE_PUK_REQUIRED -> "PUK Required"
        TelephonyManager.SIM_STATE_READY -> "Sim is ready"
        else -> "Unknown"
    }
}

val Call.stateCompat: Int
    get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) this.details.state else this.state
