package com.macleanofduartenterprises.phone.core

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/**
 * Accessibility and call-audio choices owned by Maclean Phone.
 *
 * Cellular modem noise processing is not exposed by Android. The noise-reduction
 * preference therefore applies to the SIP/VoIP engine, while hearing-aid routing
 * is applied by the app's default-dialer InCallService.
 */
object AccessibilityPreferences {
    const val KEY_SIP_NOISE_REDUCTION = "accessibility_sip_noise_reduction"
    const val KEY_PREFER_HEARING_AID = "accessibility_prefer_hearing_aid"
    const val KEY_TEXT_SCALE = "accessibility_text_scale"
    const val KEY_LARGE_CONTROLS = "accessibility_large_controls"
    const val KEY_HIGH_CONTRAST = "accessibility_high_contrast"
    const val KEY_VISUAL_ALERTS = "accessibility_visual_alerts"
    const val KEY_SIMPLIFIED_MODE = "accessibility_simplified_mode"

    const val MIN_TEXT_SCALE = 1f
    const val MAX_TEXT_SCALE = 2f

    data class Snapshot(
        val sipNoiseReduction: Boolean = true,
        val preferHearingAid: Boolean = false,
        val textScale: Float = 1f,
        val largeControls: Boolean = false,
        val highContrast: Boolean = false,
        val visualAlerts: Boolean = false,
        val simplifiedMode: Boolean = false,
    )

    fun load(context: Context): Snapshot {
        val prefs = PhoneSettingsPrefs.preferences(context)
        return Snapshot(
            sipNoiseReduction = prefs.getBoolean(KEY_SIP_NOISE_REDUCTION, true),
            preferHearingAid = prefs.getBoolean(KEY_PREFER_HEARING_AID, false),
            textScale = prefs.getFloat(KEY_TEXT_SCALE, 1f)
                .coerceIn(MIN_TEXT_SCALE, MAX_TEXT_SCALE),
            largeControls = prefs.getBoolean(KEY_LARGE_CONTROLS, false),
            highContrast = prefs.getBoolean(KEY_HIGH_CONTRAST, false),
            visualAlerts = prefs.getBoolean(KEY_VISUAL_ALERTS, false),
            simplifiedMode = prefs.getBoolean(KEY_SIMPLIFIED_MODE, false),
        )
    }

    fun save(context: Context, snapshot: Snapshot) {
        PhoneSettingsPrefs.preferences(context).edit()
            .putBoolean(KEY_SIP_NOISE_REDUCTION, snapshot.sipNoiseReduction)
            .putBoolean(KEY_PREFER_HEARING_AID, snapshot.preferHearingAid)
            .putFloat(
                KEY_TEXT_SCALE,
                snapshot.textScale.coerceIn(MIN_TEXT_SCALE, MAX_TEXT_SCALE),
            )
            .putBoolean(KEY_LARGE_CONTROLS, snapshot.largeControls)
            .putBoolean(KEY_HIGH_CONTRAST, snapshot.highContrast)
            .putBoolean(KEY_VISUAL_ALERTS, snapshot.visualAlerts)
            .putBoolean(KEY_SIMPLIFIED_MODE, snapshot.simplifiedMode)
            .apply()
    }
}

data class HearingAidDevice(
    val id: Int,
    val name: String,
)

object HearingAidSupport {
    fun connectedDevice(context: Context): HearingAidDevice? {
        val audioManager = context.getSystemService(AudioManager::class.java) ?: return null
        return audioManager
            .getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .firstOrNull(::isHearingAid)
            ?.let { device ->
                HearingAidDevice(
                    id = device.id,
                    name = device.productName?.toString()
                        ?.takeIf(String::isNotBlank)
                        ?: "Connected hearing device",
                )
            }
    }

    fun routeCommunicationAudio(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        val audioManager = context.getSystemService(AudioManager::class.java) ?: return false
        val device = audioManager.availableCommunicationDevices.firstOrNull(::isHearingAid)
            ?: return false
        return runCatching { audioManager.setCommunicationDevice(device) }.getOrDefault(false)
    }

    fun clearCommunicationRoute(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        context.getSystemService(AudioManager::class.java)?.clearCommunicationDevice()
    }

    private fun isHearingAid(device: AudioDeviceInfo): Boolean {
        if (device.type == AudioDeviceInfo.TYPE_HEARING_AID) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            device.type == AudioDeviceInfo.TYPE_BLE_HEADSET
        ) {
            return true
        }
        val name = device.productName?.toString().orEmpty()
        return device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO &&
            (name.contains("hearing", ignoreCase = true) ||
                name.contains("aid", ignoreCase = true))
    }
}
