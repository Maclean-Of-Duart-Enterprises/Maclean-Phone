package com.macleanofduartenterprises.phone.crm

import android.content.ContentProviderOperation
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.database.getLongOrNull
import androidx.core.database.getStringOrNull
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.InputStream

internal data class ContactAccount(
    val name: String?,
    val type: String?,
    val isSim: Boolean,
)

internal data class SystemContactWriteResult(
    val contactId: Long,
    val rawContactId: Long,
)

internal data class RawContactMetadata(
    val rawContactId: Long,
    val storage: ContactStorage,
    val readOnly: Boolean,
)

internal class SystemContactGateway(private val context: Context) {
    private val resolver: ContentResolver = context.contentResolver

    private fun canRead(): Boolean = ContextCompat.checkSelfPermission(
        context,
        android.Manifest.permission.READ_CONTACTS,
    ) == PackageManager.PERMISSION_GRANTED

    private fun canWrite(): Boolean = ContextCompat.checkSelfPermission(
        context,
        android.Manifest.permission.WRITE_CONTACTS,
    ) == PackageManager.PERMISSION_GRANTED

    fun loadContacts(): List<CrmContact> {
        if (!canRead()) return emptyList()
        val builders = linkedMapOf<Long, SystemContactBuilder>()
        runCatching {
            resolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                    ContactsContract.Contacts.PHOTO_URI,
                ),
                null,
                null,
                null,
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
                val nameIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                )
                val photoIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idIndex)
                    builders[id] = SystemContactBuilder(
                        contactId = id,
                        displayName = cursor.getString(nameIndex).orEmpty(),
                        photoUri = cursor.getStringOrNull(photoIndex),
                    )
                }
            }
        }.getOrElse { return emptyList() }
        if (builders.isEmpty()) return emptyList()

        runCatching {
            resolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(
                    ContactsContract.Data.CONTACT_ID,
                    ContactsContract.Data.RAW_CONTACT_ID,
                    ContactsContract.Data.MIMETYPE,
                    ContactsContract.Data.DATA1,
                    ContactsContract.Data.DATA2,
                    ContactsContract.Data.DATA3,
                    ContactsContract.Data.DATA4,
                    ContactsContract.Data.DATA5,
                ),
                null,
                null,
                "${ContactsContract.Data.CONTACT_ID} ASC, ${ContactsContract.Data.IS_PRIMARY} DESC",
            )?.use { cursor ->
                val contactIndex = cursor.getColumnIndexOrThrow(ContactsContract.Data.CONTACT_ID)
                val rawIndex = cursor.getColumnIndexOrThrow(ContactsContract.Data.RAW_CONTACT_ID)
                val mimeIndex = cursor.getColumnIndexOrThrow(ContactsContract.Data.MIMETYPE)
                val data1 = cursor.getColumnIndexOrThrow(ContactsContract.Data.DATA1)
                val data2 = cursor.getColumnIndexOrThrow(ContactsContract.Data.DATA2)
                val data3 = cursor.getColumnIndexOrThrow(ContactsContract.Data.DATA3)
                val data4 = cursor.getColumnIndexOrThrow(ContactsContract.Data.DATA4)
                val data5 = cursor.getColumnIndexOrThrow(ContactsContract.Data.DATA5)
                while (cursor.moveToNext()) {
                    val builder = builders[cursor.getLong(contactIndex)] ?: continue
                    builder.rawContactIds += cursor.getLong(rawIndex)
                    val mime = cursor.getString(mimeIndex)
                    when (mime) {
                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE -> {
                            builder.firstName = cursor.getStringOrNull(data2).orEmpty()
                            builder.lastName = cursor.getStringOrNull(data3).orEmpty()
                            builder.middleName = cursor.getStringOrNull(data5).orEmpty()
                        }
                        ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE -> {
                            builder.nickname = cursor.getStringOrNull(data1).orEmpty()
                        }
                        ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE -> {
                            builder.company = cursor.getStringOrNull(data1).orEmpty()
                            cursor.getStringOrNull(data4)?.takeIf(String::isNotBlank)?.let { title ->
                                builder.add(CrmFieldType.CUSTOM, "Job title", title)
                            }
                        }
                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE -> {
                            val type = cursor.getInt(data2)
                            val customLabel = cursor.getStringOrNull(data3)
                            val label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                                context.resources,
                                type,
                                customLabel,
                            ).toString()
                            val number = cursor.getStringOrNull(data1).orEmpty()
                            val (country, local) = number.countryAndLocalNumber()
                            builder.add(
                                if (type == ContactsContract.CommonDataKinds.Phone.TYPE_FAX_HOME ||
                                    type == ContactsContract.CommonDataKinds.Phone.TYPE_FAX_WORK ||
                                    type == ContactsContract.CommonDataKinds.Phone.TYPE_OTHER_FAX
                                ) CrmFieldType.FAX else CrmFieldType.PHONE,
                                label,
                                local,
                                country,
                            )
                        }
                        ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE -> builder.add(
                            CrmFieldType.EMAIL,
                            ContactsContract.CommonDataKinds.Email.getTypeLabel(
                                context.resources,
                                cursor.getInt(data2),
                                cursor.getStringOrNull(data3),
                            ).toString(),
                            cursor.getStringOrNull(data1).orEmpty(),
                        )
                        ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE -> builder.add(
                            CrmFieldType.ADDRESS,
                            ContactsContract.CommonDataKinds.StructuredPostal.getTypeLabel(
                                context.resources,
                                cursor.getInt(data2),
                                cursor.getStringOrNull(data3),
                            ).toString(),
                            cursor.getStringOrNull(data1).orEmpty(),
                        )
                        ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE -> builder.add(
                            CrmFieldType.WEBSITE,
                            "Website",
                            cursor.getStringOrNull(data1).orEmpty(),
                        )
                        ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE -> if (
                            cursor.getInt(data2) == ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY
                        ) {
                            builder.birthday = cursor.getStringOrNull(data1).orEmpty()
                        }
                        ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE -> {
                            builder.notes = cursor.getStringOrNull(data1).orEmpty()
                        }
                    }
                }
            }
        }
        val metadata = loadRawContactMetadata()
        return builders.values.map { it.build(metadata) }
    }

    fun availableStorageOptions(): List<ContactStorageOption> {
        val writable = canWrite()
        val sim = if (writable) findSimAccount() else null
        return listOf(
            ContactStorageOption(
                ContactStorage.APP,
                detail = "Private CRM record stored inside Maclean Phone.",
            ),
            ContactStorageOption(
                ContactStorage.PHONE,
                enabled = writable,
                detail = if (writable) {
                    "Visible to Android contacts and other permitted phone apps."
                } else {
                    "Allow Contacts access to write Android contacts; the private CRM remains available."
                },
            ),
            ContactStorageOption(
                ContactStorage.SIM,
                enabled = sim != null,
                detail = if (sim != null) {
                    "Uses the SIM contacts account exposed by this device; SIM fields may be limited."
                } else {
                    "This device does not expose a writable SIM contacts account."
                },
            ),
        )
    }

    fun save(contact: CrmContact, photoBytes: ByteArray? = null): SystemContactWriteResult {
        check(canWrite()) { "Contacts permission is required for phone or SIM storage. App storage remains available." }
        check(!contact.readOnly) { "This Android or SIM contact is read-only. Copy it to Maclean app storage to edit it." }
        val account = when (contact.storage) {
            ContactStorage.SIM -> findSimAccount()
                ?: error("This device does not expose writable SIM contact storage.")
            ContactStorage.PHONE -> ContactAccount(null, null, false)
            ContactStorage.APP -> error("App-only contacts do not use Android contact storage.")
        }
        val rawId = contact.rawContactId
        val operations = ArrayList<ContentProviderOperation>()
        val rawBackReference: Int?
        if (rawId == null) {
            val rawBuilder = ContentProviderOperation
                .newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValues(rawContactAccountValues(account))
            operations += rawBuilder.build()
            rawBackReference = 0
        } else {
            val mimeTypes = MANAGED_MIME_TYPES
            val placeholders = mimeTypes.joinToString(",") { "?" }
            operations += ContentProviderOperation
                .newDelete(ContactsContract.Data.CONTENT_URI)
                .withSelection(
                    "${ContactsContract.Data.RAW_CONTACT_ID}=? AND " +
                        "${ContactsContract.Data.MIMETYPE} IN ($placeholders)",
                    (listOf(rawId.toString()) + mimeTypes).toTypedArray(),
                )
                .build()
            rawBackReference = null
        }

        fun dataInsert(mimeType: String): ContentProviderOperation.Builder {
            val builder = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValue(ContactsContract.Data.MIMETYPE, mimeType)
            return if (rawBackReference != null) {
                builder.withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawBackReference)
            } else {
                builder.withValue(ContactsContract.Data.RAW_CONTACT_ID, rawId)
            }
        }

        operations += dataInsert(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
            .withValue(
                ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME,
                contact.firstName.ifBlank {
                    if (contact.lastName.isBlank()) contact.displayName else ""
                },
            )
            .withValue(ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME, contact.middleName)
            .withValue(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME, contact.lastName)
            .build()

        if (contact.nickname.isNotBlank()) {
            operations += dataInsert(ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Nickname.NAME, contact.nickname)
                .build()
        }
        if (contact.company.isNotBlank()) {
            operations += dataInsert(ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Organization.COMPANY, contact.company)
                .withValue(
                    ContactsContract.CommonDataKinds.Organization.TITLE,
                    contact.customFields.firstOrNull {
                        it.label.equals("Job title", ignoreCase = true)
                    }?.value,
                )
                .build()
        }
        if (contact.birthday.isNotBlank()) {
            operations += dataInsert(ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Event.START_DATE, contact.birthday)
                .withValue(
                    ContactsContract.CommonDataKinds.Event.TYPE,
                    ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY,
                )
                .build()
        }
        if (contact.notes.isNotBlank()) {
            operations += dataInsert(ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Note.NOTE, contact.notes)
                .build()
        }

        contact.customFields.filter { it.value.isNotBlank() }.forEach { field ->
            when (field.type) {
                CrmFieldType.PHONE, CrmFieldType.FAX -> {
                    val (type, customLabel) = field.phoneTypeAndLabel()
                    operations += dataInsert(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, field.completeValue())
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, type)
                        .withValue(ContactsContract.CommonDataKinds.Phone.LABEL, customLabel)
                        .build()
                }
                CrmFieldType.EMAIL -> {
                    val (type, customLabel) = field.emailTypeAndLabel()
                    operations += dataInsert(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, field.value)
                        .withValue(ContactsContract.CommonDataKinds.Email.TYPE, type)
                        .withValue(ContactsContract.CommonDataKinds.Email.LABEL, customLabel)
                        .build()
                }
                CrmFieldType.ADDRESS -> operations += dataInsert(
                    ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
                )
                    .withValue(
                        ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS,
                        field.value,
                    )
                    .withValue(
                        ContactsContract.CommonDataKinds.StructuredPostal.TYPE,
                        ContactsContract.CommonDataKinds.StructuredPostal.TYPE_CUSTOM,
                    )
                    .withValue(ContactsContract.CommonDataKinds.StructuredPostal.LABEL, field.label)
                    .build()
                CrmFieldType.WEBSITE -> operations += dataInsert(
                    ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE,
                )
                    .withValue(ContactsContract.CommonDataKinds.Website.URL, field.value)
                    .withValue(
                        ContactsContract.CommonDataKinds.Website.TYPE,
                        ContactsContract.CommonDataKinds.Website.TYPE_CUSTOM,
                    )
                    .withValue(ContactsContract.CommonDataKinds.Website.LABEL, field.label)
                    .build()
                CrmFieldType.CUSTOM -> Unit // Preserved in the Maclean CRM extension database.
            }
        }

        val resolvedPhoto = photoBytes ?: contact.photoUri?.let(::readPhotoBytes)
        if (!account.isSim && resolvedPhoto != null && resolvedPhoto.isNotEmpty()) {
            operations += dataInsert(ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Photo.PHOTO, resolvedPhoto)
                .build()
        }

        val results = resolver.applyBatch(ContactsContract.AUTHORITY, operations)
        val resolvedRawId = rawId ?: results.firstOrNull()?.uri?.lastPathSegment?.toLongOrNull()
            ?: error("Android did not return the new raw-contact identifier.")
        val contactId = resolver.query(
            Uri.withAppendedPath(ContactsContract.RawContacts.CONTENT_URI, resolvedRawId.toString()),
            arrayOf(ContactsContract.RawContacts.CONTACT_ID),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getLongOrNull(0) else null
        } ?: contact.systemContactId
        return SystemContactWriteResult(
            contactId = contactId ?: error("Android did not aggregate the saved contact."),
            rawContactId = resolvedRawId,
        )
    }

    fun delete(contact: CrmContact) {
        check(canWrite()) { "Contacts permission is required to delete an Android or SIM contact." }
        check(!contact.readOnly) { "This Android or SIM contact is read-only and was not deleted." }
        val rawId = contact.rawContactId
            ?: error("The Android RawContact identifier is missing; no provider data was deleted.")
        val deleted = resolver.delete(
            Uri.withAppendedPath(ContactsContract.RawContacts.CONTENT_URI, rawId.toString()),
            null,
            null,
        )
        check(deleted > 0) { "Android did not delete RawContact $rawId." }
    }

    private fun loadRawContactMetadata(): Map<Long, RawContactMetadata> {
        if (!canRead()) return emptyMap()
        return runCatching {
            resolver.query(
                ContactsContract.RawContacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.RawContacts._ID,
                    ContactsContract.RawContacts.ACCOUNT_NAME,
                    ContactsContract.RawContacts.ACCOUNT_TYPE,
                    ContactsContract.RawContacts.RAW_CONTACT_IS_READ_ONLY,
                ),
                "${ContactsContract.RawContacts.DELETED}=0",
                null,
                null,
            )?.use { cursor ->
                val id = cursor.getColumnIndexOrThrow(ContactsContract.RawContacts._ID)
                val name = cursor.getColumnIndexOrThrow(ContactsContract.RawContacts.ACCOUNT_NAME)
                val type = cursor.getColumnIndexOrThrow(ContactsContract.RawContacts.ACCOUNT_TYPE)
                val readOnly = cursor.getColumnIndexOrThrow(ContactsContract.RawContacts.RAW_CONTACT_IS_READ_ONLY)
                buildMap {
                    while (cursor.moveToNext()) {
                        val rawId = cursor.getLong(id)
                        val marker = "${cursor.getStringOrNull(name).orEmpty()} ${cursor.getStringOrNull(type).orEmpty()}".lowercase()
                        put(
                            rawId,
                            RawContactMetadata(
                                rawContactId = rawId,
                                storage = if (SIM_ACCOUNT_MARKERS.any(marker::contains)) ContactStorage.SIM else ContactStorage.PHONE,
                                readOnly = cursor.getInt(readOnly) != 0,
                            ),
                        )
                    }
                }
            }.orEmpty()
        }.getOrDefault(emptyMap())
    }

    private fun findSimAccount(): ContactAccount? = runCatching {
        resolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(
                ContactsContract.RawContacts.ACCOUNT_NAME,
                ContactsContract.RawContacts.ACCOUNT_TYPE,
                ContactsContract.RawContacts.RAW_CONTACT_IS_READ_ONLY,
            ),
            "${ContactsContract.RawContacts.DELETED}=0",
            null,
            null,
        )?.use { cursor ->
            val nameIndex = cursor.getColumnIndexOrThrow(ContactsContract.RawContacts.ACCOUNT_NAME)
            val typeIndex = cursor.getColumnIndexOrThrow(ContactsContract.RawContacts.ACCOUNT_TYPE)
            val readOnlyIndex = cursor.getColumnIndexOrThrow(
                ContactsContract.RawContacts.RAW_CONTACT_IS_READ_ONLY,
            )
            while (cursor.moveToNext()) {
                val name = cursor.getStringOrNull(nameIndex)
                val type = cursor.getStringOrNull(typeIndex)
                val marker = "${name.orEmpty()} ${type.orEmpty()}".lowercase()
                if (SIM_ACCOUNT_MARKERS.any(marker::contains) && cursor.getInt(readOnlyIndex) == 0) {
                    return@use ContactAccount(name, type, true)
                }
            }
            null
        }
    }.getOrNull()

    private fun readPhotoBytes(uriText: String): ByteArray? = runCatching {
        resolver.openInputStream(Uri.parse(uriText))?.use { stream ->
            val bytes = stream.readUpTo(MAX_CONTACT_PHOTO_BYTES + 1)
            bytes.takeIf { it.size <= MAX_CONTACT_PHOTO_BYTES }
        }
    }.getOrNull()

    private data class SystemContactBuilder(
        val contactId: Long,
        val displayName: String,
        val photoUri: String?,
        val rawContactIds: MutableSet<Long> = linkedSetOf(),
        var firstName: String = "",
        var middleName: String = "",
        var lastName: String = "",
        var nickname: String = "",
        var company: String = "",
        var birthday: String = "",
        var notes: String = "",
        val fields: MutableList<CrmCustomField> = mutableListOf(),
    ) {
        fun add(
            type: CrmFieldType,
            label: String,
            value: String,
            countryCode: String = "",
        ) {
            if (value.isBlank()) return
            fields += CrmCustomField(
                type = type,
                label = label.ifBlank { type.label },
                value = value,
                countryCode = countryCode,
                position = fields.size,
            )
        }

        fun build(metadata: Map<Long, RawContactMetadata>): CrmContact {
            var resolvedFirst = firstName
            var resolvedLast = lastName
            if (resolvedFirst.isBlank() && resolvedLast.isBlank() && displayName.isNotBlank()) {
                val tokens = displayName.trim().split(Regex("\\s+"))
                resolvedFirst = tokens.firstOrNull().orEmpty()
                resolvedLast = tokens.drop(1).joinToString(" ")
            }
            val selectedRaw = rawContactIds
                .mapNotNull(metadata::get)
                .firstOrNull { !it.readOnly }
                ?: rawContactIds.mapNotNull(metadata::get).firstOrNull()
                ?: rawContactIds.firstOrNull()?.let {
                    RawContactMetadata(it, ContactStorage.PHONE, readOnly = false)
                }
            return CrmContact(
                id = -contactId,
                systemContactId = contactId,
                rawContactId = selectedRaw?.rawContactId,
                storage = selectedRaw?.storage ?: ContactStorage.PHONE,
                firstName = resolvedFirst,
                middleName = middleName,
                lastName = resolvedLast,
                nickname = nickname,
                company = company,
                birthday = birthday,
                notes = notes,
                photoUri = photoUri,
                customFields = fields,
                systemOnly = true,
                readOnly = selectedRaw?.readOnly ?: true,
            )
        }
    }

    companion object {
        private const val MAX_CONTACT_PHOTO_BYTES = 3 * 1024 * 1024
        private val SIM_ACCOUNT_MARKERS = listOf("sim", "icc", "uicc")
        private val MANAGED_MIME_TYPES = listOf(
            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE,
        )
    }
}

internal fun rawContactAccountValues(account: ContactAccount): ContentValues = ContentValues().apply {
    // Several OEM providers crash when account fields are omitted entirely. Supplying explicit
    // null keys is also the documented representation of Android's local/device account.
    val localName = account.name
    val localType = account.type
    if (localName == null) putNull(ContactsContract.RawContacts.ACCOUNT_NAME)
    else put(ContactsContract.RawContacts.ACCOUNT_NAME, localName)
    if (localType == null) putNull(ContactsContract.RawContacts.ACCOUNT_TYPE)
    else put(ContactsContract.RawContacts.ACCOUNT_TYPE, localType)
}

private fun InputStream.readUpTo(maxBytes: Int): ByteArray {
    val output = ByteArrayOutputStream(minOf(maxBytes, 64 * 1024))
    val buffer = ByteArray(16 * 1024)
    var remaining = maxBytes
    while (remaining > 0) {
        val read = read(buffer, 0, minOf(buffer.size, remaining))
        if (read < 0) break
        output.write(buffer, 0, read)
        remaining -= read
    }
    return output.toByteArray()
}

private fun CrmCustomField.phoneTypeAndLabel(): Pair<Int, String?> {
    if (type == CrmFieldType.FAX) {
        return ContactsContract.CommonDataKinds.Phone.TYPE_FAX_WORK to null
    }
    return when (label.trim().lowercase()) {
        "mobile", "cell" -> ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE to null
        "home" -> ContactsContract.CommonDataKinds.Phone.TYPE_HOME to null
        "work", "office" -> ContactsContract.CommonDataKinds.Phone.TYPE_WORK to null
        "main" -> ContactsContract.CommonDataKinds.Phone.TYPE_MAIN to null
        else -> ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM to label
    }
}

private fun CrmCustomField.emailTypeAndLabel(): Pair<Int, String?> = when (label.trim().lowercase()) {
    "home" -> ContactsContract.CommonDataKinds.Email.TYPE_HOME to null
    "work", "office" -> ContactsContract.CommonDataKinds.Email.TYPE_WORK to null
    else -> ContactsContract.CommonDataKinds.Email.TYPE_CUSTOM to label
}

private fun String.countryAndLocalNumber(): Pair<String, String> {
    if (!trim().startsWith('+')) return "" to this
    val digits = trim().drop(1).takeWhile(Char::isDigit)
    // This is display-only for existing contacts; the full original number is
    // retained when an exact country-code split cannot be inferred safely.
    val knownCodes = listOf("1", "7", "20", "27", "30", "31", "32", "33", "34", "36", "39", "40", "41", "43", "44", "45", "46", "47", "48", "49", "52", "54", "55", "56", "57", "58", "60", "61", "62", "63", "64", "65", "66", "81", "82", "84", "86", "90", "91", "92", "93", "94", "95", "98", "211", "212", "213", "216", "218", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "248", "249", "250", "251", "252", "253", "254", "255", "256", "257", "258", "260", "261", "262", "263", "264", "265", "266", "267", "268", "269", "290", "291", "297", "298", "299", "350", "351", "352", "353", "354", "355", "356", "357", "358", "359", "370", "371", "372", "373", "374", "375", "376", "377", "378", "379", "380", "381", "382", "383", "385", "386", "387", "389", "420", "421", "423", "500", "501", "502", "503", "504", "505", "506", "507", "508", "509", "590", "591", "592", "593", "594", "595", "596", "597", "598", "599", "670", "672", "673", "674", "675", "676", "677", "678", "679", "680", "681", "682", "683", "685", "686", "687", "688", "689", "690", "691", "692", "850", "852", "853", "855", "856", "880", "886", "960", "961", "962", "963", "964", "965", "966", "967", "968", "970", "971", "972", "973", "974", "975", "976", "977", "992", "993", "994", "995", "996", "998")
    val code = knownCodes.sortedByDescending(String::length).firstOrNull(digits::startsWith)
        ?: return "" to this
    return "+$code" to trim().removePrefix("+$code").trim()
}
