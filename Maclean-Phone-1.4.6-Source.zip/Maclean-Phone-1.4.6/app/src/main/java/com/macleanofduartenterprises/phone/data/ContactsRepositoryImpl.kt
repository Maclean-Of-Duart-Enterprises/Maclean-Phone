package com.macleanofduartenterprises.phone.data

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.ContentObserver
import android.database.Cursor
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.database.getStringOrNull
import androidx.core.net.toUri
import com.google.i18n.phonenumbers.NumberParseException
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.macleanofduartenterprises.phone.crm.CrmRepository
import com.macleanofduartenterprises.phone.di.IODispatcher
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.entity.ContactPhone
import com.macleanofduartenterprises.phone.domain.entity.ContactPhoneChoicePolicy
import com.macleanofduartenterprises.phone.domain.repo.ContactRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.util.Locale
import javax.inject.Inject

/**
 * Created by Muhammad Usman : msusman97@gmail.com on 11/21/2023.
 */


class ContactsRepositoryImpl @Inject constructor(
    @ApplicationContext context: Context,
    @IODispatcher private val ioDispatcher: CoroutineDispatcher,
    private val crmRepository: CrmRepository,
) : ContactRepository {
    private val appContext = context
    val TAG = "ContactsRepositoryImpl"
    val contentResolver: ContentResolver = context.contentResolver
    val telephonyManager = getSystemService(context, TelephonyManager::class.java)
    private val phoneProjection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.PHOTO_URI,
        ContactsContract.CommonDataKinds.Phone.TYPE,
        ContactsContract.CommonDataKinds.Phone.LABEL,
        ContactsContract.CommonDataKinds.Phone.IS_PRIMARY,
    )
    private val contactProjection = arrayOf(
        ContactsContract.Contacts._ID,
        ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
        ContactsContract.Contacts.PHOTO_URI,
    )

    private fun Cursor.toContacts(): List<Contact> {
        val contacts = linkedMapOf<Long, Contact>()
        use { cursor ->
            while (cursor.moveToNext()) {
                val row = cursor.toContactData()
                val current = contacts[row.id]
                val choices = ContactPhoneChoicePolicy.choices(
                    primaryPhone = "",
                    phones = current?.phoneNumbers.orEmpty() + row.phoneNumbers,
                )
                contacts[row.id] = (current ?: row).copy(
                    phone = choices.firstOrNull()?.number.orEmpty(),
                    phoneNumbers = choices,
                )
            }
        }
        return contacts.values.toList()
    }

    private fun Cursor.toContactRows(): List<Contact> = toContacts()

    override suspend fun getContactsPaged(limit: Int, offset: Int): List<Contact> =
        withContext(ioDispatcher) {
            Log.d(TAG, "getContactsPaged: $limit, $offset")
            val contacts = mutableListOf<Contact>()
            contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                contactProjection,
                "${ContactsContract.Contacts.HAS_PHONE_NUMBER} > 0",
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} COLLATE NOCASE ASC LIMIT $limit OFFSET $offset"
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
                val nameIndex =
                    cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
                val photoIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI)
                while (cursor.moveToNext()) {
                    contacts += Contact(
                        id = cursor.getLong(idIndex),
                        name = cursor.getString(nameIndex).orEmpty(),
                        phone = "",
                        image = cursor.getStringOrNull(photoIndex)?.toUri(),
                    )
                }
            }

            if (contacts.isEmpty()) return@withContext emptyList()
            val phoneNumbers = loadPhoneNumbers(contacts.map { it.id })
            contacts.mapNotNull { contact ->
                val phones = phoneNumbers[contact.id].orEmpty()
                val primary = phones.firstOrNull()?.number ?: return@mapNotNull null
                contact.copy(phone = primary, phoneNumbers = phones)
            }
        }

    override suspend fun searchContacts(query: String, limit: Int, offset: Int): List<Contact> =
        withContext(ioDispatcher) {
            if (query.isBlank()) return@withContext emptyList()

            val normalizedQuery = query.trim()
            val selection =
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?".trimIndent()
            val args = arrayOf("%$normalizedQuery%", "%$normalizedQuery%")
            val phoneAndNameRows = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                phoneProjection,
                selection,
                args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC LIMIT $limit OFFSET $offset"
            )?.toContactRows() ?: emptyList()
            val phoneAndNameMatches = loadContactsByIds(phoneAndNameRows.map(Contact::id).distinct())

            val emailAndAddressMatchedIds = searchContactIdsByEmailOrAddress(
                query = normalizedQuery,
                limit = limit,
                offset = offset
            )
            val emailAndAddressMatches = loadContactsByIds(emailAndAddressMatchedIds)

            val crmMatches = crmRepository.searchLegacyContacts(normalizedQuery, limit)
            (phoneAndNameMatches + emailAndAddressMatches + crmMatches)
                .distinctBy { contact -> "${contact.id}_${contact.phone}" }
                .take(limit)
        }

    override suspend fun getContactByPhone(phoneNumber: String): Contact? =
        withContext(ioDispatcher) {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber)
            )

            val systemContact = contentResolver.query(
                uri, arrayOf(
                    ContactsContract.PhoneLookup._ID,
                    ContactsContract.PhoneLookup.DISPLAY_NAME,
                    ContactsContract.PhoneLookup.PHOTO_URI,
                    ContactsContract.PhoneLookup.NUMBER
                ), null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.toContactDataForPhoneLookup() else null
            }
            systemContact?.let { contact ->
                val phones = loadPhoneNumbers(listOf(contact.id))[contact.id].orEmpty()
                if (phones.isEmpty()) contact else contact.copy(
                    phone = phones.first().number,
                    phoneNumbers = phones,
                )
            } ?: crmRepository.findByPhone(phoneNumber)?.toLegacyContact()
        }

    override suspend fun getCompanyName(contactId: Long): String? = withContext(ioDispatcher) {
        if (contactId < 0) {
            return@withContext crmRepository.getCompanyForLegacyId(contactId)
        }
        val orgWhere =
            ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?"
        val orgWhereParams = arrayOf(
            contactId.toString(), ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE
        )
        val systemCompany = contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Organization.COMPANY),
            orgWhere,
            orgWhereParams,
            null
        )?.use {
            if (it.moveToFirst()) it.getStringOrNull(it.getColumnIndex(ContactsContract.CommonDataKinds.Organization.COMPANY)) else null
        }
        systemCompany?.takeIf(String::isNotBlank)
            ?: crmRepository.getCompanyForLegacyId(contactId)
    }


    fun normalizePhoneNumber(phone: String): String? {
        val phoneUtil = PhoneNumberUtil.getInstance()

        // Get the user's default country code
        val defaultRegion = telephonyManager?.simCountryIso?.uppercase(Locale.getDefault())
            ?: telephonyManager?.networkCountryIso?.uppercase(Locale.getDefault())
            ?: "US" // Default to "US" if unknown

        return try {
            // Parse the phone number
            val numberProto = phoneUtil.parse(phone, defaultRegion)

            // Format it into E.164 format (+<country_code><number>)
            phoneUtil.format(numberProto, PhoneNumberUtil.PhoneNumberFormat.E164)
        } catch (e: NumberParseException) {
            e.printStackTrace()
            null // Return null if the phone number is invalid
        }
    }


    /**
     * Get all favourite contacts as ContactData list
     */


    override suspend fun removeFromFavourites(contactId: Long): Unit = withContext(ioDispatcher) {
        val values = ContentValues().apply {
            put(ContactsContract.Contacts.STARRED, 0)
        }
        contentResolver.update(
            ContactsContract.Contacts.CONTENT_URI,
            values,
            "${ContactsContract.Contacts._ID} = ?",
            arrayOf(contactId.toString())
        )
    }

    override fun observeFavourites(): Flow<List<Contact>> = callbackFlow {

        fun load(): List<Contact> {
            val selection = "${ContactsContract.Contacts.STARRED} = 1"
            return contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                phoneProjection,
                selection,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )?.toContacts() ?: emptyList()
        }

        trySend(load())

        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(load())
            }
        }
        contentResolver.registerContentObserver(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, true, observer
        )

        awaitClose {
            contentResolver.unregisterContentObserver(observer)
        }

    }.flowOn(ioDispatcher)


    private fun Cursor.toContactData(): Contact {
        val idColumnIndex = this.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
        val nameColumnIndex =
            this.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberColumnIndex = this.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val photoUriColumnIndex =
            this.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)

        // Retrieve the contact details
        val contactId = this.getLong(idColumnIndex)
        val contactName = this.getString(nameColumnIndex)
        val contactNumber = this.getString(numberColumnIndex)
        val photoUri = this.getStringOrNull(photoUriColumnIndex)?.toUri()
        val typeIndex = getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)
        val labelIndex = getColumnIndex(ContactsContract.CommonDataKinds.Phone.LABEL)
        val primaryIndex = getColumnIndex(ContactsContract.CommonDataKinds.Phone.IS_PRIMARY)
        val type = if (typeIndex >= 0) getInt(typeIndex) else ContactsContract.CommonDataKinds.Phone.TYPE_OTHER
        val customLabel = if (labelIndex >= 0) getStringOrNull(labelIndex) else null
        val phoneLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
            appContext.resources,
            type,
            customLabel,
        ).toString()
        val isPrimary = primaryIndex >= 0 && getInt(primaryIndex) != 0
        return Contact(
            id = contactId,
            name = contactName,
            phone = contactNumber,
            image = photoUri,
            phoneNumbers = listOf(
                ContactPhone(
                    number = contactNumber,
                    label = phoneLabel,
                    isPrimary = isPrimary,
                )
            ),
        )
    }

    private fun Cursor.toContactDataForPhoneLookup(): Contact {

        val idColumnIndex = this.getColumnIndex(ContactsContract.PhoneLookup._ID)
        val nameColumnIndex = this.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
        val numberColumnIndex = this.getColumnIndex(ContactsContract.PhoneLookup.NUMBER)
        val photoUriColumnIndex = this.getColumnIndex(ContactsContract.PhoneLookup.PHOTO_URI)

        // Retrieve the contact details
        val contactId = this.getLong(idColumnIndex)
        val contactName = this.getString(nameColumnIndex)
        val contactNumber = this.getString(numberColumnIndex)
        val photoUri = this.getStringOrNull(photoUriColumnIndex)?.toUri()
        return Contact(
            id = contactId,
            name = contactName,
            phone = contactNumber,
            image = photoUri,
            phoneNumbers = listOf(ContactPhone(contactNumber, isPrimary = true)),
        )
    }

    private fun searchContactIdsByEmailOrAddress(
        query: String,
        limit: Int,
        offset: Int
    ): List<Long> {
        val mimetypeColumn = ContactsContract.Data.MIMETYPE
        val selection = """
            ($mimetypeColumn = ? AND ${ContactsContract.CommonDataKinds.Email.ADDRESS} LIKE ?)
            OR
            ($mimetypeColumn = ? AND ${ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS} LIKE ?)
        """.trimIndent()
        val args = arrayOf(
            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
            "%$query%",
            ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
            "%$query%"
        )

        return contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data.CONTACT_ID),
            selection,
            args,
            "${ContactsContract.Data.DISPLAY_NAME} COLLATE NOCASE ASC LIMIT $limit OFFSET $offset"
        )?.use { cursor ->
            val contactIdIndex = cursor.getColumnIndexOrThrow(ContactsContract.Data.CONTACT_ID)
            val ids = LinkedHashSet<Long>()
            while (cursor.moveToNext()) {
                ids.add(cursor.getLong(contactIdIndex))
            }
            ids.toList()
        } ?: emptyList()
    }

    private fun loadContactsByIds(contactIds: List<Long>): List<Contact> {
        if (contactIds.isEmpty()) return emptyList()

        val placeholders = contactIds.joinToString(",") { "?" }
        val selection = "${ContactsContract.Contacts._ID} IN ($placeholders) AND ${ContactsContract.Contacts.HAS_PHONE_NUMBER} > 0"
        val args = contactIds.map { it.toString() }.toTypedArray()
        val contacts = mutableListOf<Contact>()

        contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            contactProjection,
            selection,
            args,
            "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
            val nameIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
            val photoIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI)

            while (cursor.moveToNext()) {
                contacts += Contact(
                    id = cursor.getLong(idIndex),
                    name = cursor.getString(nameIndex).orEmpty(),
                    phone = "",
                    image = cursor.getStringOrNull(photoIndex)?.toUri()
                )
            }
        }

        if (contacts.isEmpty()) return emptyList()
        val phoneNumbers = loadPhoneNumbers(contacts.map { it.id })
        return contacts.mapNotNull { contact ->
            val phones = phoneNumbers[contact.id].orEmpty()
            val primary = phones.firstOrNull()?.number ?: return@mapNotNull null
            contact.copy(phone = primary, phoneNumbers = phones)
        }
    }

    private fun loadPhoneNumbers(contactIds: List<Long>): Map<Long, List<ContactPhone>> {
        if (contactIds.isEmpty()) return emptyMap()
        val placeholders = contactIds.joinToString(",") { "?" }
        val selection = "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} IN ($placeholders)"
        val args = contactIds.map { it.toString() }.toTypedArray()
        val numbers = mutableMapOf<Long, List<ContactPhone>>()
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.IS_PRIMARY,
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.LABEL,
            ),
            selection,
            args,
            "${ContactsContract.CommonDataKinds.Phone.IS_PRIMARY} DESC"
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numberIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val primaryIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.IS_PRIMARY)
            val typeIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
            val labelIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)
            val rows = linkedMapOf<Long, MutableList<ContactPhone>>()
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIndex)
                val number = cursor.getString(numberIndex)
                if (!number.isNullOrBlank()) {
                    val label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                        appContext.resources,
                        cursor.getInt(typeIndex),
                        cursor.getStringOrNull(labelIndex),
                    ).toString()
                    rows.getOrPut(id) { mutableListOf() } += ContactPhone(
                        number = number,
                        label = label,
                        isPrimary = cursor.getInt(primaryIndex) != 0,
                    )
                }
            }
            rows.forEach { (id, phones) ->
                numbers[id] = ContactPhoneChoicePolicy.choices("", phones)
            }
        }
        return numbers
    }
}
