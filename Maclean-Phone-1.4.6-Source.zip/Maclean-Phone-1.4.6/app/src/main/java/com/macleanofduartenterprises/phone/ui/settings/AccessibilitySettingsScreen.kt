package com.macleanofduartenterprises.phone.ui.settings

import android.content.Context
import android.view.accessibility.AccessibilityManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Contrast
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.FormatSize
import androidx.compose.material.icons.outlined.Hearing
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.SpaceBar
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.core.AccessibilityPreferences
import com.macleanofduartenterprises.phone.core.HearingAidSupport
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilitySettingsScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    var settings by remember(context) { mutableStateOf(AccessibilityPreferences.load(context)) }
    var callerAnnouncement by remember(context) {
        mutableStateOf(PhoneSettingsPrefs.callerIdAnnouncement(context))
    }
    var hearingDevice by remember(context) {
        mutableStateOf(HearingAidSupport.connectedDevice(context))
    }
    val accessibilityManager = remember(context) {
        context.getSystemService(AccessibilityManager::class.java)
    }
    val talkBackActive = accessibilityManager?.isEnabled == true &&
        accessibilityManager.isTouchExplorationEnabled

    fun update(newSettings: AccessibilityPreferences.Snapshot) {
        settings = newSettings
        AccessibilityPreferences.save(context, newSettings)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Accessibility & audio") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            AccessibilitySection("Screen reader") {
                AccessibilityStatusRow(
                    icon = Icons.Outlined.RecordVoiceOver,
                    title = "TalkBack compatibility",
                    detail = if (talkBackActive) {
                        "TalkBack is active. Buttons, call states, keypad letters, and recording status are announced."
                    } else {
                        "Always enabled. Maclean Phone exposes labels, roles, states, and accessible actions to TalkBack."
                    },
                )
            }

            AccessibilitySection("Call audio") {
                AccessibilitySwitchRow(
                    icon = Icons.Outlined.VolumeUp,
                    title = "SIP noise & echo reduction",
                    detail = "Controls Maclean Phone's SIP/VoIP audio engine. Cellular modem noise processing is managed by the phone hardware.",
                    checked = settings.sipNoiseReduction,
                    onCheckedChange = {
                        update(settings.copy(sipNoiseReduction = it))
                    },
                )
                AccessibilityDivider()
                AccessibilitySwitchRow(
                    icon = Icons.Outlined.Hearing,
                    title = "Prefer hearing aid",
                    detail = hearingDevice?.let {
                        "Connected: ${it.name}. Maclean Phone will prefer it for cellular calls."
                    } ?: "No compatible hearing device is currently detected. The preference will apply when one connects.",
                    checked = settings.preferHearingAid,
                    onCheckedChange = {
                        update(settings.copy(preferHearingAid = it))
                    },
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.End,
                ) {
                    Button(onClick = {
                        hearingDevice = HearingAidSupport.connectedDevice(context)
                    }) {
                        Text("Refresh hearing devices")
                    }
                }
            }

            AccessibilitySection("Vision & controls") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(Icons.Outlined.FormatSize, contentDescription = null)
                        Text(
                            "Extra text size: ${(settings.textScale * 100).roundToInt()}%",
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    Slider(
                        value = settings.textScale,
                        onValueChange = { update(settings.copy(textScale = it)) },
                        valueRange = AccessibilityPreferences.MIN_TEXT_SCALE..
                            AccessibilityPreferences.MAX_TEXT_SCALE,
                        steps = 9,
                    )
                    Text(
                        "This is applied in addition to Android's system font size.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                AccessibilityDivider()
                AccessibilitySwitchRow(
                    icon = Icons.Outlined.SpaceBar,
                    title = "Large controls",
                    detail = "Enlarges the dial pad and the most important call controls.",
                    checked = settings.largeControls,
                    onCheckedChange = { update(settings.copy(largeControls = it)) },
                )
                AccessibilityDivider()
                AccessibilitySwitchRow(
                    icon = Icons.Outlined.Contrast,
                    title = "High contrast",
                    detail = "Uses opaque panels, stronger outlines, and maximum text contrast.",
                    checked = settings.highContrast,
                    onCheckedChange = { update(settings.copy(highContrast = it)) },
                )
            }

            AccessibilitySection("Incoming calls") {
                AccessibilitySwitchRow(
                    icon = Icons.Outlined.FlashOn,
                    title = "Visual call alerts",
                    detail = "Flashes the incoming-call screen while the phone is ringing.",
                    checked = settings.visualAlerts,
                    onCheckedChange = { update(settings.copy(visualAlerts = it)) },
                )
                AccessibilityDivider()
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(Icons.Outlined.Campaign, contentDescription = null)
                        Text("Caller announcements", style = MaterialTheme.typography.titleMedium)
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PhoneSettingsPrefs.CallerIdAnnouncement.entries.forEach { choice ->
                            FilterChip(
                                selected = callerAnnouncement == choice,
                                onClick = {
                                    callerAnnouncement = choice
                                    PhoneSettingsPrefs.preferences(context).edit()
                                        .putString(
                                            PhoneSettingsPrefs.KEY_CALLER_ID_ANNOUNCEMENT,
                                            choice.name,
                                        )
                                        .apply()
                                },
                                label = { Text(choice.label) },
                            )
                        }
                    }
                    Text(
                        "Announcements use the saved contact name when available, otherwise the phone number.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            AccessibilitySection("Simplified layout") {
                AccessibilitySwitchRow(
                    icon = Icons.Outlined.AccessibilityNew,
                    title = "Simplified Mode",
                    detail = "Replaces the standard home tabs with large Favorites, Keypad, Recent calls, Voicemail, and Settings buttons.",
                    checked = settings.simplifiedMode,
                    onCheckedChange = { update(settings.copy(simplifiedMode = it)) },
                )
            }
        }
    }
}

@Composable
private fun AccessibilitySection(
    title: String,
    content: @Composable () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .semantics { heading() },
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
            ),
        ) {
            Column { content() }
        }
    }
}

@Composable
private fun AccessibilitySwitchRow(
    icon: ImageVector,
    title: String,
    detail: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    ListItem(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .toggleable(
                value = checked,
                role = Role.Switch,
                onValueChange = onCheckedChange,
            ),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = { Icon(icon, contentDescription = null) },
        headlineContent = { Text(title) },
        supportingContent = { Text(detail) },
        trailingContent = {
            Switch(checked = checked, onCheckedChange = null)
        },
    )
}

@Composable
private fun AccessibilityStatusRow(
    icon: ImageVector,
    title: String,
    detail: String,
) {
    ListItem(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = { Icon(icon, contentDescription = null) },
        headlineContent = { Text(title) },
        supportingContent = { Text(detail) },
    )
}

@Composable
private fun AccessibilityDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 64.dp),
        color = MaterialTheme.colorScheme.outlineVariant,
    )
}
