package com.macleanofduartenterprises.phone.domain.repo

import com.macleanofduartenterprises.phone.domain.entity.CallLogData
import com.macleanofduartenterprises.phone.domain.entity.CallLogFilter
import com.macleanofduartenterprises.phone.domain.entity.Contact

interface CallLogRepository {
    suspend fun getCallLogsPaged(
        limit: Int,
        offset: Int,
        filter: CallLogFilter = CallLogFilter.ALL
    ): List<CallLogData>
    suspend fun getCallLogsByPhone(phone: String): List<CallLogData>
    suspend fun deleteCallLogsByPhone(phone: String): Int
    suspend fun deleteAllCallLogs(): Int
    suspend fun getFrequentCalledContacts(): List<Contact>
    suspend fun searchCallLogContacts(query: String, limit: Int, offset: Int): List<Contact>
}
