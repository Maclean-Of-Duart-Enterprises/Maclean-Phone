package com.macleanofduartenterprises.phone.ivr

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object SipIvrRuntime {
    private val _status = MutableStateFlow(IvrRuntimeStatus())
    val status: StateFlow<IvrRuntimeStatus> = _status.asStateFlow()

    fun update(status: IvrRuntimeStatus) {
        _status.value = status
    }
}
