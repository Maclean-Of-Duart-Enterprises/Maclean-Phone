package com.macleanofduartenterprises.phone.core

import android.content.Context

object AppearancePreferences {
    const val KEY_BACKGROUND_TYPE = "appearance_background_type"
    const val KEY_BACKGROUND_PHOTO_URI = "appearance_background_photo_uri"
    const val KEY_ACCENT_COLOR = "appearance_accent_color"
    const val KEY_SOLID_BACKGROUND_COLOR = "appearance_solid_background_color"
    const val KEY_PANEL_OPACITY = "appearance_panel_opacity"
    const val KEY_TEXT_COLOR_MODE = "appearance_text_color_mode"
    const val KEY_TEXT_COLOR = "appearance_text_color"
    const val KEY_TEXT_WINDOW_MODE = "appearance_text_window_mode"
    const val KEY_TEXT_WINDOW_COLOR = "appearance_text_window_color"
    const val KEY_TEXT_WINDOW_OPACITY = "appearance_text_window_opacity"
    const val KEY_TEXT_WINDOW_CORNER_RADIUS = "appearance_text_window_corner_radius"

    const val DEFAULT_ACCENT_COLOR: Int = 0xFF286C4D.toInt()
    const val DEFAULT_SOLID_BACKGROUND_COLOR: Int = 0xFFF3F6F2.toInt()
    const val DEFAULT_PANEL_OPACITY: Float = 0.86f
    const val DEFAULT_TEXT_COLOR: Int = 0xFF111111.toInt()
    const val DEFAULT_TEXT_WINDOW_COLOR: Int = 0xFFF8FBF7.toInt()
    const val DEFAULT_TEXT_WINDOW_OPACITY: Float = 0.86f
    const val DEFAULT_TEXT_WINDOW_CORNER_RADIUS: Float = 12f

    enum class BackgroundType(val label: String) {
        TARTAN("Maclean ancient dress tartan"),
        SOLID("Solid color"),
        PHOTO("My photo"),
    }

    enum class TextColorMode(val label: String) {
        AUTOMATIC("Automatic"),
        CUSTOM("Custom"),
    }

    enum class TextWindowMode(val label: String) {
        CLEAR("Clear"),
        COLORED("Colored"),
    }

    data class Snapshot(
        val backgroundType: BackgroundType,
        val photoUri: String,
        val accentColor: Int,
        val solidBackgroundColor: Int,
        val panelOpacity: Float,
        val textColorMode: TextColorMode,
        val textColor: Int,
        val textWindowMode: TextWindowMode,
        val textWindowColor: Int,
        val textWindowOpacity: Float,
        val textWindowCornerRadius: Float,
    )

    fun load(context: Context): Snapshot {
        val prefs = PhoneSettingsPrefs.preferences(context)
        val backgroundType = runCatching {
            BackgroundType.valueOf(
                prefs.getString(KEY_BACKGROUND_TYPE, BackgroundType.TARTAN.name).orEmpty()
            )
        }.getOrDefault(BackgroundType.TARTAN)
        val textColorMode = runCatching {
            TextColorMode.valueOf(
                prefs.getString(KEY_TEXT_COLOR_MODE, TextColorMode.AUTOMATIC.name).orEmpty()
            )
        }.getOrDefault(TextColorMode.AUTOMATIC)
        val textWindowMode = runCatching {
            TextWindowMode.valueOf(
                prefs.getString(KEY_TEXT_WINDOW_MODE, TextWindowMode.CLEAR.name).orEmpty()
            )
        }.getOrDefault(TextWindowMode.CLEAR)
        return Snapshot(
            backgroundType = backgroundType,
            photoUri = prefs.getString(KEY_BACKGROUND_PHOTO_URI, "").orEmpty(),
            accentColor = prefs.getInt(KEY_ACCENT_COLOR, DEFAULT_ACCENT_COLOR),
            solidBackgroundColor = prefs.getInt(
                KEY_SOLID_BACKGROUND_COLOR,
                DEFAULT_SOLID_BACKGROUND_COLOR,
            ),
            panelOpacity = prefs.getFloat(KEY_PANEL_OPACITY, DEFAULT_PANEL_OPACITY)
                .let(::normalizePanelOpacity),
            textColorMode = textColorMode,
            textColor = prefs.getInt(KEY_TEXT_COLOR, DEFAULT_TEXT_COLOR),
            textWindowMode = textWindowMode,
            textWindowColor = prefs.getInt(
                KEY_TEXT_WINDOW_COLOR,
                DEFAULT_TEXT_WINDOW_COLOR,
            ),
            textWindowOpacity = prefs.getFloat(
                KEY_TEXT_WINDOW_OPACITY,
                DEFAULT_TEXT_WINDOW_OPACITY,
            ).let(::normalizeTextWindowOpacity),
            textWindowCornerRadius = prefs.getFloat(
                KEY_TEXT_WINDOW_CORNER_RADIUS,
                DEFAULT_TEXT_WINDOW_CORNER_RADIUS,
            ).let(::normalizeTextWindowCornerRadius),
        )
    }

    fun save(context: Context, snapshot: Snapshot) {
        PhoneSettingsPrefs.preferences(context).edit()
            .putString(KEY_BACKGROUND_TYPE, snapshot.backgroundType.name)
            .putString(KEY_BACKGROUND_PHOTO_URI, snapshot.photoUri)
            .putInt(KEY_ACCENT_COLOR, snapshot.accentColor)
            .putInt(KEY_SOLID_BACKGROUND_COLOR, snapshot.solidBackgroundColor)
            .putFloat(KEY_PANEL_OPACITY, normalizePanelOpacity(snapshot.panelOpacity))
            .putString(KEY_TEXT_COLOR_MODE, snapshot.textColorMode.name)
            .putInt(KEY_TEXT_COLOR, snapshot.textColor)
            .putString(KEY_TEXT_WINDOW_MODE, snapshot.textWindowMode.name)
            .putInt(KEY_TEXT_WINDOW_COLOR, snapshot.textWindowColor)
            .putFloat(
                KEY_TEXT_WINDOW_OPACITY,
                normalizeTextWindowOpacity(snapshot.textWindowOpacity),
            )
            .putFloat(
                KEY_TEXT_WINDOW_CORNER_RADIUS,
                normalizeTextWindowCornerRadius(snapshot.textWindowCornerRadius),
            )
            .apply()
    }

    fun reset(context: Context) {
        save(
            context,
            Snapshot(
                backgroundType = BackgroundType.TARTAN,
                photoUri = "",
                accentColor = DEFAULT_ACCENT_COLOR,
                solidBackgroundColor = DEFAULT_SOLID_BACKGROUND_COLOR,
                panelOpacity = DEFAULT_PANEL_OPACITY,
                textColorMode = TextColorMode.AUTOMATIC,
                textColor = DEFAULT_TEXT_COLOR,
                textWindowMode = TextWindowMode.CLEAR,
                textWindowColor = DEFAULT_TEXT_WINDOW_COLOR,
                textWindowOpacity = DEFAULT_TEXT_WINDOW_OPACITY,
                textWindowCornerRadius = DEFAULT_TEXT_WINDOW_CORNER_RADIUS,
            )
        )
    }

    fun parseHexColor(value: String): Int? {
        return try {
            val normalized = value.trim().removePrefix("#")
            if (normalized.length != 6 && normalized.length != 8) {
                null
            } else {
                val withAlpha = if (normalized.length == 6) "FF$normalized" else normalized
                withAlpha.toLong(16).toInt()
            }
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun formatHexColor(color: Int): String = String.format("#%06X", color and 0xFFFFFF)

    fun normalizePanelOpacity(value: Float): Float = value.coerceIn(0.01f, 1f)

    fun normalizeTextWindowOpacity(value: Float): Float = value.coerceIn(0.01f, 1f)

    fun normalizeTextWindowCornerRadius(value: Float): Float = value.coerceIn(0f, 32f)
}
