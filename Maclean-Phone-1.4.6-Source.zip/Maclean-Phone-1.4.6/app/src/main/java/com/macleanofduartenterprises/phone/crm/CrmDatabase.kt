package com.macleanofduartenterprises.phone.crm

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

internal class CrmDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION,
) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE crm_contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                system_contact_id INTEGER,
                raw_contact_id INTEGER,
                storage TEXT NOT NULL,
                first_name TEXT NOT NULL DEFAULT '',
                middle_name TEXT NOT NULL DEFAULT '',
                last_name TEXT NOT NULL DEFAULT '',
                nickname TEXT NOT NULL DEFAULT '',
                household TEXT NOT NULL DEFAULT '',
                company TEXT NOT NULL DEFAULT '',
                birthday TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                photo_uri TEXT,
                stage TEXT NOT NULL DEFAULT 'New lead',
                service TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT '',
                representative TEXT NOT NULL DEFAULT '',
                next_action TEXT NOT NULL DEFAULT '',
                favorite INTEGER NOT NULL DEFAULT 0,
                read_only INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE crm_fields (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER NOT NULL,
                field_type TEXT NOT NULL,
                label TEXT NOT NULL,
                value TEXT NOT NULL DEFAULT '',
                country_code TEXT NOT NULL DEFAULT '',
                position INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY(contact_id) REFERENCES crm_contacts(id) ON DELETE CASCADE
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE crm_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                color_argb INTEGER NOT NULL,
                position INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE crm_contact_groups (
                contact_id INTEGER NOT NULL,
                group_id INTEGER NOT NULL,
                PRIMARY KEY(contact_id, group_id),
                FOREIGN KEY(contact_id) REFERENCES crm_contacts(id) ON DELETE CASCADE,
                FOREIGN KEY(group_id) REFERENCES crm_groups(id) ON DELETE CASCADE
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX idx_crm_contacts_system ON crm_contacts(system_contact_id)")
        db.execSQL("CREATE UNIQUE INDEX idx_crm_contacts_system_unique ON crm_contacts(system_contact_id) WHERE system_contact_id IS NOT NULL")
        db.execSQL("CREATE UNIQUE INDEX idx_crm_contacts_raw_unique ON crm_contacts(raw_contact_id) WHERE raw_contact_id IS NOT NULL")
        db.execSQL("CREATE INDEX idx_crm_fields_contact ON crm_fields(contact_id, position)")
        db.execSQL("CREATE INDEX idx_crm_fields_value ON crm_fields(field_type, value)")
        db.execSQL("CREATE INDEX idx_crm_contact_groups_group ON crm_contact_groups(group_id)")

        listOf("Clients", "Leads", "Family", "Friends", "Work").forEachIndexed { index, name ->
            db.insertOrThrow(
                "crm_groups",
                null,
                ContentValues().apply {
                    put("name", name)
                    put("color_argb", DEFAULT_GROUP_COLORS[index])
                    put("position", index)
                },
            )
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        var version = oldVersion
        if (version == 1) {
            db.execSQL("ALTER TABLE crm_contacts ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE crm_contacts ADD COLUMN read_only INTEGER NOT NULL DEFAULT 0")
            repairDuplicateIdentityLinks(db)
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_crm_contacts_system_unique ON crm_contacts(system_contact_id) WHERE system_contact_id IS NOT NULL")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_crm_contacts_raw_unique ON crm_contacts(raw_contact_id) WHERE raw_contact_id IS NOT NULL")
            version = 2
        }
        check(version == newVersion) { "Missing CRM database migration from $oldVersion to $newVersion" }
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.execSQL("DELETE FROM crm_fields WHERE contact_id NOT IN (SELECT id FROM crm_contacts)")
            db.execSQL("DELETE FROM crm_contact_groups WHERE contact_id NOT IN (SELECT id FROM crm_contacts) OR group_id NOT IN (SELECT id FROM crm_groups)")
        }
    }

    fun loadContacts(): List<CrmContact> {
        val fieldsByContact = loadFields().groupBy { it.first }
        val groupsByContact = loadContactGroups()
        return readableDatabase.query(
            "crm_contacts",
            null,
            null,
            null,
            null,
            null,
            "updated_at DESC, id DESC",
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    val id = cursor.long("id")
                    add(
                        CrmContact(
                            id = id,
                            systemContactId = cursor.nullableLong("system_contact_id"),
                            rawContactId = cursor.nullableLong("raw_contact_id"),
                            storage = cursor.string("storage").asStorage(),
                            firstName = cursor.string("first_name"),
                            middleName = cursor.string("middle_name"),
                            lastName = cursor.string("last_name"),
                            nickname = cursor.string("nickname"),
                            household = cursor.string("household"),
                            company = cursor.string("company"),
                            birthday = cursor.string("birthday"),
                            notes = cursor.string("notes"),
                            photoUri = cursor.nullableString("photo_uri"),
                            stage = cursor.string("stage").ifBlank { CRM_STAGES.first() },
                            service = cursor.string("service"),
                            source = cursor.string("source"),
                            representative = cursor.string("representative"),
                            nextAction = cursor.string("next_action"),
                            favorite = cursor.int("favorite") != 0,
                            readOnly = cursor.int("read_only") != 0,
                            customFields = fieldsByContact[id]
                                .orEmpty()
                                .sortedBy { it.second.position }
                                .map { it.second },
                            groupIds = groupsByContact[id].orEmpty(),
                            createdAt = cursor.long("created_at"),
                            updatedAt = cursor.long("updated_at"),
                        ),
                    )
                }
            }
        }
    }

    fun getContact(id: Long): CrmContact? = loadContacts().firstOrNull { it.id == id }

    fun getContactBySystemId(systemContactId: Long): CrmContact? =
        loadContacts().firstOrNull { it.systemContactId == systemContactId }

    fun findByPhone(phone: String): CrmContact? {
        val needle = phone.normalizedPhoneKey()
        if (needle.isBlank()) return null
        return loadContacts().firstOrNull { contact ->
            contact.customFields.any { field ->
                field.type == CrmFieldType.PHONE &&
                    field.completeValue().normalizedPhoneKey().endsWithComparable(needle)
            }
        }
    }

    fun saveContact(contact: CrmContact): Long {
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            val resolvedId = when {
                contact.id > 0L -> contact.id
                contact.rawContactId != null -> findContactId("raw_contact_id", contact.rawContactId)
                contact.systemContactId != null -> findContactId("system_contact_id", contact.systemContactId)
                else -> null
            }
            val values = ContentValues().apply {
                putNullableLong("system_contact_id", contact.systemContactId)
                putNullableLong("raw_contact_id", contact.rawContactId)
                put("storage", contact.storage.name)
                put("first_name", contact.firstName)
                put("middle_name", contact.middleName)
                put("last_name", contact.lastName)
                put("nickname", contact.nickname)
                put("household", contact.household)
                put("company", contact.company)
                put("birthday", contact.birthday)
                put("notes", contact.notes)
                if (contact.photoUri == null) putNull("photo_uri") else put("photo_uri", contact.photoUri)
                put("stage", contact.stage.ifBlank { CRM_STAGES.first() })
                put("service", contact.service)
                put("source", contact.source)
                put("representative", contact.representative)
                put("next_action", contact.nextAction)
                put("favorite", if (contact.favorite) 1 else 0)
                put("read_only", if (contact.readOnly) 1 else 0)
                put("created_at", if (resolvedId == null) now else contact.createdAt)
                put("updated_at", now)
            }
            val contactId = if (resolvedId == null) {
                db.insertOrThrow("crm_contacts", null, values)
            } else {
                val changed = db.update("crm_contacts", values, "id=?", arrayOf(resolvedId.toString()))
                check(changed == 1) { "Contact $resolvedId no longer exists." }
                resolvedId
            }

            db.delete("crm_fields", "contact_id=?", arrayOf(contactId.toString()))
            contact.customFields.forEachIndexed { index, field ->
                db.insertOrThrow(
                    "crm_fields",
                    null,
                    ContentValues().apply {
                        put("contact_id", contactId)
                        put("field_type", field.type.name)
                        put("label", field.label)
                        put("value", field.value)
                        put("country_code", field.countryCode)
                        put("position", index)
                    },
                )
            }

            db.delete("crm_contact_groups", "contact_id=?", arrayOf(contactId.toString()))
            contact.groupIds.forEach { groupId ->
                db.insertWithOnConflict(
                    "crm_contact_groups",
                    null,
                    ContentValues().apply {
                        put("contact_id", contactId)
                        put("group_id", groupId)
                    },
                    SQLiteDatabase.CONFLICT_IGNORE,
                )
            }
            db.setTransactionSuccessful()
            return contactId
        } finally {
            db.endTransaction()
        }
    }

    fun updateSystemLink(
        contactId: Long,
        systemContactId: Long?,
        rawContactId: Long?,
        photoUri: String? = null,
    ) {
        writableDatabase.update(
            "crm_contacts",
            ContentValues().apply {
                putNullableLong("system_contact_id", systemContactId)
                putNullableLong("raw_contact_id", rawContactId)
                if (photoUri != null) put("photo_uri", photoUri)
                put("updated_at", System.currentTimeMillis())
            },
            "id=?",
            arrayOf(contactId.toString()),
        )
    }

    fun deleteContact(contactId: Long) {
        check(writableDatabase.delete("crm_contacts", "id=?", arrayOf(contactId.toString())) == 1) {
            "Contact $contactId no longer exists."
        }
    }

    fun deleteContacts(contactIds: Collection<Long>): Int {
        val ids = contactIds.filter { it > 0L }.distinct()
        if (ids.isEmpty()) return 0
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val placeholders = ids.joinToString(",") { "?" }
            val deleted = db.delete(
                "crm_contacts",
                "id IN ($placeholders)",
                ids.map(Long::toString).toTypedArray(),
            )
            db.setTransactionSuccessful()
            deleted
        } finally {
            db.endTransaction()
        }
    }

    fun setFavorite(contactId: Long, favorite: Boolean) {
        val changed = writableDatabase.update(
            "crm_contacts",
            ContentValues().apply {
                put("favorite", if (favorite) 1 else 0)
                put("updated_at", System.currentTimeMillis())
            },
            "id=?",
            arrayOf(contactId.toString()),
        )
        check(changed == 1) { "Contact $contactId no longer exists." }
    }

    fun updateGroupMembership(
        contactIds: Collection<Long>,
        groupIds: Collection<Long>,
        add: Boolean,
    ): Int {
        val contacts = contactIds.filter { it > 0L }.distinct()
        val groups = groupIds.filter { it > 0L }.distinct()
        if (contacts.isEmpty() || groups.isEmpty()) return 0
        val db = writableDatabase
        db.beginTransaction()
        var changed = 0
        return try {
            contacts.forEach { contactId ->
                groups.forEach { groupId ->
                    changed += if (add) {
                        if (db.insertWithOnConflict(
                                "crm_contact_groups",
                                null,
                                ContentValues().apply {
                                    put("contact_id", contactId)
                                    put("group_id", groupId)
                                },
                                SQLiteDatabase.CONFLICT_IGNORE,
                            ) == -1L
                        ) 0 else 1
                    } else {
                        db.delete(
                            "crm_contact_groups",
                            "contact_id=? AND group_id=?",
                            arrayOf(contactId.toString(), groupId.toString()),
                        )
                    }
                }
            }
            db.setTransactionSuccessful()
            changed
        } finally {
            db.endTransaction()
        }
    }

    fun loadGroups(): List<CrmGroup> = readableDatabase.query(
        "crm_groups",
        null,
        null,
        null,
        null,
        null,
        "position ASC, name COLLATE NOCASE ASC",
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) {
                add(
                    CrmGroup(
                        id = cursor.long("id"),
                        name = cursor.string("name"),
                        colorArgb = cursor.long("color_argb"),
                        position = cursor.int("position"),
                    ),
                )
            }
        }
    }

    fun saveGroup(group: CrmGroup): Long {
        require(group.name.trim().isNotEmpty()) { "Enter a group name." }
        val values = ContentValues().apply {
            put("name", group.name.trim())
            put("color_argb", group.colorArgb)
            put(
                "position",
                if (group.id == 0L) loadGroups().size else group.position,
            )
        }
        return if (group.id == 0L) {
            writableDatabase.insertOrThrow("crm_groups", null, values)
        } else {
            check(writableDatabase.update("crm_groups", values, "id=?", arrayOf(group.id.toString())) == 1) {
                "Group ${group.id} no longer exists."
            }
            group.id
        }
    }

    fun ensureGroup(name: String): Long {
        val cleanName = name.trim()
        if (cleanName.isBlank()) return 0
        loadGroups().firstOrNull { it.name.equals(cleanName, ignoreCase = true) }
            ?.let { return it.id }
        return saveGroup(CrmGroup(name = cleanName))
    }

    fun deleteGroup(groupId: Long) {
        check(writableDatabase.delete("crm_groups", "id=?", arrayOf(groupId.toString())) == 1) {
            "Group $groupId no longer exists."
        }
        normalizeGroupPositions()
    }

    fun moveGroup(groupId: Long, direction: Int) {
        val groups = loadGroups().toMutableList()
        val index = groups.indexOfFirst { it.id == groupId }
        val destination = index + direction
        if (index < 0 || destination !in groups.indices) return
        val moving = groups.removeAt(index)
        groups.add(destination, moving)
        val db = writableDatabase
        db.beginTransaction()
        try {
            groups.forEachIndexed { position, group ->
                db.update(
                    "crm_groups",
                    ContentValues().apply { put("position", position) },
                    "id=?",
                    arrayOf(group.id.toString()),
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun normalizeGroupPositions() {
        val db = writableDatabase
        loadGroups().forEachIndexed { index, group ->
            db.update(
                "crm_groups",
                ContentValues().apply { put("position", index) },
                "id=?",
                arrayOf(group.id.toString()),
            )
        }
    }

    private fun findContactId(column: String, value: Long): Long? = readableDatabase.query(
        "crm_contacts",
        arrayOf("id"),
        "$column=?",
        arrayOf(value.toString()),
        null,
        null,
        null,
        "1",
    ).use { cursor -> if (cursor.moveToFirst()) cursor.getLong(0) else null }

    private fun loadFields(): List<Pair<Long, CrmCustomField>> = readableDatabase.query(
        "crm_fields",
        null,
        null,
        null,
        null,
        null,
        "contact_id ASC, position ASC, id ASC",
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) {
                val contactId = cursor.long("contact_id")
                add(
                    contactId to CrmCustomField(
                        id = cursor.long("id"),
                        type = cursor.string("field_type").asFieldType(),
                        label = cursor.string("label"),
                        value = cursor.string("value"),
                        countryCode = cursor.string("country_code"),
                        position = cursor.int("position"),
                    ),
                )
            }
        }
    }

    private fun loadContactGroups(): Map<Long, Set<Long>> = readableDatabase.query(
        "crm_contact_groups",
        arrayOf("contact_id", "group_id"),
        null,
        null,
        null,
        null,
        null,
    ).use { cursor ->
        val result = mutableMapOf<Long, MutableSet<Long>>()
        while (cursor.moveToNext()) {
            result.getOrPut(cursor.long("contact_id"), ::mutableSetOf)
                .add(cursor.long("group_id"))
        }
        result
    }

    private fun Cursor.column(name: String): Int = getColumnIndexOrThrow(name)
    private fun Cursor.string(name: String): String = getString(column(name)).orEmpty()
    private fun Cursor.nullableString(name: String): String? =
        column(name).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.long(name: String): Long = getLong(column(name))
    private fun Cursor.int(name: String): Int = getInt(column(name))
    private fun Cursor.nullableLong(name: String): Long? =
        column(name).let { if (isNull(it)) null else getLong(it) }

    private fun ContentValues.putNullableLong(key: String, value: Long?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun String.asStorage(): ContactStorage =
        runCatching { ContactStorage.valueOf(this) }.getOrDefault(ContactStorage.APP)

    private fun String.asFieldType(): CrmFieldType =
        runCatching { CrmFieldType.valueOf(this) }.getOrDefault(CrmFieldType.CUSTOM)

    companion object {
        private const val DATABASE_NAME = "maclean_phone_crm.db"
        internal const val DATABASE_VERSION = 2
        private val DEFAULT_GROUP_COLORS = listOf(
            0xFF2E6F60,
            0xFFB8860B,
            0xFF7B4FA3,
            0xFF3367A8,
            0xFF8B5A2B,
        )

        private fun repairDuplicateIdentityLinks(db: SQLiteDatabase) {
            db.execSQL(
                "UPDATE crm_contacts SET system_contact_id=NULL WHERE system_contact_id IS NOT NULL AND id NOT IN (SELECT MIN(id) FROM crm_contacts WHERE system_contact_id IS NOT NULL GROUP BY system_contact_id)",
            )
            db.execSQL(
                "UPDATE crm_contacts SET raw_contact_id=NULL WHERE raw_contact_id IS NOT NULL AND id NOT IN (SELECT MIN(id) FROM crm_contacts WHERE raw_contact_id IS NOT NULL GROUP BY raw_contact_id)",
            )
        }
    }
}

internal fun String.normalizedPhoneKey(): String = filter(Char::isDigit)

private fun String.endsWithComparable(other: String): Boolean {
    if (isBlank() || other.isBlank()) return false
    val shortest = minOf(length, other.length)
    val comparisonLength = minOf(shortest, 10)
    return takeLast(comparisonLength) == other.takeLast(comparisonLength)
}
