package com.macleanofduartenterprises.phone.domain.repo

import com.macleanofduartenterprises.phone.domain.entity.Contact

interface ContactDetailProvider {
    suspend fun getContactByPhone(phone: String): Contact?
}
