package com.macleanofduartenterprises.phone.ui.home.favourite

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.repo.CallLogRepository
import com.macleanofduartenterprises.phone.domain.repo.ContactRepository
import com.macleanofduartenterprises.phone.ui.extensions.stateInScoped
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavouritesViewModel @Inject constructor(
    private val contactRepository: ContactRepository,
    private val callLogRepository: CallLogRepository
) : ViewModel() {

    val favourites = contactRepository.observeFavourites()
        .stateInScoped(emptyList())

    private val _frequentCalledContacts =
        MutableStateFlow<List<Contact>>(emptyList())

    val frequentCalledContacts: StateFlow<List<Contact>> =
        _frequentCalledContacts.asStateFlow()

    init {
        loadFrequent()
    }

    fun removeFromFavourites(contactId: Long) = viewModelScope.launch {
        runCatching { contactRepository.removeFromFavourites(contactId) }
            .onFailure { Log.d("favmeod", "removeFromFavourites: ${it.message}") }
    }

    private fun loadFrequent() = viewModelScope.launch {
        runCatching { callLogRepository.getFrequentCalledContacts() }
            .onSuccess {
                _frequentCalledContacts.value = it
            }.onFailure {
                Log.d("favmeod", "loadFrequent: ${it.message}")
            }

    }
}
