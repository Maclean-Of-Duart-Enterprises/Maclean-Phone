package com.macleanofduartenterprises.phone.ivr

import android.content.Context
import androidx.core.content.edit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IvrSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val preferences =
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    private val secretStore = IvrSecretStore()
    private val json = Json {
        encodeDefaults = true
        ignoreUnknownKeys = true
    }

    fun loadConfig(): IvrConfig {
        val encoded = preferences.getString(KEY_CONFIG, null) ?: return IvrConfig()
        return runCatching {
            json.decodeFromString<IvrConfig>(encoded)
        }.getOrDefault(IvrConfig())
    }

    fun loadPassword(): String =
        secretStore.decrypt(preferences.getString(KEY_ENCRYPTED_PASSWORD, "").orEmpty())

    fun save(config: IvrConfig, password: String) {
        val normalized = config.normalized()
        preferences.edit(commit = true) {
            putString(KEY_CONFIG, json.encodeToString(normalized))
            putString(KEY_ENCRYPTED_PASSWORD, secretStore.encrypt(password))
        }
    }

    fun setEnabled(enabled: Boolean) {
        val current = loadConfig()
        preferences.edit(commit = true) {
            putString(KEY_CONFIG, json.encodeToString(current.copy(enabled = enabled)))
        }
    }

    companion object {
        const val PREFERENCES_NAME = "sip_ivr_settings"
        private const val KEY_CONFIG = "ivr_config"
        private const val KEY_ENCRYPTED_PASSWORD = "sip_password"
    }
}
