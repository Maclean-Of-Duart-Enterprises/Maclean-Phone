package com.macleanofduartenterprises.phone.ui.home.contacts

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Merge
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.macleanofduartenterprises.phone.R
import com.macleanofduartenterprises.phone.crm.ContactStorage
import com.macleanofduartenterprises.phone.crm.ContactStorageOption
import com.macleanofduartenterprises.phone.crm.CrmContact
import com.macleanofduartenterprises.phone.crm.CrmFieldType
import com.macleanofduartenterprises.phone.crm.CrmGroup
import com.macleanofduartenterprises.phone.crm.CrmSortField
import com.macleanofduartenterprises.phone.crm.DuplicateMatch
import com.macleanofduartenterprises.phone.domain.entity.Contact

private sealed interface ExportRequest {
    data object All : ExportRequest
    data class Contacts(val contacts: List<CrmContact>, val label: String) : ExportRequest
    data class Group(val id: Long, val name: String) : ExportRequest
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContactsScreen(
    onContactDetailClick: (Contact) -> Unit,
    onCallClick: (Contact) -> Unit,
    onSettingsClick: () -> Unit,
    vm: ContactsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHost = remember { SnackbarHostState() }
    var editingContact by remember { mutableStateOf<CrmContact?>(null) }
    var detailContact by remember { mutableStateOf<CrmContact?>(null) }
    var showSort by remember { mutableStateOf(false) }
    var showGroups by remember { mutableStateOf(false) }
    var showExportScope by remember { mutableStateOf(false) }
    var pendingImportUri by remember { mutableStateOf<Uri?>(null) }
    var pendingExport by remember { mutableStateOf<ExportRequest?>(null) }
    var copyContacts by remember { mutableStateOf<List<CrmContact>?>(null) }
    var membershipContacts by remember { mutableStateOf<List<CrmContact>?>(null) }
    var deletingContacts by remember { mutableStateOf<List<CrmContact>?>(null) }
    var mergingContacts by remember { mutableStateOf<List<CrmContact>?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            editingContact = editingContact?.copy(photoUri = uri.toString())
        }
    }
    val vcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pendingImportUri = uri
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/vcard"),
    ) { uri ->
        val request = pendingExport
        pendingExport = null
        if (uri != null && request != null) {
            when (request) {
                ExportRequest.All -> vm.exportAll(uri)
                is ExportRequest.Contacts -> vm.export(uri, request.contacts)
                is ExportRequest.Group -> vm.exportGroup(uri, request.id)
            }
        }
    }
    val contactsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { vm.refresh() }

    fun startExport(request: ExportRequest) {
        pendingExport = request
        val label = when (request) {
            ExportRequest.All -> "Maclean-Contacts-All"
            is ExportRequest.Contacts -> request.label
            is ExportRequest.Group -> request.name
        }.replace(Regex("[^A-Za-z0-9._-]+"), "-").ifBlank { "Maclean-Contacts" }
        exportLauncher.launch("$label.vcf")
    }

    LaunchedEffect(state.message, state.error) {
        val notice = state.error ?: state.message ?: return@LaunchedEffect
        snackbarHost.showSnackbar(notice)
        vm.clearNotice()
    }
    LaunchedEffect(state.shareFile) {
        val shared = state.shareFile ?: return@LaunchedEffect
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/vcard"
            putExtra(Intent.EXTRA_STREAM, shared.uri)
            clipData = ClipData.newRawUri(shared.displayName, shared.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { context.startActivity(Intent.createChooser(intent, "Share contacts")) }
            .onFailure { snackbarHost.showSnackbar(it.message ?: "No sharing app is available.") }
        vm.consumeShareFile()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHost) },
        floatingActionButton = {
            if (!state.selectionMode) {
                ExtendedFloatingActionButton(
                    text = { Text("Add contact") },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    onClick = { editingContact = CrmContact() },
                )
            }
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            CrmHeader(
                contactCount = state.snapshot.contacts.size,
                onAdd = { editingContact = CrmContact() },
                onImport = {
                    vcfLauncher.launch(
                        arrayOf("text/vcard", "text/x-vcard", "application/vcard", "application/octet-stream"),
                    )
                },
                onExport = { showExportScope = true },
                onGroups = { showGroups = true },
                onDuplicates = vm::scanDuplicates,
                onSort = { showSort = true },
                onSettings = onSettingsClick,
                onContactsPermission = if (
                    state.snapshot.storageOptions.firstOrNull { it.storage == ContactStorage.PHONE }
                        ?.enabled == false
                ) ({
                    contactsPermissionLauncher.launch(
                        arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS),
                    )
                }) else null,
            )
            if (state.selectionMode) {
                SelectionToolbar(
                    count = state.selectedCount,
                    working = state.working,
                    onClose = vm::clearSelection,
                    onSelectAll = vm::selectAll,
                    onCopy = { copyContacts = vm.selected() },
                    onExport = {
                        startExport(ExportRequest.Contacts(vm.selected(), "Maclean-Contacts-Selected"))
                    },
                    onShare = { vm.share(vm.selected(), "Maclean-Contacts-Selected") },
                    onGroups = { membershipContacts = vm.selected() },
                    onMerge = { mergingContacts = vm.selected() },
                    onDelete = { deletingContacts = vm.selected() },
                )
            }
            OutlinedTextField(
                value = state.query,
                onValueChange = vm::setQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (state.query.isNotEmpty()) ({
                    IconButton(onClick = { vm.setQuery("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear contact search")
                    }
                }) else null,
                label = { Text("Search CRM contacts and fields") },
                singleLine = true,
            )
            GroupFilterRow(
                groups = state.snapshot.groups,
                selectedGroupId = state.selectedGroupId,
                favoritesOnly = state.favoritesOnly,
                onSelectGroup = vm::setGroupFilter,
                onSelectFavorites = vm::setFavoritesFilter,
            )
            when {
                state.loading && state.snapshot.contacts.isEmpty() -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center,
                ) { CircularProgressIndicator() }
                state.snapshot.contacts.isEmpty() -> EmptyContacts(
                    favoritesOnly = state.favoritesOnly,
                    onAdd = { editingContact = CrmContact() },
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp, 6.dp, 12.dp, 104.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(state.snapshot.contacts, key = CrmContact::stableId) { contact ->
                        CrmContactCard(
                            contact = contact,
                            groups = state.snapshot.groups,
                            selected = contact.stableId in state.selectedIds,
                            selectionMode = state.selectionMode,
                            onClick = {
                                if (state.selectionMode) vm.toggleSelection(contact) else detailContact = contact
                            },
                            onLongClick = { vm.toggleSelection(contact) },
                            onCall = {
                                if (contact.primaryPhone.isNotBlank()) onCallClick(contact.toLegacyContact())
                            },
                        )
                    }
                }
            }
        }
    }

    editingContact?.let { contact ->
        CrmContactEditor(
            original = contact,
            groups = state.snapshot.groups,
            storageOptions = state.snapshot.storageOptions,
            working = state.working,
            onPickPhoto = { photoLauncher.launch(arrayOf("image/*")) },
            onDismiss = { editingContact = null },
            onSave = { draft -> vm.saveContact(draft) { editingContact = null } },
        )
    }
    detailContact?.let { contact ->
        ContactActionsDialog(
            contact = contact,
            groups = state.snapshot.groups,
            onDismiss = { detailContact = null },
            onEdit = {
                detailContact = null
                editingContact = if (contact.readOnly) contact.copy(
                    id = 0,
                    systemContactId = null,
                    rawContactId = null,
                    storage = ContactStorage.APP,
                    readOnly = false,
                    systemOnly = false,
                ) else contact
            },
            onSystemDetails = { onContactDetailClick(contact.toLegacyContact()) },
            onCall = {
                detailContact = null
                onCallClick(contact.toLegacyContact())
            },
            onMessage = { launchSendTo(context, "smsto", contact.primaryPhone) },
            onEmail = { launchSendTo(context, "mailto", contact.primaryEmail) },
            onFavorite = {
                detailContact = null
                vm.setFavorite(contact, !contact.favorite)
            },
            onCopy = { copyContacts = listOf(contact) },
            onExport = { startExport(ExportRequest.Contacts(listOf(contact), contact.displayName)) },
            onShare = { vm.share(listOf(contact), contact.displayName) },
            onGroups = { membershipContacts = listOf(contact) },
            onMerge = {
                vm.selectOnly(contact)
                detailContact = null
            },
            onDelete = {
                deletingContacts = listOf(contact)
                detailContact = null
            },
        )
    }
    if (showSort) SortDialog(state.sortField, state.ascending, { showSort = false }) { field, ascending ->
        vm.setSort(field, ascending)
        showSort = false
    }
    if (showGroups) GroupManagerDialog(
        groups = state.snapshot.groups,
        working = state.working,
        onDismiss = { showGroups = false },
        onSave = vm::saveGroup,
        onDelete = vm::deleteGroup,
        onMove = vm::moveGroup,
        onExport = { startExport(ExportRequest.Group(it.id, it.name)) },
        onShare = vm::shareGroup,
    )
    if (showExportScope) ExportScopeDialog(
        hasSelection = state.selectionMode,
        selectedGroup = state.snapshot.groups.firstOrNull { it.id == state.selectedGroupId },
        onDismiss = { showExportScope = false },
        onAll = {
            showExportScope = false
            startExport(ExportRequest.All)
        },
        onCurrent = {
            showExportScope = false
            startExport(ExportRequest.Contacts(state.snapshot.contacts, "Maclean-Contacts-Filtered"))
        },
        onSelected = {
            showExportScope = false
            startExport(ExportRequest.Contacts(vm.selected(), "Maclean-Contacts-Selected"))
        },
        onGroup = { group ->
            showExportScope = false
            startExport(ExportRequest.Group(group.id, group.name))
        },
    )
    pendingImportUri?.let { uri ->
        StorageDialog(
            title = "Import VCF contacts to…",
            options = state.snapshot.storageOptions,
            onDismiss = { pendingImportUri = null },
            onSelect = { storage ->
                pendingImportUri = null
                vm.importVCard(uri, storage)
            },
        )
    }
    copyContacts?.let { contacts ->
        StorageDialog(
            title = "Copy ${contacts.size} contact${if (contacts.size == 1) "" else "s"} to…",
            options = state.snapshot.storageOptions,
            onDismiss = { copyContacts = null },
            onSelect = { storage ->
                copyContacts = null
                vm.copy(contacts, storage)
            },
        )
    }
    membershipContacts?.let { contacts ->
        MembershipDialog(
            contactCount = contacts.size,
            groups = state.snapshot.groups,
            onDismiss = { membershipContacts = null },
            onApply = { groups, add ->
                membershipContacts = null
                vm.updateGroups(contacts, groups, add)
            },
        )
    }
    deletingContacts?.let { contacts ->
        ConfirmActionDialog(
            title = "Delete ${contacts.size} contact${if (contacts.size == 1) "" else "s"}?",
            text = "The correct Maclean record and linked Android/SIM RawContact will be removed. Read-only records will be reported, not silently ignored.",
            action = "Delete",
            onDismiss = { deletingContacts = null },
            onConfirm = {
                deletingContacts = null
                vm.delete(contacts)
            },
        )
    }
    mergingContacts?.let { contacts ->
        ConfirmActionDialog(
            title = "Merge ${contacts.size} contacts?",
            text = "All unique fields, photos, notes, and groups will be saved first. Sources are deleted only after the merged contact saves successfully.",
            action = "Merge",
            confirmEnabled = contacts.size >= 2,
            onDismiss = { mergingContacts = null },
            onConfirm = {
                mergingContacts = null
                vm.merge(contacts)
            },
        )
    }
    if (state.duplicateMatches.isNotEmpty()) DuplicateDialog(
        matches = state.duplicateMatches,
        onDismiss = vm::clearDuplicates,
        onSelect = { match ->
            vm.selectDuplicate(match)
            vm.clearDuplicates()
        },
    )
}

@Composable
private fun CrmHeader(
    contactCount: Int,
    onAdd: () -> Unit,
    onImport: () -> Unit,
    onExport: () -> Unit,
    onGroups: () -> Unit,
    onDuplicates: () -> Unit,
    onSort: () -> Unit,
    onSettings: () -> Unit,
    onContactsPermission: (() -> Unit)?,
) {
    Column(
        modifier = Modifier.fillMaxWidth().background(
            Brush.verticalGradient(
                listOf(MaterialTheme.colorScheme.surfaceContainerHighest, MaterialTheme.colorScheme.surface),
            ),
        ),
    ) {
        Image(
            painter = painterResource(R.drawable.maclean_ancient_dress_tartan),
            contentDescription = null,
            modifier = Modifier.fillMaxWidth().height(7.dp),
            contentScale = ContentScale.Crop,
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                painter = painterResource(R.drawable.company_logo),
                contentDescription = null,
                modifier = Modifier.size(46.dp),
                contentScale = ContentScale.Fit,
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Maclean CRM Contacts", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("$contactCount record${if (contactCount == 1) "" else "s"} · no password", style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            HeaderButton("Add", Icons.Default.Add, onAdd)
            HeaderButton("Import VCF", Icons.Default.FileUpload, onImport)
            HeaderButton("Export", Icons.Default.Download, onExport)
            HeaderButton("Groups", Icons.Default.Groups, onGroups)
            HeaderButton("Duplicates", Icons.Default.Merge, onDuplicates)
            HeaderButton("Sort", Icons.Default.Sort, onSort)
            if (onContactsPermission != null) {
                HeaderButton("Android access", Icons.Default.Contacts, onContactsPermission)
            }
        }
    }
}

@Composable
private fun HeaderButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick) {
        Icon(icon, contentDescription = null)
        Text(" $label")
    }
}

@Composable
private fun SelectionToolbar(
    count: Int,
    working: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onExport: () -> Unit,
    onShare: () -> Unit,
    onGroups: () -> Unit,
    onMerge: () -> Unit,
    onDelete: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.secondaryContainer)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Clear selection") }
            Text("$count selected", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onSelectAll) { Icon(Icons.Default.SelectAll, null); Text(" Select All") }
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            HeaderButton("Copy / storage", Icons.Default.ContentCopy, onCopy)
            HeaderButton("Export", Icons.Default.Download, onExport)
            HeaderButton("Share", Icons.Default.Share, onShare)
            HeaderButton("Groups", Icons.Default.Groups, onGroups)
            OutlinedButton(enabled = count >= 2 && !working, onClick = onMerge) {
                Icon(Icons.Default.Merge, null); Text(" Merge")
            }
            OutlinedButton(enabled = !working, onClick = onDelete) {
                Icon(Icons.Default.Delete, null); Text(" Delete")
            }
        }
    }
}

@Composable
private fun GroupFilterRow(
    groups: List<CrmGroup>,
    selectedGroupId: Long?,
    favoritesOnly: Boolean,
    onSelectGroup: (Long?) -> Unit,
    onSelectFavorites: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        FilterChip(
            selected = selectedGroupId == null && !favoritesOnly,
            onClick = { onSelectGroup(null) },
            label = { Text("All") },
        )
        FilterChip(
            selected = favoritesOnly,
            onClick = onSelectFavorites,
            label = { Text("Favorites") },
            leadingIcon = { Icon(Icons.Default.Star, contentDescription = null) },
        )
        groups.forEach { group ->
            FilterChip(
                selected = !favoritesOnly && selectedGroupId == group.id,
                onClick = { onSelectGroup(group.id) },
                label = { Text(group.name) },
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CrmContactCard(
    contact: CrmContact,
    groups: List<CrmGroup>,
    selected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onCall: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selected) Icon(Icons.Default.CheckCircle, "Selected", modifier = Modifier.size(52.dp))
            else ContactListPhoto(contact)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        contact.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    if (contact.favorite) Icon(Icons.Default.Star, "Favorite", tint = MaterialTheme.colorScheme.primary)
                }
                if (contact.company.isNotBlank()) Text(contact.company, style = MaterialTheme.typography.bodySmall)
                if (contact.primaryPhone.isNotBlank()) Text(contact.primaryPhone, style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(contact.storage.label, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                    if (contact.readOnly) Text("• read-only", style = MaterialTheme.typography.labelSmall)
                    groups.filter { it.id in contact.groupIds }.forEach { Text("• ${it.name}", style = MaterialTheme.typography.labelSmall) }
                }
            }
            if (!selectionMode && contact.primaryPhone.isNotBlank()) {
                IconButton(onClick = onCall) { Icon(Icons.Default.Call, "Call ${contact.displayName}") }
            }
        }
    }
}

@Composable
private fun ContactListPhoto(contact: CrmContact) {
    if (contact.photoUri != null) {
        AsyncImage(
            model = contact.photoUri,
            contentDescription = null,
            modifier = Modifier.size(52.dp).clip(CircleShape),
            contentScale = ContentScale.Crop,
        )
    } else {
        Box(
            modifier = Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                contact.displayName.split(Regex("\\s+")).filter(String::isNotBlank).take(2)
                    .joinToString("") { it.take(1) }.uppercase().ifBlank { "?" },
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun ContactActionsDialog(
    contact: CrmContact,
    groups: List<CrmGroup>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onSystemDetails: () -> Unit,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onEmail: () -> Unit,
    onFavorite: () -> Unit,
    onCopy: () -> Unit,
    onExport: () -> Unit,
    onShare: () -> Unit,
    onGroups: () -> Unit,
    onMerge: () -> Unit,
    onDelete: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(18.dp), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ContactListPhoto(contact)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(contact.displayName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(contact.storage.label + if (contact.readOnly) " · read-only" else "")
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                contact.customFields
                    .filter { it.type == CrmFieldType.PHONE && it.value.isNotBlank() }
                    .forEachIndexed { index, phone ->
                        Text(
                            "${phone.label.ifBlank { "Phone" }}: ${phone.completeValue()}" +
                                if (index == 0) " • Primary" else "",
                            modifier = if (index == 0) Modifier.padding(top = 8.dp) else Modifier,
                        )
                    }
                if (contact.primaryEmail.isNotBlank()) Text(contact.primaryEmail)
                if (contact.company.isNotBlank()) Text(contact.company)
                val names = groups.filter { it.id in contact.groupIds }.joinToString { it.name }
                if (names.isNotBlank()) Text("Groups: $names", style = MaterialTheme.typography.bodySmall)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    OutlinedButton(enabled = contact.primaryPhone.isNotBlank(), onClick = onCall) { Icon(Icons.Default.Call, null); Text(" Call") }
                    OutlinedButton(enabled = contact.primaryPhone.isNotBlank(), onClick = onMessage) { Icon(Icons.Default.Message, null); Text(" Message") }
                    OutlinedButton(enabled = contact.primaryEmail.isNotBlank(), onClick = onEmail) { Icon(Icons.Default.Email, null); Text(" Email") }
                }
                ActionRow(if (contact.readOnly) "Edit as app copy" else "Edit", Icons.Default.Edit, onEdit)
                if (contact.systemContactId != null) {
                    ActionRow("Android contact details", Icons.Default.Contacts, onSystemDetails)
                }
                ActionRow(if (contact.favorite) "Remove favorite" else "Add favorite", if (contact.favorite) Icons.Default.Star else Icons.Default.StarBorder, onFavorite)
                ActionRow("Copy / save to storage", Icons.Default.ContentCopy, onCopy)
                ActionRow("Add or remove groups", Icons.Default.Groups, onGroups)
                ActionRow("Export VCF", Icons.Default.Download, onExport)
                ActionRow("Share VCF", Icons.Default.Share, onShare)
                ActionRow("Select for merge", Icons.Default.Merge, onMerge)
                ActionRow("Delete contact", Icons.Default.Delete, onDelete)
            }
        }
    }
}

@Composable
private fun ActionRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, contentDescription = null)
        Text("  $label", modifier = Modifier.weight(1f))
    }
}

@Composable
private fun EmptyContacts(favoritesOnly: Boolean, onAdd: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Contacts, null, Modifier.size(64.dp))
            Text(
                if (favoritesOnly) "No favorite contacts yet" else "No matching CRM contacts",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                if (favoritesOnly) "Mark a contact with the star to find it here."
                else "English, Spanish, Russian, Unicode, and emoji are supported.",
            )
            Button(onClick = onAdd, modifier = Modifier.padding(top = 12.dp)) { Text("Add contact") }
        }
    }
}

@Composable
private fun SortDialog(
    selected: CrmSortField,
    ascending: Boolean,
    onDismiss: () -> Unit,
    onApply: (CrmSortField, Boolean) -> Unit,
) {
    var field by remember(selected) { mutableStateOf(selected) }
    var isAscending by remember(ascending) { mutableStateOf(ascending) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sort contacts") },
        text = {
            Column {
                CrmSortField.entries.forEach { option ->
                    Row(
                        Modifier.fillMaxWidth().clickable { field = option }.padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(field == option, onClick = null)
                        Text(option.label)
                    }
                }
                Divider()
                Row(
                    Modifier.fillMaxWidth().clickable { isAscending = !isAscending }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(if (isAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward, null)
                    Text(if (isAscending) " Ascending" else " Descending")
                }
            }
        },
        confirmButton = { Button(onClick = { onApply(field, isAscending) }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun StorageDialog(
    title: String,
    options: List<ContactStorageOption>,
    onDismiss: () -> Unit,
    onSelect: (ContactStorage) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.ifEmpty {
                    listOf(ContactStorageOption(ContactStorage.APP, detail = "Stored privately in Maclean Phone."))
                }.forEach { option ->
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        enabled = option.enabled,
                        onClick = { onSelect(option.storage) },
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(option.storage.label)
                            Text(option.detail, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun MembershipDialog(
    contactCount: Int,
    groups: List<CrmGroup>,
    onDismiss: () -> Unit,
    onApply: (Set<Long>, Boolean) -> Unit,
) {
    var selected by remember { mutableStateOf(emptySet<Long>()) }
    var add by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Groups for $contactCount contact${if (contactCount == 1) "" else "s"}") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(add, { add = true }); Text("Add")
                    RadioButton(!add, { add = false }); Text("Remove")
                }
                LazyColumn(Modifier.height(300.dp)) {
                    items(groups, key = CrmGroup::id) { group ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                selected = if (group.id in selected) selected - group.id else selected + group.id
                            }.padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(group.id in selected, onCheckedChange = null)
                            Text(group.name)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = selected.isNotEmpty(), onClick = { onApply(selected, add) }) {
                Text(if (add) "Add to groups" else "Remove from groups")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ExportScopeDialog(
    hasSelection: Boolean,
    selectedGroup: CrmGroup?,
    onDismiss: () -> Unit,
    onAll: () -> Unit,
    onCurrent: () -> Unit,
    onSelected: () -> Unit,
    onGroup: (CrmGroup) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export VCF") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAll, modifier = Modifier.fillMaxWidth()) { Text("All contacts") }
                OutlinedButton(onClick = onCurrent, modifier = Modifier.fillMaxWidth()) { Text("Current filtered view") }
                if (hasSelection) OutlinedButton(onClick = onSelected, modifier = Modifier.fillMaxWidth()) { Text("Selected contacts") }
                if (selectedGroup != null) OutlinedButton(
                    onClick = { onGroup(selectedGroup) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Entire ${selectedGroup.name} group") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ConfirmActionDialog(
    title: String,
    text: String,
    action: String,
    confirmEnabled: Boolean = true,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { Button(enabled = confirmEnabled, onClick = onConfirm) { Text(action) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun DuplicateDialog(
    matches: List<DuplicateMatch>,
    onDismiss: () -> Unit,
    onSelect: (DuplicateMatch) -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(18.dp), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Possible duplicates", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                Text("Candidates are never merged automatically. Similar names alone are not treated as a match.")
                LazyColumn(Modifier.height(380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(matches) { match ->
                        Card(onClick = { onSelect(match) }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(match.contacts.joinToString { it.displayName }, fontWeight = FontWeight.Bold)
                                Text(match.reasons.joinToString(), style = MaterialTheme.typography.bodySmall)
                                Text("Tap to select these contacts, then review and merge.")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupManagerDialog(
    groups: List<CrmGroup>,
    working: Boolean,
    onDismiss: () -> Unit,
    onSave: (CrmGroup, () -> Unit) -> Unit,
    onDelete: (Long) -> Unit,
    onMove: (Long, Int) -> Unit,
    onExport: (CrmGroup) -> Unit,
    onShare: (CrmGroup) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<CrmGroup?>(null) }
    var deleting by remember { mutableStateOf<CrmGroup?>(null) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(20.dp), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Contact groups", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close group manager") }
                }
                Text("Create, rename, reorder, export, share, and manage membership through contact selection.")
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), label = { Text("New group") }, singleLine = true)
                    IconButton(
                        enabled = name.isNotBlank() && !working,
                        onClick = { onSave(CrmGroup(name = name)) { name = "" } },
                    ) { Icon(Icons.Default.Add, "Add group") }
                }
                LazyColumn(Modifier.fillMaxWidth().height(390.dp)) {
                    items(groups, key = CrmGroup::id) { group ->
                        Column {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(group.name, Modifier.weight(1f))
                                IconButton(onClick = { onMove(group.id, -1) }) { Icon(Icons.Default.ArrowUpward, "Move up") }
                                IconButton(onClick = { onMove(group.id, 1) }) { Icon(Icons.Default.ArrowDownward, "Move down") }
                                IconButton(onClick = { editing = group }) { Icon(Icons.Default.Edit, "Rename") }
                                IconButton(onClick = { deleting = group }) { Icon(Icons.Outlined.DeleteOutline, "Delete") }
                            }
                            Row {
                                TextButton(onClick = { onExport(group) }) { Icon(Icons.Default.Download, null); Text(" Export") }
                                TextButton(onClick = { onShare(group) }) { Icon(Icons.Default.Share, null); Text(" Share") }
                            }
                            Divider()
                        }
                    }
                }
                Button(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Done") }
            }
        }
    }
    editing?.let { group ->
        var editedName by remember(group) { mutableStateOf(group.name) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Rename group") },
            text = { OutlinedTextField(editedName, { editedName = it }, label = { Text("Group name") }) },
            confirmButton = {
                Button(enabled = editedName.isNotBlank(), onClick = {
                    onSave(group.copy(name = editedName)) { editing = null }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } },
        )
    }
    deleting?.let { group ->
        ConfirmActionDialog(
            title = "Delete ${group.name}?",
            text = "Only the group and its memberships will be removed. Its contacts will be kept.",
            action = "Delete group",
            onDismiss = { deleting = null },
            onConfirm = {
                deleting = null
                onDelete(group.id)
            },
        )
    }
}

private fun launchSendTo(context: android.content.Context, scheme: String, value: String) {
    if (value.isBlank()) return
    val uri = Uri.parse("$scheme:${Uri.encode(value)}")
    runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, uri)) }
}
