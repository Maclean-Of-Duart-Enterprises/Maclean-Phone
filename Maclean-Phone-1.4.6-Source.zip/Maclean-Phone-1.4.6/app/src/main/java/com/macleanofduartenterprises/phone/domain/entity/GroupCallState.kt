package com.macleanofduartenterprises.phone.domain.entity

data class GroupCallState(
    val participants: List<GroupCallParticipant> = emptyList(),
    val foregroundCallId: String? = null,
    val foregroundIsIncoming: Boolean = false,
    val calledLine: CalledLineInfo = CalledLineInfo.Unknown,
    val outgoingLine: CalledLineInfo = CalledLineInfo.Unknown,
    val canAddCall: Boolean = false,
    val canMerge: Boolean = false,
    val canSwap: Boolean = false,
    val isConference: Boolean = false,
    val canManageConference: Boolean = false,
    val statusMessage: String? = null,
) {
    val foregroundPhone: String
        get() = participants.firstOrNull { it.id == foregroundCallId }?.phone.orEmpty()

    companion object {
        val Empty = GroupCallState()
    }
}

data class GroupCallParticipant(
    val id: String,
    val name: String,
    val phone: String,
    val state: GroupCallParticipantState,
    val isForeground: Boolean,
    val canSeparate: Boolean,
    val canDisconnect: Boolean,
)

enum class GroupCallParticipantState {
    RINGING,
    CONNECTING,
    DIALING,
    ACTIVE,
    HELD,
    DISCONNECTED,
    UNKNOWN,
}
