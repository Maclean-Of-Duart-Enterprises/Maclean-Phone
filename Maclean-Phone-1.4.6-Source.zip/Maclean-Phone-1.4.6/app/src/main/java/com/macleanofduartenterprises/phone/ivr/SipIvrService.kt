package com.macleanofduartenterprises.phone.ivr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.macleanofduartenterprises.phone.MainActivity
import com.macleanofduartenterprises.phone.R
import com.macleanofduartenterprises.phone.core.AccessibilityPreferences
import dagger.hilt.android.AndroidEntryPoint
import java.io.File
import java.util.ArrayDeque
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.linphone.core.Account
import org.linphone.core.Address
import org.linphone.core.Call
import org.linphone.core.Core
import org.linphone.core.CoreListenerStub
import org.linphone.core.Factory
import org.linphone.core.Player
import org.linphone.core.PlayerListenerStub
import org.linphone.core.Reason
import org.linphone.core.RegistrationState
import org.linphone.core.TransportType

@AndroidEntryPoint
class SipIvrService : Service() {
    @Inject
    lateinit var settingsRepository: IvrSettingsRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var engineJob: Job? = null

    private var core: Core? = null
    private var account: Account? = null
    private var config = IvrConfig()
    private var prompts: IvrPromptSet? = null

    private var activeCall: Call? = null
    private var menuRouter: IvrMenuRouter? = null
    private var menuStarted = false
    private var answerRunnable: Runnable? = null
    private var timeoutRunnable: Runnable? = null

    private val playbackQueue = ArrayDeque<File>()
    private var activePlayer: Player? = null
    private var playbackCompletion: (() -> Unit)? = null

    private val playerListener = object : PlayerListenerStub() {
        override fun onEofReached(player: Player) {
            mainHandler.post {
                closePlayer()
                playNextFile()
            }
        }
    }

    private val coreListener = object : CoreListenerStub() {
        override fun onAccountRegistrationStateChanged(
            core: Core,
            account: Account,
            state: RegistrationState,
            message: String
        ) {
            mainHandler.post {
                when (state) {
                    RegistrationState.Ok -> updateStatus(
                        IvrServicePhase.REGISTERED,
                        "Registered and ready for incoming calls"
                    )

                    RegistrationState.Progress,
                    RegistrationState.Refreshing -> updateStatus(
                        IvrServicePhase.REGISTERING,
                        "Connecting to the SIP provider…"
                    )

                    RegistrationState.Failed -> updateStatus(
                        IvrServicePhase.ERROR,
                        message.ifBlank { "SIP registration failed." }
                    )

                    RegistrationState.Cleared -> updateStatus(
                        IvrServicePhase.STOPPED,
                        "SIP account is offline"
                    )

                    RegistrationState.None -> Unit
                }
            }
        }

        override fun onCallStateChanged(
            core: Core,
            call: Call,
            state: Call.State,
            message: String
        ) {
            mainHandler.post {
                handleCallState(call, state, message)
            }
        }

        override fun onDtmfReceived(core: Core, call: Call, dtmf: Int) {
            mainHandler.post {
                if (call == activeCall) {
                    mapDtmf(dtmf)?.let(::handleDigit)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Starting…"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action ?: ACTION_START) {
            ACTION_STOP -> {
                settingsRepository.setEnabled(false)
                stopEngine()
                updateStatus(IvrServicePhase.STOPPED, "IVR is off")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_RELOAD,
            ACTION_START -> startOrReload()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        engineJob?.cancel()
        stopEngine()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startOrReload() {
        engineJob?.cancel()
        stopEngine()
        config = settingsRepository.loadConfig().normalized()
        val password = settingsRepository.loadPassword()

        if (!config.enabled) {
            updateStatus(IvrServicePhase.STOPPED, "IVR is off")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        val errors = config.validationErrors(password)
        if (errors.isNotEmpty()) {
            updateStatus(IvrServicePhase.ERROR, errors.first())
            return
        }

        updateStatus(IvrServicePhase.STARTING, "Starting the SIP IVR…")
        engineJob = serviceScope.launch {
            updateStatus(IvrServicePhase.PREPARING_VOICES, "Preparing English and Russian prompts…")
            if (config.callForwardingEnabled) {
                prompts = null
                runCatching { startCore(password) }
                    .onFailure { error ->
                        updateStatus(
                            IvrServicePhase.ERROR,
                            error.message ?: "The SIP engine could not start."
                        )
                    }
                return@launch
            }
            val promptResult = IvrPromptSynthesizer(applicationContext).synthesize(config)
            promptResult.fold(
                onSuccess = {
                    prompts = it
                    runCatching { startCore(password) }
                        .onFailure { error ->
                            updateStatus(
                                IvrServicePhase.ERROR,
                                error.message ?: "The SIP engine could not start."
                            )
                        }
                },
                onFailure = { error ->
                    updateStatus(
                        IvrServicePhase.ERROR,
                        error.message ?: "The spoken prompts could not be prepared."
                    )
                }
            )
        }
    }

    private fun startCore(password: String) {
        updateStatus(IvrServicePhase.REGISTERING, "Connecting to the SIP provider…")
        val factory = Factory.instance()
        val newCore = factory.createCore(null, null, applicationContext)
        core = newCore
        newCore.addListener(coreListener)
        newCore.setAutoIterateEnabled(true)
        newCore.setMaxCalls(1)
        newCore.setUseRfc2833ForDtmf(true)
        newCore.setUseInfoForDtmf(true)
        newCore.setMicEnabled(false)
        newCore.setVideoCaptureEnabled(false)
        newCore.setVideoDisplayEnabled(false)
        newCore.setNativeRingingEnabled(true)
        val accessibility = AccessibilityPreferences.load(applicationContext)
        newCore.setEchoCancellationEnabled(accessibility.sipNoiseReduction)
        // The limiter intentionally remains off: it is half-duplex and can cut off
        // speech. Linphone's software/hardware echo cancellation is the safer
        // accessibility default for the SIP path.
        newCore.setEchoLimiterEnabled(false)
        check(newCore.start() == 0) { "The SIP engine failed to start." }

        val identity = requireNotNull(
            factory.createAddress("sip:${config.username}@${config.domain}")
        ) { "The SIP identity is invalid." }
        if (config.displayName.isNotBlank()) {
            identity.setDisplayName(config.displayName)
        }
        val serverAddress = requireNotNull(factory.createAddress(buildRegistrarUri())) {
            "The SIP server is invalid."
        }

        val params = newCore.createAccountParams()
        check(params.setIdentityAddress(identity) == 0) { "The SIP identity is invalid." }
        check(params.setServerAddress(serverAddress) == 0) { "The SIP server is invalid." }
        params.setTransport(config.transport.toLinphoneTransport())
        params.setRegisterEnabled(true)

        if (config.outboundProxy.isNotBlank()) {
            val route = requireNotNull(factory.createAddress(buildOutboundProxyUri())) {
                "The outbound proxy address is invalid."
            }
            check(params.setRoutesAddresses(arrayOf(route)) == 0) {
                "The outbound proxy address is invalid."
            }
        }

        val authInfo = factory.createAuthInfo(
            config.username,
            config.authUsername.ifBlank { config.username },
            password,
            null,
            null,
            config.domain
        )
        newCore.addAuthInfo(authInfo)
        val newAccount = newCore.createAccount(params)
        check(newCore.addAccount(newAccount) == 0) { "The SIP account could not be added." }
        newCore.setDefaultAccount(newAccount)
        account = newAccount
    }

    private fun handleCallState(call: Call, state: Call.State, message: String) {
        when (state) {
            Call.State.IncomingReceived,
            Call.State.PushIncomingReceived -> handleIncomingCall(call)

            Call.State.StreamsRunning -> {
                if (call == activeCall && !menuStarted) {
                    menuStarted = true
                    call.setMicrophoneMuted(true)
                    if (config.callForwardingEnabled) {
                        val destination = config.forwardingDestination()
                        updateStatus(
                            IvrServicePhase.TRANSFERRING,
                            "Forwarding to $destination",
                            callerOf(call)
                        )
                        transferCall(
                            call,
                            destination,
                            config.callForwardingTargetType ==
                                CallForwardingTargetType.PHONE_NUMBER,
                        )
                        return
                    }
                    updateStatus(
                        IvrServicePhase.IN_CALL,
                        "Playing the language menu",
                        callerOf(call)
                    )
                    handleDecision(menuRouter?.reset() ?: return)
                }
            }

            Call.State.Error -> {
                if (call == activeCall) {
                    updateStatus(
                        IvrServicePhase.ERROR,
                        message.ifBlank { "The incoming call ended with an error." }
                    )
                    clearActiveCall()
                }
            }

            Call.State.End,
            Call.State.Released -> {
                if (call == activeCall) {
                    clearActiveCall()
                    updateStatus(
                        IvrServicePhase.REGISTERED,
                        "Registered and ready for incoming calls"
                    )
                }
            }

            else -> Unit
        }
    }

    private fun handleIncomingCall(call: Call) {
        if (activeCall != null && activeCall != call) {
            call.decline(Reason.Busy)
            return
        }
        if (activeCall == call) return

        activeCall = call
        menuRouter = IvrMenuRouter(config)
        menuStarted = false
        val caller = callerOf(call)
        updateStatus(
            IvrServicePhase.ANSWERING,
            "Incoming call; answering in ${config.answerDelaySeconds} second(s)",
            caller
        )
        answerRunnable = Runnable {
            if (activeCall == call &&
                (call.state == Call.State.IncomingReceived ||
                    call.state == Call.State.PushIncomingReceived)
            ) {
                val callParams = core?.createCallParams(call)?.apply {
                    setMicEnabled(false)
                    setVideoEnabled(false)
                }
                val result = call.acceptWithParams(callParams)
                if (result != 0) {
                    updateStatus(IvrServicePhase.ERROR, "The incoming call could not be answered.")
                    call.terminate()
                }
            }
        }.also {
            mainHandler.postDelayed(it, config.answerDelaySeconds * 1_000L)
        }
    }

    private fun handleDigit(digit: Char) {
        cancelNoInputTimeout()
        stopPlayback()
        val router = menuRouter ?: return
        handleDecision(router.accept(digit))
    }

    private fun handleDecision(decision: IvrRouteDecision) {
        val call = activeCall ?: return
        val promptSet = prompts
        if (promptSet == null) {
            call.terminate()
            return
        }
        val files = mutableListOf<File>()

        if (decision.invalidSelection) {
            if (decision.language == null) {
                files += promptSet.invalidEnglish
                files += promptSet.invalidRussian
            } else {
                files += promptSet.invalid(decision.language)
            }
        }

        when (decision.command) {
            IvrRouteCommand.PLAY_LANGUAGE_MENU -> {
                files += promptSet.languageEnglish
                files += promptSet.languageRussian
                playFiles(call, files) { scheduleNoInputTimeout() }
            }

            IvrRouteCommand.PLAY_DIRECTORY -> {
                val language = decision.language ?: IvrLanguage.ENGLISH
                files += promptSet.directory(language)
                updateStatus(IvrServicePhase.IN_CALL, "Waiting for a directory selection", callerOf(call))
                playFiles(call, files) { scheduleNoInputTimeout() }
            }

            IvrRouteCommand.TRANSFER -> {
                val language = decision.language ?: IvrLanguage.ENGLISH
                files += promptSet.transfer(language)
                updateStatus(
                    IvrServicePhase.TRANSFERRING,
                    "Transferring to ${decision.destination}",
                    callerOf(call)
                )
                playFiles(call, files) {
                    transferCall(call, decision.destination)
                }
            }

            IvrRouteCommand.HANG_UP -> {
                val language = decision.language ?: IvrLanguage.ENGLISH
                files += promptSet.goodbye(language)
                playFiles(call, files) { call.terminate() }
            }
        }
    }

    private fun transferCall(
        call: Call,
        destination: String,
        isPhoneNumber: Boolean = false,
    ) {
        val address = runCatching {
            Factory.instance().createAddress(transferUri(destination, isPhoneNumber))
        }.getOrNull()
        if (address == null || call.transferTo(address) != 0) {
            updateStatus(
                IvrServicePhase.ERROR,
                "The provider rejected the transfer to $destination."
            )
            call.terminate()
        }
    }

    private fun playFiles(call: Call, files: List<File>, onComplete: () -> Unit) {
        stopPlayback()
        playbackQueue.addAll(files.filter(File::exists))
        playbackCompletion = onComplete
        if (playbackQueue.isEmpty()) {
            onComplete()
        } else {
            playNextFile(call)
        }
    }

    private fun playNextFile(call: Call? = activeCall) {
        val currentCall = call ?: return
        val next = playbackQueue.pollFirst()
        if (next == null) {
            val completion = playbackCompletion
            playbackCompletion = null
            completion?.invoke()
            return
        }

        val player = currentCall.player
        if (player == null) {
            updateStatus(IvrServicePhase.ERROR, "The call audio player is unavailable.")
            currentCall.terminate()
            return
        }
        activePlayer = player
        player.addListener(playerListener)
        if (player.open(next.absolutePath) != 0 || player.start() != 0) {
            closePlayer()
            playNextFile(currentCall)
        }
    }

    private fun stopPlayback() {
        playbackQueue.clear()
        playbackCompletion = null
        closePlayer()
    }

    private fun closePlayer() {
        activePlayer?.let { player ->
            runCatching { player.removeListener(playerListener) }
            runCatching { player.close() }
        }
        activePlayer = null
    }

    private fun scheduleNoInputTimeout() {
        cancelNoInputTimeout()
        val router = menuRouter ?: return
        timeoutRunnable = Runnable {
            handleDecision(router.noInput())
        }.also {
            mainHandler.postDelayed(it, config.noInputTimeoutSeconds * 1_000L)
        }
    }

    private fun cancelNoInputTimeout() {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
    }

    private fun clearActiveCall() {
        answerRunnable?.let(mainHandler::removeCallbacks)
        answerRunnable = null
        cancelNoInputTimeout()
        stopPlayback()
        activeCall = null
        menuRouter = null
        menuStarted = false
    }

    private fun stopEngine() {
        activeCall?.let { call -> runCatching { call.terminate() } }
        clearActiveCall()
        core?.let { currentCore ->
            runCatching { currentCore.removeListener(coreListener) }
            runCatching { currentCore.stop() }
        }
        core = null
        account = null
        prompts = null
    }

    private fun buildRegistrarUri(): String {
        val host = config.sipServer.substringBefore(';').substringBefore(':')
        val transport = config.transport.name.lowercase()
        return "sip:$host:${config.sipPort};transport=$transport"
    }

    private fun buildOutboundProxyUri(): String {
        val raw = config.outboundProxy
        val withScheme = if (raw.startsWith("sip:") || raw.startsWith("sips:")) raw else "sip:$raw"
        return if (";transport=" in withScheme) {
            withScheme
        } else {
            "$withScheme;transport=${config.transport.name.lowercase()}"
        }
    }

    private fun transferUri(destination: String, isPhoneNumber: Boolean = false): String {
        val trimmed = destination.trim()
        return when {
            trimmed.startsWith("sip:", ignoreCase = true) ||
                trimmed.startsWith("sips:", ignoreCase = true) -> trimmed

            '@' in trimmed -> "sip:$trimmed"
            isPhoneNumber -> "sip:${IvrConfig.normalizePhoneNumber(trimmed)}@${config.domain};user=phone"
            else -> "sip:$trimmed@${config.domain}"
        }
    }

    private fun mapDtmf(value: Int): Char? = when {
        value in '0'.code..'9'.code -> value.toChar()
        value in 0..9 -> ('0'.code + value).toChar()
        value == '*'.code || value == 10 -> '*'
        value == '#'.code || value == 11 -> '#'
        else -> null
    }

    private fun callerOf(call: Call): String =
        runCatching { call.remoteAddress.asStringUriOnly() }.getOrDefault("Unknown caller")

    private fun updateStatus(phase: IvrServicePhase, detail: String, caller: String? = null) {
        SipIvrRuntime.update(IvrRuntimeStatus(phase, detail, caller))
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(detail))
    }

    private fun buildNotification(detail: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.app_logo_short_notification)
            .setContentTitle("Maclean Phone IVR")
            .setContentText(detail)
            .setContentIntent(openIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "SIP IVR service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the SIP line registered and ready to answer calls."
                setShowBadge(false)
            }
        )
    }

    private fun SipTransport.toLinphoneTransport(): TransportType = when (this) {
        SipTransport.TLS -> TransportType.Tls
        SipTransport.TCP -> TransportType.Tcp
        SipTransport.UDP -> TransportType.Udp
    }

    companion object {
        private const val NOTIFICATION_ID = 2_701
        private const val NOTIFICATION_CHANNEL_ID = "maclean_phone_sip_ivr"
        const val ACTION_START = "com.macleanofduartenterprises.phone.ivr.START"
        const val ACTION_STOP = "com.macleanofduartenterprises.phone.ivr.STOP"
        const val ACTION_RELOAD = "com.macleanofduartenterprises.phone.ivr.RELOAD"

        fun intent(context: Context, action: String): Intent =
            Intent(context, SipIvrService::class.java).setAction(action)
    }
}
