package com.macleanofduartenterprises.phone.core

import android.content.Context
import android.content.SharedPreferences
import com.google.i18n.phonenumbers.PhoneNumberUtil
import java.util.Locale

object PhoneSettingsPrefs {
    const val PREFS_NAME = "phone_settings_preferences"

    const val KEY_CALLER_ID_SPAM = "caller_id_spam"
    const val KEY_LLAMA_CALLER_ASSISTANT = "llama_caller_assistant"
    const val KEY_LLAMA_AUTO_SILENCE = "llama_auto_silence"
    const val KEY_ASSISTED_DIALING = "assisted_dialing"
    const val KEY_ASSISTED_DIALING_REGION = "assisted_dialing_region"
    const val KEY_THEME_MODE = "theme_mode"
    const val KEY_INCOMING_GESTURE = "incoming_gesture"
    const val KEY_CALLER_ID_ANNOUNCEMENT = "caller_id_announcement"
    const val KEY_FLIP_TO_SILENCE = "flip_to_silence"
    const val KEY_HOME_OPENING_PAGE = "home_opening_page"
    const val KEY_LAST_USED_HOME_TAB = "last_used_home_tab"

    private const val KEY_QUICK_RESPONSE_PREFIX = "quick_response_"

    val defaultQuickResponses = listOf(
        "Can't talk right now. What's up?",
        "I'll call you right back.",
        "I'll call you later.",
        "Can't talk right now. Call me later?",
    )

    enum class ThemeMode(val label: String) {
        SYSTEM("Use system theme"),
        LIGHT("Light"),
        DARK("Dark"),
    }

    enum class IncomingGesture(val label: String) {
        BUTTONS("Tap buttons"),
        SWIPE("Swipe to answer"),
    }

    enum class CallerIdAnnouncement(val label: String) {
        NEVER("Never"),
        HEADSET_ONLY("Only with a headset"),
        ALWAYS("Always"),
    }

    enum class HomeOpeningPage(val label: String) {
        CONTACTS("Contacts"),
        RECENTS("Recents"),
        LAST_USED("Last used"),
    }

    enum class HomeTab {
        CONTACTS,
        RECENTS,
    }

    fun preferences(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun callerIdSpamEnabled(context: Context): Boolean =
        preferences(context).getBoolean(KEY_CALLER_ID_SPAM, true)

    fun llamaCallerAssistantEnabled(context: Context): Boolean =
        preferences(context).getBoolean(KEY_LLAMA_CALLER_ASSISTANT, true)

    fun llamaAutoSilenceEnabled(context: Context): Boolean =
        preferences(context).getBoolean(KEY_LLAMA_AUTO_SILENCE, false)

    fun assistedDialingEnabled(context: Context): Boolean =
        preferences(context).getBoolean(KEY_ASSISTED_DIALING, false)

    fun assistedDialingRegion(context: Context): String =
        preferences(context)
            .getString(KEY_ASSISTED_DIALING_REGION, Locale.getDefault().country)
            .orEmpty()
            .ifBlank { "US" }
            .uppercase(Locale.ROOT)

    fun themeMode(context: Context): ThemeMode =
        preferences(context)
            .getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name)
            .toEnumOrDefault(ThemeMode.SYSTEM)

    fun incomingGesture(context: Context): IncomingGesture =
        preferences(context)
            .getString(KEY_INCOMING_GESTURE, IncomingGesture.BUTTONS.name)
            .toEnumOrDefault(IncomingGesture.BUTTONS)

    fun callerIdAnnouncement(context: Context): CallerIdAnnouncement =
        preferences(context)
            .getString(KEY_CALLER_ID_ANNOUNCEMENT, CallerIdAnnouncement.NEVER.name)
            .toEnumOrDefault(CallerIdAnnouncement.NEVER)

    fun flipToSilenceEnabled(context: Context): Boolean =
        preferences(context).getBoolean(KEY_FLIP_TO_SILENCE, false)

    fun homeOpeningPage(context: Context): HomeOpeningPage =
        preferences(context)
            .getString(KEY_HOME_OPENING_PAGE, HomeOpeningPage.RECENTS.name)
            .toEnumOrDefault(HomeOpeningPage.RECENTS)

    fun saveHomeOpeningPage(context: Context, page: HomeOpeningPage) {
        preferences(context).edit().putString(KEY_HOME_OPENING_PAGE, page.name).apply()
    }

    fun lastUsedHomeTab(context: Context): HomeTab =
        preferences(context)
            .getString(KEY_LAST_USED_HOME_TAB, HomeTab.RECENTS.name)
            .toEnumOrDefault(HomeTab.RECENTS)

    fun saveLastUsedHomeTab(context: Context, tab: HomeTab) {
        preferences(context).edit().putString(KEY_LAST_USED_HOME_TAB, tab.name).apply()
    }

    fun resolveOpeningHomeTab(
        openingPage: HomeOpeningPage,
        lastUsed: HomeTab,
    ): HomeTab = when (openingPage) {
        HomeOpeningPage.CONTACTS -> HomeTab.CONTACTS
        HomeOpeningPage.RECENTS -> HomeTab.RECENTS
        HomeOpeningPage.LAST_USED -> lastUsed
    }

    fun quickResponses(context: Context): List<String> {
        val prefs = preferences(context)
        return defaultQuickResponses.mapIndexed { index, fallback ->
            prefs.getString("$KEY_QUICK_RESPONSE_PREFIX$index", fallback)
                .orEmpty()
                .ifBlank { fallback }
        }
    }

    fun saveQuickResponses(context: Context, responses: List<String>) {
        preferences(context).edit().apply {
            defaultQuickResponses.indices.forEach { index ->
                val fallback = defaultQuickResponses[index]
                putString(
                    "$KEY_QUICK_RESPONSE_PREFIX$index",
                    responses.getOrNull(index).orEmpty().ifBlank { fallback },
                )
            }
        }.apply()
    }

    fun applyAssistedDialing(context: Context, rawPhone: String): String {
        if (!assistedDialingEnabled(context)) return rawPhone
        val trimmed = rawPhone.trim()
        if (trimmed.startsWith("+") || trimmed.startsWith("*") || trimmed.startsWith("#")) {
            return rawPhone
        }
        if (trimmed.count(Char::isDigit) < 7) return rawPhone

        return runCatching {
            val phoneUtil = PhoneNumberUtil.getInstance()
            val parsed = phoneUtil.parse(trimmed, assistedDialingRegion(context))
            if (phoneUtil.isValidNumber(parsed)) {
                phoneUtil.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164)
            } else {
                rawPhone
            }
        }.getOrDefault(rawPhone)
    }

    private inline fun <reified T : Enum<T>> String?.toEnumOrDefault(default: T): T =
        runCatching { enumValueOf<T>(this.orEmpty()) }.getOrDefault(default)
}
