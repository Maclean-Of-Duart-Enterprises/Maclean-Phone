package com.macleanofduartenterprises.phone.core

import android.content.Context
import androidx.core.content.edit

object CallingAccountPreferences {
    private const val KEY_MODE = "calling_account_mode"
    private const val KEY_ACCOUNT_KEY = "calling_account_key"
    private const val LEGACY_KEY_ACCOUNT_ID = "calling_account_id"

    enum class Mode(val label: String) {
        SYSTEM_DEFAULT("System default"),
        ASK_EVERY_TIME("Ask every time"),
        SPECIFIC_ACCOUNT("Selected calling account"),
    }

    data class Snapshot(
        val mode: Mode = Mode.SYSTEM_DEFAULT,
        val accountKey: String = "",
    )

    fun load(
        context: Context,
        accounts: List<CallingAccountInfo> = CallingAccountCatalog.load(context),
    ): Snapshot {
        val prefs = PhoneSettingsPrefs.preferences(context)
        val modeName = prefs.getString(KEY_MODE, Mode.SYSTEM_DEFAULT.name).orEmpty()
        val storedKey = prefs.getString(KEY_ACCOUNT_KEY, null)
            ?: prefs.getString(LEGACY_KEY_ACCOUNT_ID, "").orEmpty()
        val snapshot = migrate(modeName, storedKey, accounts)
        if (modeName == "SPECIFIC_SIM" ||
            (storedKey.isNotBlank() && storedKey != snapshot.accountKey)
        ) {
            save(context, snapshot)
        }
        return snapshot
    }

    fun migrate(
        modeName: String,
        storedAccount: String,
        accounts: List<CallingAccountInfo>,
    ): Snapshot {
        val mode = when (modeName) {
            "SPECIFIC_SIM", Mode.SPECIFIC_ACCOUNT.name -> Mode.SPECIFIC_ACCOUNT
            Mode.ASK_EVERY_TIME.name -> Mode.ASK_EVERY_TIME
            else -> Mode.SYSTEM_DEFAULT
        }
        val migratedKey = if (mode == Mode.SPECIFIC_ACCOUNT) {
            CallingAccountCatalog.resolve(storedAccount, accounts)?.key ?: storedAccount
        } else {
            ""
        }
        return Snapshot(
            mode = mode,
            accountKey = migratedKey,
        )
    }

    fun save(context: Context, snapshot: Snapshot) {
        PhoneSettingsPrefs.preferences(context).edit {
            putString(KEY_MODE, snapshot.mode.name)
            putString(KEY_ACCOUNT_KEY, snapshot.accountKey)
        }
    }
}

sealed interface CallingAccountSelection {
    data object SystemDefault : CallingAccountSelection
    data object ShowChooser : CallingAccountSelection
    data class Specific(val account: CallingAccountInfo) : CallingAccountSelection
}

object CallingAccountSelectionPolicy {
    fun select(
        snapshot: CallingAccountPreferences.Snapshot,
        accounts: List<CallingAccountInfo>,
    ): CallingAccountSelection = when (snapshot.mode) {
        CallingAccountPreferences.Mode.SYSTEM_DEFAULT -> CallingAccountSelection.SystemDefault
        CallingAccountPreferences.Mode.ASK_EVERY_TIME -> CallingAccountSelection.ShowChooser
        CallingAccountPreferences.Mode.SPECIFIC_ACCOUNT -> {
            CallingAccountCatalog.resolve(snapshot.accountKey, accounts)
                ?.takeIf(CallingAccountInfo::supportsTelephoneNumbers)
                ?.let(CallingAccountSelection::Specific)
                ?: CallingAccountSelection.ShowChooser
        }
    }
}
