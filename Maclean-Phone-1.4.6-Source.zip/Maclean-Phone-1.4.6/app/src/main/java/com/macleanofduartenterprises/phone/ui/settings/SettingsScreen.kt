package com.macleanofduartenterprises.phone.ui.settings

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Dialpad
import androidx.compose.material.icons.outlined.DisplaySettings
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PhoneInTalk
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.ScreenRotationAlt
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.SimCard
import androidx.compose.material.icons.outlined.Swipe
import androidx.compose.material.icons.outlined.Voicemail
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.macleanofduartenterprises.phone.App
import com.macleanofduartenterprises.phone.R
import com.macleanofduartenterprises.phone.core.DtmfTonePrefs
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import com.macleanofduartenterprises.phone.ui.accessibility.LocalAccessibilitySettings
import com.macleanofduartenterprises.phone.util.SystemCallRoleManager
import com.macleanofduartenterprises.phone.util.SystemCallRoleManager.CallRole

private enum class SettingsDialog {
    CALLER_ID_SPAM,
    ASSISTED_DIALING,
    DEFAULT_OPENING_PAGE,
    DISPLAY_OPTIONS,
    INCOMING_GESTURE,
    QUICK_RESPONSES,
    SOUNDS,
    CALLER_ID_ANNOUNCEMENT,
    CLEAR_LOGS,
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    onBlockedNumbersClick: () -> Unit,
    onIvrSettingsClick: () -> Unit,
    onAccessibilitySettingsClick: () -> Unit,
    onCallingAccountsClick: () -> Unit,
    onAppearanceSettingsClick: () -> Unit,
    onNotificationSettingsClick: () -> Unit,
    onVoicemailSettingsClick: () -> Unit,
    onLicenseClick: () -> Unit,
    vm: SettingsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val phonePrefs = remember(context) { PhoneSettingsPrefs.preferences(context) }
    var activeDialog by remember { mutableStateOf<SettingsDialog?>(null) }
    var callerIdSpamEnabled by remember {
        mutableStateOf(PhoneSettingsPrefs.callerIdSpamEnabled(context))
    }
    var llamaCallerAssistantEnabled by remember {
        mutableStateOf(PhoneSettingsPrefs.llamaCallerAssistantEnabled(context))
    }
    var llamaAutoSilenceEnabled by remember {
        mutableStateOf(PhoneSettingsPrefs.llamaAutoSilenceEnabled(context))
    }
    var callerIdRoleHeld by remember {
        mutableStateOf(SystemCallRoleManager.isHeld(context, CallRole.CALLER_ID_AND_SPAM))
    }
    var roleMessage by remember { mutableStateOf<String?>(null) }
    var assistedDialingEnabled by remember {
        mutableStateOf(PhoneSettingsPrefs.assistedDialingEnabled(context))
    }
    var assistedDialingRegion by remember {
        mutableStateOf(PhoneSettingsPrefs.assistedDialingRegion(context))
    }
    var homeOpeningPage by remember {
        mutableStateOf(PhoneSettingsPrefs.homeOpeningPage(context))
    }
    var themeMode by remember {
        mutableStateOf(PhoneSettingsPrefs.themeMode(context))
    }
    var incomingGesture by remember {
        mutableStateOf(PhoneSettingsPrefs.incomingGesture(context))
    }
    var callerIdAnnouncement by remember {
        mutableStateOf(PhoneSettingsPrefs.callerIdAnnouncement(context))
    }
    var flipToSilenceEnabled by remember {
        mutableStateOf(PhoneSettingsPrefs.flipToSilenceEnabled(context))
    }
    var quickResponses by remember {
        mutableStateOf(PhoneSettingsPrefs.quickResponses(context))
    }
    var dtmfTonesEnabled by remember {
        mutableStateOf(DtmfTonePrefs.isEnabled(context))
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                callerIdRoleHeld = SystemCallRoleManager.isHeld(
                    context,
                    CallRole.CALLER_ID_AND_SPAM,
                )
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun requestRole(role: CallRole) {
        val request = SystemCallRoleManager.requestIntent(context, role)
        if (request == null) {
            roleMessage = if (SystemCallRoleManager.isHeld(context, role)) {
                "Maclean Phone already has the ${role.label} role."
            } else {
                "The ${role.label} role is not available on this Android device."
            }
            return
        }
        runCatching { context.startActivity(request) }
            .onFailure { roleMessage = "Android could not open the ${role.label} chooser." }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SettingsGroup(title = "Call Assist") {
                SettingsRow(
                    icon = Icons.Outlined.Security,
                    title = "Caller ID & spam",
                    supportingText = if (callerIdRoleHeld && callerIdSpamEnabled) {
                        "Default role on • Llama Local caller assistance"
                    } else {
                        "Select Maclean Phone in Android's default-app chooser"
                    },
                    onClick = { activeDialog = SettingsDialog.CALLER_ID_SPAM },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.PhoneInTalk,
                    title = "Google Voice compatibility",
                    supportingText = "Outgoing call redirection remains available for Google Voice",
                    onClick = {
                        context.openSystemSettings(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
                    },
                )
            }

            SettingsGroup(title = "General") {
                SettingsRow(
                    icon = Icons.Outlined.Home,
                    title = "Default opening page",
                    supportingText = homeOpeningPage.label,
                    onClick = { activeDialog = SettingsDialog.DEFAULT_OPENING_PAGE },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.AccessibilityNew,
                    title = "Accessibility",
                    supportingText = "Audio assistance, TalkBack, text, controls, contrast, alerts, and Simplified Mode",
                    onClick = onAccessibilitySettingsClick,
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Public,
                    title = "Assisted dialing",
                    supportingText = if (assistedDialingEnabled) {
                        "Region $assistedDialingRegion"
                    } else {
                        "Off"
                    },
                    onClick = { activeDialog = SettingsDialog.ASSISTED_DIALING },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Block,
                    title = "Blocked numbers",
                    onClick = onBlockedNumbersClick,
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.SimCard,
                    title = "Calling accounts",
                    supportingText = "Choose a default SIM, ask each time, and manage SIP/VoIP",
                    onClick = onCallingAccountsClick,
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Palette,
                    title = "Color & appearance",
                    supportingText = "Theme, colors, tartan, or your own photo",
                    onClick = onAppearanceSettingsClick,
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Swipe,
                    title = "Incoming call gesture",
                    supportingText = incomingGesture.label,
                    onClick = { activeDialog = SettingsDialog.INCOMING_GESTURE },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.ChatBubbleOutline,
                    title = "Quick responses",
                    onClick = { activeDialog = SettingsDialog.QUICK_RESPONSES },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Notifications,
                    title = "Notifications & sounds",
                    supportingText = "Ringtone, vibration, missed-call alerts, and Android controls",
                    onClick = onNotificationSettingsClick,
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Voicemail,
                    title = "Voicemail & incoming forwarding",
                    supportingText = "Forward incoming physical-SIM calls without changing Google Voice",
                    onClick = onVoicemailSettingsClick,
                )
            }

            SettingsGroup(title = "Advanced") {
                SettingsRow(
                    icon = Icons.Outlined.Campaign,
                    title = "Caller ID announcement",
                    supportingText = callerIdAnnouncement.label,
                    onClick = { activeDialog = SettingsDialog.CALLER_ID_ANNOUNCEMENT },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.ScreenRotationAlt,
                    title = "Flip To Silence",
                    supportingText = "Silence an incoming ring by turning the phone over",
                    trailingContent = {
                        Switch(
                            checked = flipToSilenceEnabled,
                            onCheckedChange = { enabled ->
                                flipToSilenceEnabled = enabled
                                phonePrefs.edit()
                                    .putBoolean(PhoneSettingsPrefs.KEY_FLIP_TO_SILENCE, enabled)
                                    .apply()
                            },
                        )
                    },
                    onClick = {
                        flipToSilenceEnabled = !flipToSilenceEnabled
                        phonePrefs.edit()
                            .putBoolean(
                                PhoneSettingsPrefs.KEY_FLIP_TO_SILENCE,
                                flipToSilenceEnabled,
                            )
                            .apply()
                    },
                )
            }

            SettingsGroup(title = "Maclean Phone") {
                BrandIdentityPanel()
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.PhoneInTalk,
                    title = "Business IVR (SIP/VoIP)",
                    supportingText = "Auto-answer, language selection, and caller directory",
                    onClick = onIvrSettingsClick,
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.Dialpad,
                    title = "Dial pad tones",
                    supportingText = "Respect system sound settings",
                    trailingContent = {
                        Switch(
                            checked = dtmfTonesEnabled,
                            onCheckedChange = { enabled ->
                                dtmfTonesEnabled = enabled
                                DtmfTonePrefs.setEnabled(context, enabled)
                            },
                        )
                    },
                    onClick = {
                        dtmfTonesEnabled = !dtmfTonesEnabled
                        DtmfTonePrefs.setEnabled(context, dtmfTonesEnabled)
                    },
                )
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Outlined.DeleteForever,
                    title = "Clear call logs",
                    supportingText = "Delete all call history",
                    onClick = { activeDialog = SettingsDialog.CLEAR_LOGS },
                )
            }

            SettingsGroup(title = "Legal") {
                SettingsRow(
                    icon = Icons.Outlined.Gavel,
                    title = "License",
                    supportingText = "GNU Affero General Public License v3.0 (AGPLv3)",
                    onClick = onLicenseClick,
                )
            }
        }
    }

    when (activeDialog) {
        SettingsDialog.CALLER_ID_SPAM -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("Caller ID & spam") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            if (callerIdRoleHeld) {
                                "Android default role: Maclean Phone"
                            } else {
                                "Android default role: not selected"
                            },
                            style = MaterialTheme.typography.titleSmall,
                        )
                        if (!callerIdRoleHeld && SystemCallRoleManager.isAvailable(
                                context,
                                CallRole.CALLER_ID_AND_SPAM,
                            )
                        ) {
                            OutlinedButton(
                                onClick = { requestRole(CallRole.CALLER_ID_AND_SPAM) },
                            ) {
                                Text("Set as Caller ID & spam app")
                            }
                        }
                        SettingSwitchRow(
                            text = "Show caller labels and use spam detection",
                            checked = callerIdSpamEnabled,
                            onCheckedChange = { callerIdSpamEnabled = it },
                        )
                        SettingSwitchRow(
                            text = "Use Llama Local caller assistant",
                            checked = llamaCallerAssistantEnabled,
                            onCheckedChange = { llamaCallerAssistantEnabled = it },
                        )
                        SettingSwitchRow(
                            text = "Silence only high-confidence spam",
                            checked = llamaAutoSilenceEnabled,
                            onCheckedChange = { llamaAutoSilenceEnabled = it },
                        )
                        Text(
                            text = "Llama Local uses contacts, your blocked list, and call history entirely on this phone. It never uploads caller data. Unknown callers are not automatically blocked. Auto-silence applies only to a local risk score of 80 or higher.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        roleMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            phonePrefs.edit()
                                .putBoolean(
                                    PhoneSettingsPrefs.KEY_CALLER_ID_SPAM,
                                    callerIdSpamEnabled,
                                )
                                .putBoolean(
                                    PhoneSettingsPrefs.KEY_LLAMA_CALLER_ASSISTANT,
                                    llamaCallerAssistantEnabled,
                                )
                                .putBoolean(
                                    PhoneSettingsPrefs.KEY_LLAMA_AUTO_SILENCE,
                                    llamaAutoSilenceEnabled,
                                )
                                .apply()
                            App.needCallLogRefresh = true
                            activeDialog = null
                        },
                    ) {
                        Text("Done")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            callerIdSpamEnabled =
                                PhoneSettingsPrefs.callerIdSpamEnabled(context)
                            llamaCallerAssistantEnabled =
                                PhoneSettingsPrefs.llamaCallerAssistantEnabled(context)
                            llamaAutoSilenceEnabled =
                                PhoneSettingsPrefs.llamaAutoSilenceEnabled(context)
                            activeDialog = null
                        },
                    ) {
                        Text("Cancel")
                    }
                },
            )
        }

        SettingsDialog.ASSISTED_DIALING -> {
            var localEnabled by remember(activeDialog) {
                mutableStateOf(assistedDialingEnabled)
            }
            var localRegion by remember(activeDialog) {
                mutableStateOf(assistedDialingRegion)
            }
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("Assisted dialing") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingSwitchRow(
                            text = "Format local numbers for international dialing",
                            checked = localEnabled,
                            onCheckedChange = { localEnabled = it },
                        )
                        OutlinedTextField(
                            value = localRegion,
                            onValueChange = {
                                localRegion = it
                                    .filter(Char::isLetter)
                                    .take(2)
                                    .uppercase()
                            },
                            enabled = localEnabled,
                            label = { Text("Home region (for example US)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Characters,
                            ),
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = !localEnabled || localRegion.length == 2,
                        onClick = {
                            assistedDialingEnabled = localEnabled
                            assistedDialingRegion = localRegion.ifBlank { "US" }
                            phonePrefs.edit()
                                .putBoolean(
                                    PhoneSettingsPrefs.KEY_ASSISTED_DIALING,
                                    assistedDialingEnabled,
                                )
                                .putString(
                                    PhoneSettingsPrefs.KEY_ASSISTED_DIALING_REGION,
                                    assistedDialingRegion,
                                )
                                .apply()
                            activeDialog = null
                        },
                    ) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Cancel")
                    }
                },
            )
        }

        SettingsDialog.DEFAULT_OPENING_PAGE -> {
            var localPage by remember(activeDialog) { mutableStateOf(homeOpeningPage) }
            ChoiceDialog(
                title = "Default opening page",
                choices = PhoneSettingsPrefs.HomeOpeningPage.entries,
                selected = localPage,
                label = PhoneSettingsPrefs.HomeOpeningPage::label,
                onSelect = { localPage = it },
                onDismiss = { activeDialog = null },
                onSave = {
                    homeOpeningPage = localPage
                    PhoneSettingsPrefs.saveHomeOpeningPage(context, homeOpeningPage)
                    activeDialog = null
                },
            )
        }

        SettingsDialog.DISPLAY_OPTIONS -> {
            var localThemeMode by remember(activeDialog) { mutableStateOf(themeMode) }
            ChoiceDialog(
                title = "Display options",
                choices = PhoneSettingsPrefs.ThemeMode.entries,
                selected = localThemeMode,
                label = PhoneSettingsPrefs.ThemeMode::label,
                onSelect = { localThemeMode = it },
                onDismiss = { activeDialog = null },
                onSave = {
                    themeMode = localThemeMode
                    phonePrefs.edit()
                        .putString(PhoneSettingsPrefs.KEY_THEME_MODE, themeMode.name)
                        .apply()
                    activeDialog = null
                },
            )
        }

        SettingsDialog.INCOMING_GESTURE -> {
            var localGesture by remember(activeDialog) { mutableStateOf(incomingGesture) }
            ChoiceDialog(
                title = "Incoming call gesture",
                choices = PhoneSettingsPrefs.IncomingGesture.entries,
                selected = localGesture,
                label = PhoneSettingsPrefs.IncomingGesture::label,
                onSelect = { localGesture = it },
                onDismiss = { activeDialog = null },
                onSave = {
                    incomingGesture = localGesture
                    phonePrefs.edit()
                        .putString(
                            PhoneSettingsPrefs.KEY_INCOMING_GESTURE,
                            incomingGesture.name,
                        )
                        .apply()
                    activeDialog = null
                },
            )
        }

        SettingsDialog.QUICK_RESPONSES -> {
            var localResponses by remember(activeDialog) { mutableStateOf(quickResponses) }
            AlertDialog(
                modifier = Modifier.widthIn(max = 560.dp),
                onDismissRequest = { activeDialog = null },
                title = { Text("Quick responses") },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        localResponses.forEachIndexed { index, response ->
                            OutlinedTextField(
                                value = response,
                                onValueChange = { updated ->
                                    localResponses = localResponses.toMutableList().also {
                                        it[index] = updated
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Response ${index + 1}") },
                                minLines = 2,
                                maxLines = 3,
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            quickResponses = localResponses
                            PhoneSettingsPrefs.saveQuickResponses(context, quickResponses)
                            activeDialog = null
                        },
                    ) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Cancel")
                    }
                },
            )
        }

        SettingsDialog.SOUNDS -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("Sounds and vibration") },
                text = {
                    SettingSwitchRow(
                        text = "Play dial pad tones",
                        checked = dtmfTonesEnabled,
                        onCheckedChange = {
                            dtmfTonesEnabled = it
                            DtmfTonePrefs.setEnabled(context, it)
                        },
                    )
                },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Done")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            activeDialog = null
                            context.openSystemSettings(Settings.ACTION_SOUND_SETTINGS)
                        },
                    ) {
                        Text("System sounds")
                    }
                },
            )
        }

        SettingsDialog.CALLER_ID_ANNOUNCEMENT -> {
            var localAnnouncement by remember(activeDialog) {
                mutableStateOf(callerIdAnnouncement)
            }
            ChoiceDialog(
                title = "Caller ID announcement",
                choices = PhoneSettingsPrefs.CallerIdAnnouncement.entries,
                selected = localAnnouncement,
                label = PhoneSettingsPrefs.CallerIdAnnouncement::label,
                onSelect = { localAnnouncement = it },
                onDismiss = { activeDialog = null },
                onSave = {
                    callerIdAnnouncement = localAnnouncement
                    phonePrefs.edit()
                        .putString(
                            PhoneSettingsPrefs.KEY_CALLER_ID_ANNOUNCEMENT,
                            callerIdAnnouncement.name,
                        )
                        .apply()
                    activeDialog = null
                },
            )
        }

        SettingsDialog.CLEAR_LOGS -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("Clear call logs?") },
                text = {
                    Text("This will permanently delete all call history from this device.")
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            activeDialog = null
                            vm.clearAllCallLogs()
                        },
                    ) {
                        Text("Clear")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Cancel")
                    }
                },
            )
        }

        null -> Unit
    }
}

@Composable
private fun BrandIdentityPanel() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Image(
            painter = painterResource(R.drawable.app_logo_long),
            contentDescription = "Maclean Of Duart Enterprises Corp logo",
            modifier = Modifier
                .fillMaxWidth()
                .height(124.dp),
            contentScale = ContentScale.Fit,
        )
        Text(
            text = "Phone app with SIP/VoIP integration for Home and Business.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SettingsGroup(
    title: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
            ),
        ) {
            Column(content = content)
        }
    }
}

@Composable
private fun SettingsRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    supportingText: String? = null,
    trailingContent: (@Composable () -> Unit)? = null,
) {
    val accessibility = LocalAccessibilitySettings.current
    ListItem(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = if (accessibility.largeControls) 72.dp else 56.dp)
            .clickable(role = Role.Button, onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
        headlineContent = { Text(title) },
        supportingContent = supportingText?.let {
            { Text(it) }
        },
        trailingContent = trailingContent,
    )
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 64.dp),
        color = MaterialTheme.colorScheme.outlineVariant,
    )
}

@Composable
private fun SettingSwitchRow(
    text: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = text,
            modifier = Modifier.weight(1f),
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
        )
    }
}

@Composable
private fun <T> ChoiceDialog(
    title: String,
    choices: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                choices.forEach { choice ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(choice) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(
                            selected = selected == choice,
                            onClick = { onSelect(choice) },
                        )
                        Text(
                            text = label(choice),
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onSave) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

private fun Context.openSystemSettings(
    primaryAction: String,
    fallbackAction: String = Settings.ACTION_SETTINGS,
) {
    val primary = Intent(primaryAction)
    val fallback = Intent(fallbackAction)
    runCatching { startActivity(primary) }
        .recoverCatching { startActivity(fallback) }
        .recoverCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
}
