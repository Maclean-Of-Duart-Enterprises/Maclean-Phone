package com.macleanofduartenterprises.phone.ui.home

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import com.macleanofduartenterprises.phone.core.dial
import com.macleanofduartenterprises.phone.core.AccessibilityPreferences
import com.macleanofduartenterprises.phone.core.CallingAccountPreferences
import com.macleanofduartenterprises.phone.core.CallingAccountCatalog
import com.macleanofduartenterprises.phone.core.CallingAccountInfo
import com.macleanofduartenterprises.phone.core.CallingAccountSelection
import com.macleanofduartenterprises.phone.core.CallingAccountSelectionPolicy
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.ui.callLogHistory.CallLogHistoryScreen
import com.macleanofduartenterprises.phone.ui.components.AnimatedBottomBar
import com.macleanofduartenterprises.phone.ui.components.DialFab
import com.macleanofduartenterprises.phone.ui.components.CallingAccountSelectionDialog
import com.macleanofduartenterprises.phone.ui.components.PhoneNumberSelectionDialog
import com.macleanofduartenterprises.phone.ui.extensions.openContactAddScreen
import com.macleanofduartenterprises.phone.ui.extensions.openContactDetailScreen
import com.macleanofduartenterprises.phone.ui.home.calllogs.CallLogsScreen
import com.macleanofduartenterprises.phone.ui.home.contacts.ContactsScreen
import com.macleanofduartenterprises.phone.ui.home.favourite.FavouritesScreen
import com.macleanofduartenterprises.phone.ui.home.searchbar.HomeSearchBar
import com.macleanofduartenterprises.phone.ui.home.searchbar.SearchBarState
import com.macleanofduartenterprises.phone.ui.settings.BlockedNumbersScreen
import com.macleanofduartenterprises.phone.ui.settings.AccessibilitySettingsScreen
import com.macleanofduartenterprises.phone.ui.settings.AppearanceSettingsScreen
import com.macleanofduartenterprises.phone.ui.settings.CallingAccountsSettingsScreen
import com.macleanofduartenterprises.phone.ui.settings.LicenseScreen
import com.macleanofduartenterprises.phone.ui.settings.SettingsScreen
import com.macleanofduartenterprises.phone.ui.settings.IvrSettingsScreen
import com.macleanofduartenterprises.phone.ui.settings.NotificationSettingsScreen
import com.macleanofduartenterprises.phone.ui.settings.VoicemailSettingsScreen
import com.macleanofduartenterprises.phone.util.PermissionChecker


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val initialDestination = remember {
        if (PermissionChecker.isVoipOnlyMode(context) &&
            !PermissionChecker.isDefaultPhoneApp(context)
        ) {
            IvrSettingsKey
        } else {
            when (
                PhoneSettingsPrefs.resolveOpeningHomeTab(
                    openingPage = PhoneSettingsPrefs.homeOpeningPage(context),
                    lastUsed = PhoneSettingsPrefs.lastUsedHomeTab(context),
                )
            ) {
                PhoneSettingsPrefs.HomeTab.CONTACTS -> ContactsKey
                PhoneSettingsPrefs.HomeTab.RECENTS -> RecentsKey
            }
        }
    }
    val backStack = rememberNavBackStack(initialDestination)
    val vm: HomeViewModel = hiltViewModel()
    var searchBarState by rememberSaveable { mutableStateOf(SearchBarState.COLLAPSED) }
    var pendingDialPhone by remember { mutableStateOf<String?>(null) }
    var callingAccountOptions by remember { mutableStateOf<List<CallingAccountInfo>>(emptyList()) }
    var pendingContactDial by remember { mutableStateOf<Contact?>(null) }
    val phonePreferences = remember(context) { PhoneSettingsPrefs.preferences(context) }
    var simplifiedMode by remember(context) {
        mutableStateOf(AccessibilityPreferences.load(context).simplifiedMode)
    }
    DisposableEffect(phonePreferences) {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == AccessibilityPreferences.KEY_SIMPLIFIED_MODE) {
                simplifiedMode = AccessibilityPreferences.load(context).simplifiedMode
            }
        }
        phonePreferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose { phonePreferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    val currentDestination: NavKey? = backStack.lastOrNull()
    LaunchedEffect(currentDestination) {
        when (currentDestination) {
            ContactsKey -> PhoneSettingsPrefs.saveLastUsedHomeTab(
                context,
                PhoneSettingsPrefs.HomeTab.CONTACTS,
            )
            RecentsKey -> PhoneSettingsPrefs.saveLastUsedHomeTab(
                context,
                PhoneSettingsPrefs.HomeTab.RECENTS,
            )
        }
    }
    val isStandardHomeTab =
        currentDestination == FavouritesKey ||
                currentDestination == RecentsKey ||
                currentDestination == ContactsKey
    val showSimplifiedHome = simplifiedMode && isStandardHomeTab
    val isHomeTab = isStandardHomeTab && !showSimplifiedHome
    val isCrmContactsTab = currentDestination == ContactsKey && !showSimplifiedHome
    val showStandardHomeSearch = isHomeTab && !isCrmContactsTab

    fun requestDial(phone: String) {
        val accounts = CallingAccountCatalog.load(context)
        val preference = CallingAccountPreferences.load(context, accounts)
        when (val selection = CallingAccountSelectionPolicy.select(preference, accounts)) {
            CallingAccountSelection.SystemDefault -> {
                if (!context.dial(phone)) {
                    Toast.makeText(context, "The call could not be placed.", Toast.LENGTH_LONG).show()
                }
            }
            CallingAccountSelection.ShowChooser -> {
                pendingDialPhone = phone
                callingAccountOptions = accounts
            }
            is CallingAccountSelection.Specific -> {
                if (!context.dial(phone = phone, accountKey = selection.account.key)) {
                    pendingDialPhone = phone
                    callingAccountOptions = accounts
                }
            }
        }
    }

    fun requestContactDial(contact: Contact) {
        when (contact.callablePhones.size) {
            0 -> Toast.makeText(context, "This contact has no callable number.", Toast.LENGTH_LONG).show()
            1 -> requestDial(contact.callablePhones.first().number)
            else -> pendingContactDial = contact
        }
    }

    fun openSimplifiedDestination(destination: NavKey) {
        if (backStack.lastOrNull() != destination) backStack.add(destination)
    }

    @Composable
    fun simplifiedHome() {
        SimplifiedHomeScreen(
            onFavouritesClick = { openSimplifiedDestination(SimplifiedFavouritesKey) },
            onDialPadClick = { openSimplifiedDestination(SimplifiedDialerKey) },
            onRecentsClick = { openSimplifiedDestination(SimplifiedRecentsKey) },
            onVoicemailClick = { openSimplifiedDestination(VoicemailSettingsKey) },
            onSettingsClick = { openSimplifiedDestination(SettingsKey) },
        )
    }

    Scaffold(
        floatingActionButton = {
            if (showStandardHomeSearch) {
                DialFab(
                    visible = !searchBarState.isActive(),
                    onClick = {
                        searchBarState = SearchBarState.EXPANDED_WITH_DIAL_PAD
                    }
                )
            }
        },
        topBar = {
            if (showStandardHomeSearch) {
                HomeSearchBar(
                    searchBarState = searchBarState,
                    onSearchBarClick = {
                        searchBarState = SearchBarState.EXPANDED
                    },
                    onSearchCloseClick = {
                        searchBarState = SearchBarState.COLLAPSED
                    },
                    onCallClick = ::requestDial,
                    onContactCallClick = ::requestContactDial,
                    onSettingsClick = { backStack.add(SettingsKey) }
                )
            }
        },
        bottomBar = {
            if (isHomeTab) {
                AnimatedBottomBar(
                    visible = !searchBarState.isActive(),
                    backStack = backStack
                )
            }
        }
    ) { paddingValues ->

        NavDisplay(
            backStack = backStack,
            modifier = if (isHomeTab) {
                Modifier.padding(paddingValues)
            } else {
                Modifier
            },
            entryDecorators = listOf(
                rememberSaveableStateHolderNavEntryDecorator(),
                rememberViewModelStoreNavEntryDecorator()
            ),
            entryProvider = entryProvider {
                entry(FavouritesKey) {
                    if (simplifiedMode) {
                        simplifiedHome()
                    } else {
                        FavouritesScreen(
                            onCallClick = ::requestContactDial,
                            onContactDetailCLick = { context.openContactDetailScreen(it.id) }
                        )
                    }
                }
                entry(RecentsKey) {
                    if (simplifiedMode) {
                        simplifiedHome()
                    } else {
                        CallLogsScreen(
                            onContactDetailClick = {
                                it.contactId?.let(context::openContactDetailScreen)
                            },
                            onCallClick = {
                                requestDial(it)
                            },
                            onCallLogClick = {
                                backStack.add(
                                    CallLogHistoryKey(
                                        phone = it.phone,
                                        contactName = it.name,
                                        contactId = it.contactId
                                    )
                                )
                            }
                        )
                    }
                }
                entry(ContactsKey) {
                    if (simplifiedMode) {
                        simplifiedHome()
                    } else {
                        ContactsScreen(
                            onContactDetailClick = { context.openContactDetailScreen(it.id) },
                            onCallClick = ::requestContactDial,
                            onSettingsClick = { backStack.add(SettingsKey) },
                        )
                    }
                }
                entry<CallLogHistoryKey> {
                    CallLogHistoryScreen(
                        phone = it.phone,
                        contactName = it.contactName,
                        onBackClick = {
                            if (backStack.size > 1) {
                                backStack.removeAt(backStack.lastIndex)
                            }
                        },
                        onCallClick = { phone ->
                            requestDial(phone)
                        },
                        onAddContactClick = { phone ->
                            context.openContactAddScreen(phone)
                        },
                    )
                }
                entry(SettingsKey) {
                    SettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) {
                                backStack.removeAt(backStack.lastIndex)
                            }
                        },
                        onBlockedNumbersClick = {
                            backStack.add(BlockedNumbersKey)
                        },
                        onIvrSettingsClick = {
                            backStack.add(IvrSettingsKey)
                        },
                        onAccessibilitySettingsClick = {
                            backStack.add(AccessibilitySettingsKey)
                        },
                        onCallingAccountsClick = {
                            backStack.add(CallingAccountsSettingsKey)
                        },
                        onAppearanceSettingsClick = {
                            backStack.add(AppearanceSettingsKey)
                        },
                        onNotificationSettingsClick = {
                            backStack.add(NotificationSettingsKey)
                        },
                        onVoicemailSettingsClick = {
                            backStack.add(VoicemailSettingsKey)
                        },
                        onLicenseClick = {
                            backStack.add(LicenseKey)
                        },
                    )
                }
                entry(AppearanceSettingsKey) {
                    AppearanceSettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        }
                    )
                }
                entry(NotificationSettingsKey) {
                    NotificationSettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        }
                    )
                }
                entry(VoicemailSettingsKey) {
                    VoicemailSettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                        loadSims = vm::getSimsInfo,
                    )
                }
                entry(AccessibilitySettingsKey) {
                    AccessibilitySettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                    )
                }
                entry(CallingAccountsSettingsKey) {
                    CallingAccountsSettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                        onSipSettingsClick = { backStack.add(IvrSettingsKey) },
                    )
                }
                entry(LicenseKey) {
                    LicenseScreen(
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                    )
                }
                entry(SimplifiedFavouritesKey) {
                    SimplifiedSubpageScaffold(
                        title = "Favorites",
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                    ) {
                        FavouritesScreen(
                            onCallClick = ::requestContactDial,
                            onContactDetailCLick = { context.openContactDetailScreen(it.id) },
                        )
                    }
                }
                entry(SimplifiedRecentsKey) {
                    SimplifiedSubpageScaffold(
                        title = "Recent calls",
                        onBackClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                    ) {
                        CallLogsScreen(
                            onContactDetailClick = {
                                it.contactId?.let(context::openContactDetailScreen)
                            },
                            onCallClick = ::requestDial,
                            onCallLogClick = {
                                backStack.add(
                                    CallLogHistoryKey(
                                        phone = it.phone,
                                        contactName = it.name,
                                        contactId = it.contactId,
                                    )
                                )
                            },
                        )
                    }
                }
                entry(SimplifiedDialerKey) {
                    HomeSearchBar(
                        searchBarState = SearchBarState.EXPANDED_WITH_DIAL_PAD,
                        onSearchBarClick = {},
                        onSearchCloseClick = {
                            if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
                        },
                        onCallClick = ::requestDial,
                        onContactCallClick = ::requestContactDial,
                        onSettingsClick = {},
                    )
                }
                entry(IvrSettingsKey) {
                    IvrSettingsScreen(
                        onBackClick = {
                            if (backStack.size > 1) {
                                backStack.removeAt(backStack.lastIndex)
                            }
                        }
                    )
                }
                entry(BlockedNumbersKey) {
                    BlockedNumbersScreen(
                        onBackClick = {
                            if (backStack.size > 1) {
                                backStack.removeAt(backStack.lastIndex)
                            }
                        }
                    )
                }
            }
        )

    }

    pendingContactDial?.let { contact ->
        PhoneNumberSelectionDialog(
            contactName = contact.name,
            phones = contact.callablePhones,
            onSelected = { selected ->
                pendingContactDial = null
                requestDial(selected.number)
            },
            onDismiss = { pendingContactDial = null },
        )
    }

    pendingDialPhone?.let { phone ->
        CallingAccountSelectionDialog(
            systemRoute = CallingAccountCatalog.systemRoute(context, callingAccountOptions),
            accounts = callingAccountOptions,
            onSystemSelected = {
                if (!context.dial(phone)) {
                    Toast.makeText(context, "The call could not be placed.", Toast.LENGTH_LONG).show()
                }
                pendingDialPhone = null
                callingAccountOptions = emptyList()
            },
            onAccountSelected = { account ->
                if (!context.dial(phone = phone, accountKey = account.key)) {
                    Toast.makeText(context, "The selected calling account could not place the call.", Toast.LENGTH_LONG).show()
                }
                pendingDialPhone = null
                callingAccountOptions = emptyList()
            },
            onDismiss = {
                pendingDialPhone = null
                callingAccountOptions = emptyList()
            },
        )
    }
}
