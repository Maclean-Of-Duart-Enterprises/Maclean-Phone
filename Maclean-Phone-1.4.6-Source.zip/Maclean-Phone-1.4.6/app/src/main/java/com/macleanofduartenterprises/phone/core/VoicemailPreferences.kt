package com.macleanofduartenterprises.phone.core

import android.content.Context

object VoicemailPreferences {
    private const val PREFS_NAME = "voicemail_and_forwarding"
    private const val KEY_VOICEMAIL_NUMBER = "voicemail_number"
    private const val KEY_FORWARDING_ENABLED = "carrier_forwarding_enabled"
    private const val KEY_FORWARDING_NUMBER = "carrier_forwarding_number"
    private const val KEY_FORWARDING_CONDITION = "carrier_forwarding_condition"
    private const val KEY_FORWARDING_CONDITIONS = "carrier_forwarding_conditions"
    private const val KEY_FORWARDING_ACCOUNT_ID = "carrier_forwarding_account_id"

    enum class ForwardingCondition(val label: String, val serviceCode: String) {
        ALWAYS("All calls", "21"),
        UNANSWERED("When unanswered", "61"),
        BUSY("When busy", "67"),
        UNAVAILABLE("When unavailable", "62"),
    }

    data class Snapshot(
        val voicemailNumber: String,
        val forwardingEnabled: Boolean,
        val forwardingNumber: String,
        val forwardingConditions: Set<ForwardingCondition>,
        val forwardingAccountId: String = "",
    )

    fun load(context: Context): Snapshot {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val legacyCondition = runCatching {
            ForwardingCondition.valueOf(
                prefs.getString(KEY_FORWARDING_CONDITION, ForwardingCondition.UNANSWERED.name)
                    .orEmpty()
            )
        }.getOrDefault(ForwardingCondition.UNANSWERED)
        val storedConditions = prefs.getStringSet(KEY_FORWARDING_CONDITIONS, null)
        val conditions = storedConditions
            ?.mapNotNull { name ->
                runCatching { ForwardingCondition.valueOf(name) }.getOrNull()
            }
            ?.toSet()
            ?: setOf(legacyCondition)
        return Snapshot(
            voicemailNumber = prefs.getString(KEY_VOICEMAIL_NUMBER, "").orEmpty(),
            forwardingEnabled = prefs.getBoolean(KEY_FORWARDING_ENABLED, false),
            forwardingNumber = prefs.getString(KEY_FORWARDING_NUMBER, "").orEmpty(),
            forwardingConditions = conditions,
            forwardingAccountId = prefs.getString(KEY_FORWARDING_ACCOUNT_ID, "").orEmpty(),
        )
    }

    fun save(context: Context, snapshot: Snapshot) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_VOICEMAIL_NUMBER, snapshot.voicemailNumber.trim())
            .putBoolean(KEY_FORWARDING_ENABLED, snapshot.forwardingEnabled)
            .putString(KEY_FORWARDING_NUMBER, snapshot.forwardingNumber.trim())
            .putStringSet(
                KEY_FORWARDING_CONDITIONS,
                snapshot.forwardingConditions.map(ForwardingCondition::name).toSet(),
            )
            .putString(
                KEY_FORWARDING_CONDITION,
                snapshot.forwardingConditions.firstOrNull()?.name
                    ?: ForwardingCondition.UNANSWERED.name,
            )
            .putString(KEY_FORWARDING_ACCOUNT_ID, snapshot.forwardingAccountId)
            .apply()
    }

    fun activationCode(snapshot: Snapshot, condition: ForwardingCondition): String =
        "**${condition.serviceCode}*${normalizedForwardingNumber(snapshot.forwardingNumber)}#"

    fun deactivationCode(condition: ForwardingCondition): String =
        "##${condition.serviceCode}#"

    fun selectedConditions(snapshot: Snapshot): List<ForwardingCondition> =
        ForwardingCondition.entries.filter(snapshot.forwardingConditions::contains)

    fun toggleCondition(
        selected: Set<ForwardingCondition>,
        condition: ForwardingCondition,
    ): Set<ForwardingCondition> = when {
        condition in selected -> selected - condition
        condition == ForwardingCondition.ALWAYS -> setOf(ForwardingCondition.ALWAYS)
        else -> (selected - ForwardingCondition.ALWAYS) + condition
    }

    internal fun normalizedForwardingNumber(value: String): String {
        val trimmed = value.trim()
        return buildString {
            trimmed.forEachIndexed { index, character ->
                if (character.isDigit() || (character == '+' && index == 0)) {
                    append(character)
                }
            }
        }
    }
}
