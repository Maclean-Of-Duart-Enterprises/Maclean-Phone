package com.macleanofduartenterprises.phone.core

/** Pure conference policy kept separate from Android callbacks so it is unit-testable. */
object GroupCallPolicy {
    enum class State {
        RINGING,
        CONNECTING,
        DIALING,
        ACTIVE,
        HELD,
        DISCONNECTED,
        UNKNOWN,
    }

    data class CallInfo(
        val id: String,
        val state: State,
        val parentId: String? = null,
        val childIds: Set<String> = emptySet(),
        val conferenceableIds: Set<String> = emptySet(),
        val canMergeConference: Boolean = false,
        val canSwapConference: Boolean = false,
        val canAddParticipant: Boolean = false,
        val canManageConference: Boolean = false,
        val canHold: Boolean = false,
    )

    sealed interface MergeOperation {
        data class MergeExistingConference(val ownerId: String) : MergeOperation
        data class ConferenceCalls(val ownerId: String, val otherId: String) : MergeOperation
    }

    fun preferredForeground(calls: Collection<CallInfo>): String? = calls
        .filter { it.state != State.DISCONNECTED }
        .minWithOrNull(
            compareBy<CallInfo> { foregroundPriority(it.state) }
                .thenByDescending { it.childIds.isNotEmpty() }
                .thenBy { it.id },
        )
        ?.id

    fun mergeOperation(calls: Collection<CallInfo>): MergeOperation? {
        val live = calls.filter { it.state != State.DISCONNECTED }
        live.firstOrNull { it.canMergeConference }
            ?.let { return MergeOperation.MergeExistingConference(it.id) }

        live.forEach { owner ->
            val otherId = owner.conferenceableIds.firstOrNull { candidate ->
                candidate != owner.id && live.any { it.id == candidate }
            }
            if (otherId != null) {
                return MergeOperation.ConferenceCalls(owner.id, otherId)
            }
        }
        return null
    }

    fun directAddOwner(calls: Collection<CallInfo>): String? = calls
        .firstOrNull {
            it.state == State.ACTIVE && it.canAddParticipant && it.parentId == null
        }
        ?.id

    fun canSwap(calls: Collection<CallInfo>): Boolean {
        val live = calls.filter { it.state != State.DISCONNECTED }
        if (live.any { it.canSwapConference }) return true
        return live.any { it.state == State.ACTIVE && it.canHold } &&
            live.any { it.state == State.HELD }
    }

    fun participantIds(calls: Collection<CallInfo>): List<String> {
        val live = calls.filter { it.state != State.DISCONNECTED }
        val childIds = live.flatMap { it.childIds }.toSet()
        val conferenceRoots = live.filter { it.childIds.isNotEmpty() }.map { it.id }.toSet()
        return live
            .filter { it.id !in conferenceRoots && (it.parentId != null || it.id !in childIds) }
            .map { it.id }
            .ifEmpty { live.filter { it.id !in conferenceRoots }.map { it.id } }
    }

    fun isConference(calls: Collection<CallInfo>): Boolean = calls.any {
        it.state != State.DISCONNECTED && (it.childIds.size >= 2 || it.parentId != null)
    }

    private fun foregroundPriority(state: State): Int = when (state) {
        State.RINGING -> 0
        State.DIALING -> 1
        State.CONNECTING -> 2
        State.ACTIVE -> 3
        State.HELD -> 4
        State.UNKNOWN -> 5
        State.DISCONNECTED -> 6
    }
}
