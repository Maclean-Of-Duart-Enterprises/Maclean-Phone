package com.macleanofduartenterprises.phone.ui.settings

import android.content.Context
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.macleanofduartenterprises.phone.ivr.DirectoryEntry
import com.macleanofduartenterprises.phone.ivr.IvrConfig
import com.macleanofduartenterprises.phone.ivr.IvrRuntimeStatus
import com.macleanofduartenterprises.phone.ivr.IvrSettingsRepository
import com.macleanofduartenterprises.phone.ivr.SipIvrRuntime
import com.macleanofduartenterprises.phone.ivr.SipIvrService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class IvrSettingsUiState(
    val config: IvrConfig = IvrConfig(),
    val password: String = "",
    val runtimeStatus: IvrRuntimeStatus = IvrRuntimeStatus(),
    val message: String? = null,
    val dirty: Boolean = false
) {
    val validationErrors: List<String>
        get() = config.validationErrors(password)
}

@HiltViewModel
class IvrSettingsViewModel @Inject constructor(
    private val repository: IvrSettingsRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {
    private val _state = MutableStateFlow(
        IvrSettingsUiState(
            config = repository.loadConfig(),
            password = repository.loadPassword(),
            runtimeStatus = SipIvrRuntime.status.value
        )
    )
    val state: StateFlow<IvrSettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            SipIvrRuntime.status.collectLatest { status ->
                _state.value = _state.value.copy(runtimeStatus = status)
            }
        }
    }

    fun updateConfig(config: IvrConfig) {
        _state.value = _state.value.copy(config = config, dirty = true, message = null)
    }

    fun updatePassword(password: String) {
        _state.value = _state.value.copy(password = password, dirty = true, message = null)
    }

    fun upsertDirectoryEntry(originalDigit: String?, entry: DirectoryEntry) {
        val current = _state.value.config
        val withoutOriginal = current.directory.filterNot {
            it.digit == originalDigit || it.digit == entry.digit
        }
        updateConfig(current.copy(directory = (withoutOriginal + entry).sortedBy { it.digit }))
    }

    fun removeDirectoryEntry(digit: String) {
        val current = _state.value.config
        updateConfig(current.copy(directory = current.directory.filterNot { it.digit == digit }))
    }

    fun save() {
        persist(start = false)
    }

    fun saveAndStart() {
        persist(start = true)
    }

    fun stop() {
        val updated = _state.value.config.copy(enabled = false).normalized()
        runCatching {
            repository.save(updated, _state.value.password)
            context.startService(SipIvrService.intent(context, SipIvrService.ACTION_STOP))
        }.onSuccess {
            _state.value = _state.value.copy(
                config = updated,
                dirty = false,
                message = "SIP IVR stopped."
            )
        }.onFailure {
            _state.value = _state.value.copy(message = it.message ?: "Could not stop the IVR.")
        }
    }

    private fun persist(start: Boolean) {
        val current = _state.value
        val updated = current.config.copy(
            enabled = start || current.config.enabled
        ).normalized()
        val errors = updated.validationErrors(current.password)
        if (start && errors.isNotEmpty()) {
            _state.value = current.copy(message = errors.joinToString("\n"))
            return
        }

        runCatching {
            repository.save(updated, current.password)
            if (start || updated.enabled) {
                ContextCompat.startForegroundService(
                    context,
                    SipIvrService.intent(
                        context,
                        if (start) SipIvrService.ACTION_START else SipIvrService.ACTION_RELOAD
                    )
                )
            }
        }.onSuccess {
            _state.value = current.copy(
                config = updated,
                dirty = false,
                message = if (start) {
                    "Settings saved. Starting the SIP IVR…"
                } else {
                    "Settings saved."
                }
            )
        }.onFailure {
            _state.value = current.copy(
                message = it.message ?: "The IVR settings could not be saved."
            )
        }
    }
}
