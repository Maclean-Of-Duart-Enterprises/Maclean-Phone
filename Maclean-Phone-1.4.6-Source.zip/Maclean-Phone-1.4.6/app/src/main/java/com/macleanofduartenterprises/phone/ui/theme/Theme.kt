package com.macleanofduartenterprises.phone.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import coil3.compose.AsyncImage
import com.macleanofduartenterprises.phone.R
import com.macleanofduartenterprises.phone.core.AccessibilityPreferences
import com.macleanofduartenterprises.phone.core.AppearancePreferences
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import com.macleanofduartenterprises.phone.ui.accessibility.LocalAccessibilitySettings
import com.macleanofduartenterprises.phone.ui.components.LocalTextWindowStyle
import com.macleanofduartenterprises.phone.ui.components.TextWindowStyle


private val LightColors = lightColorScheme(
    primary = md_theme_light_primary,
    onPrimary = md_theme_light_onPrimary,
    primaryContainer = md_theme_light_primaryContainer,
    onPrimaryContainer = md_theme_light_onPrimaryContainer,
    secondary = md_theme_light_secondary,
    onSecondary = md_theme_light_onSecondary,
    secondaryContainer = md_theme_light_secondaryContainer,
    onSecondaryContainer = md_theme_light_onSecondaryContainer,
    tertiary = md_theme_light_tertiary,
    onTertiary = md_theme_light_onTertiary,
    tertiaryContainer = md_theme_light_tertiaryContainer,
    onTertiaryContainer = md_theme_light_onTertiaryContainer,
    error = md_theme_light_error,
    onError = md_theme_light_onError,
    errorContainer = md_theme_light_errorContainer,
    onErrorContainer = md_theme_light_onErrorContainer,
    outline = md_theme_light_outline,
    background = md_theme_light_background,
    onBackground = md_theme_light_onBackground,
    surface = md_theme_light_surface,
    onSurface = md_theme_light_onSurface,
    surfaceVariant = md_theme_light_surfaceVariant,
    onSurfaceVariant = md_theme_light_onSurfaceVariant,
    inverseSurface = md_theme_light_inverseSurface,
    inverseOnSurface = md_theme_light_inverseOnSurface,
    inversePrimary = md_theme_light_inversePrimary,
    surfaceTint = md_theme_light_surfaceTint,
    outlineVariant = md_theme_light_outlineVariant,
    scrim = md_theme_light_scrim,
)


private val DarkColors = darkColorScheme(
    primary = md_theme_dark_primary,
    onPrimary = md_theme_dark_onPrimary,
    primaryContainer = md_theme_dark_primaryContainer,
    onPrimaryContainer = md_theme_dark_onPrimaryContainer,
    secondary = md_theme_dark_secondary,
    onSecondary = md_theme_dark_onSecondary,
    secondaryContainer = md_theme_dark_secondaryContainer,
    onSecondaryContainer = md_theme_dark_onSecondaryContainer,
    tertiary = md_theme_dark_tertiary,
    onTertiary = md_theme_dark_onTertiary,
    tertiaryContainer = md_theme_dark_tertiaryContainer,
    onTertiaryContainer = md_theme_dark_onTertiaryContainer,
    error = md_theme_dark_error,
    onError = md_theme_dark_onError,
    errorContainer = md_theme_dark_errorContainer,
    onErrorContainer = md_theme_dark_onErrorContainer,
    outline = md_theme_dark_outline,
    background = md_theme_dark_background,
    onBackground = md_theme_dark_onBackground,
    surface = md_theme_dark_surface,
    onSurface = md_theme_dark_onSurface,
    surfaceVariant = md_theme_dark_surfaceVariant,
    onSurfaceVariant = md_theme_dark_onSurfaceVariant,
    inverseSurface = md_theme_dark_inverseSurface,
    inverseOnSurface = md_theme_dark_inverseOnSurface,
    inversePrimary = md_theme_dark_inversePrimary,
    surfaceTint = md_theme_dark_surfaceTint,
    outlineVariant = md_theme_dark_outlineVariant,
    scrim = md_theme_dark_scrim,
)

@Composable
fun MacleanPhoneTheme(
    darkTheme: Boolean? = null,
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDarkTheme = isSystemInDarkTheme()
    val preferences = remember(context) { PhoneSettingsPrefs.preferences(context) }
    var themeMode by remember(context) {
        mutableStateOf(PhoneSettingsPrefs.themeMode(context))
    }
    var appearance by remember(context) {
        mutableStateOf(AppearancePreferences.load(context))
    }
    var accessibility by remember(context) {
        mutableStateOf(AccessibilityPreferences.load(context))
    }

    DisposableEffect(preferences) {
        val listener =
            android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
                when (key) {
                    PhoneSettingsPrefs.KEY_THEME_MODE -> {
                        themeMode = PhoneSettingsPrefs.themeMode(context)
                    }

                    AppearancePreferences.KEY_BACKGROUND_TYPE,
                    AppearancePreferences.KEY_BACKGROUND_PHOTO_URI,
                    AppearancePreferences.KEY_ACCENT_COLOR,
                    AppearancePreferences.KEY_SOLID_BACKGROUND_COLOR,
                    AppearancePreferences.KEY_PANEL_OPACITY,
                    AppearancePreferences.KEY_TEXT_COLOR_MODE,
                    AppearancePreferences.KEY_TEXT_COLOR,
                    AppearancePreferences.KEY_TEXT_WINDOW_MODE,
                    AppearancePreferences.KEY_TEXT_WINDOW_COLOR,
                    AppearancePreferences.KEY_TEXT_WINDOW_OPACITY,
                    AppearancePreferences.KEY_TEXT_WINDOW_CORNER_RADIUS -> {
                        appearance = AppearancePreferences.load(context)
                    }

                    AccessibilityPreferences.KEY_SIP_NOISE_REDUCTION,
                    AccessibilityPreferences.KEY_PREFER_HEARING_AID,
                    AccessibilityPreferences.KEY_TEXT_SCALE,
                    AccessibilityPreferences.KEY_LARGE_CONTROLS,
                    AccessibilityPreferences.KEY_HIGH_CONTRAST,
                    AccessibilityPreferences.KEY_VISUAL_ALERTS,
                    AccessibilityPreferences.KEY_SIMPLIFIED_MODE -> {
                        accessibility = AccessibilityPreferences.load(context)
                    }
                }
            }
        preferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose { preferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    val useDarkTheme = darkTheme ?: when (themeMode) {
        PhoneSettingsPrefs.ThemeMode.SYSTEM -> systemDarkTheme
        PhoneSettingsPrefs.ThemeMode.LIGHT -> false
        PhoneSettingsPrefs.ThemeMode.DARK -> true
    }

    val baseColorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (useDarkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        useDarkTheme -> DarkColors
        else -> LightColors
    }
    val accentedColorScheme = if (accessibility.highContrast) {
        if (useDarkTheme) {
            baseColorScheme.copy(
                primary = Color(0xFFFFD740),
                onPrimary = Color.Black,
                primaryContainer = Color(0xFF3D3200),
                onPrimaryContainer = Color.White,
                secondary = Color.White,
                onSecondary = Color.Black,
                background = Color.Black,
                onBackground = Color.White,
                surface = Color.Black,
                onSurface = Color.White,
                surfaceVariant = Color(0xFF171717),
                onSurfaceVariant = Color.White,
                outline = Color.White,
                outlineVariant = Color(0xFFBDBDBD),
            )
        } else {
            baseColorScheme.copy(
                primary = Color(0xFF00305C),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFD5E9FF),
                onPrimaryContainer = Color.Black,
                secondary = Color(0xFF00305C),
                onSecondary = Color.White,
                background = Color.White,
                onBackground = Color.Black,
                surface = Color.White,
                onSurface = Color.Black,
                surfaceVariant = Color(0xFFF1F1F1),
                onSurfaceVariant = Color.Black,
                outline = Color.Black,
                outlineVariant = Color(0xFF4A4A4A),
            )
        }
    } else {
        val accent = Color(appearance.accentColor)
        val onAccent = if (accent.luminance() > 0.48f) Color.Black else Color.White
        baseColorScheme.copy(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = if (useDarkTheme) 0.42f else 0.24f)
                .compositeOver(baseColorScheme.surface),
            onPrimaryContainer = baseColorScheme.onSurface,
            secondary = accent,
            onSecondary = onAccent,
        )
    }
    val hasImageBackground = appearance.backgroundType !=
        AppearancePreferences.BackgroundType.SOLID
    val panelAlpha = if (accessibility.highContrast) {
        1f
    } else if (hasImageBackground) {
        appearance.panelOpacity
    } else {
        1f
    }
    val colorScheme = accentedColorScheme.copy(
        background = accentedColorScheme.background.copy(alpha = panelAlpha),
        surface = accentedColorScheme.surface.copy(alpha = panelAlpha),
        surfaceVariant = accentedColorScheme.surfaceVariant.copy(alpha = panelAlpha),
        surfaceContainerLowest = accentedColorScheme.surfaceContainerLowest.copy(alpha = panelAlpha),
        surfaceContainerLow = accentedColorScheme.surfaceContainerLow.copy(alpha = panelAlpha),
        surfaceContainer = accentedColorScheme.surfaceContainer.copy(alpha = panelAlpha),
        surfaceContainerHigh = accentedColorScheme.surfaceContainerHigh.copy(alpha = panelAlpha),
        surfaceContainerHighest = accentedColorScheme.surfaceContainerHighest.copy(alpha = panelAlpha),
    )
    val selectedTextColor = if (
        !accessibility.highContrast &&
        appearance.textColorMode == AppearancePreferences.TextColorMode.CUSTOM
    ) {
        Color(appearance.textColor)
    } else {
        null
    }
    val selectedTextWindowColor = if (
        !accessibility.highContrast &&
        appearance.textWindowMode == AppearancePreferences.TextWindowMode.COLORED
    ) {
        Color(appearance.textWindowColor).copy(alpha = appearance.textWindowOpacity)
    } else {
        null
    }
    val appTypography = Typography.withTextAppearance(textColor = selectedTextColor)
    val view = LocalView.current
    val activity = view.context.findActivity()
    if (!view.isInEditMode && activity != null) {
        SideEffect {
            val window = activity.window
            window.navigationBarColor =
                colorScheme.primary.copy(alpha = 0.08f).compositeOver(colorScheme.surface.copy())
                    .toArgb()
            window.statusBarColor = baseColorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars =
                !useDarkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars =
                !useDarkTheme

        }
    }
    val baseDensity = LocalDensity.current
    val scaledDensity = Density(
        density = baseDensity.density,
        fontScale = baseDensity.fontScale * accessibility.textScale,
    )
    CompositionLocalProvider(
        LocalAccessibilitySettings provides accessibility,
        LocalDensity provides scaledDensity,
        LocalTextWindowStyle provides TextWindowStyle(
            color = selectedTextWindowColor,
            cornerRadius = appearance.textWindowCornerRadius.dp,
        ),
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = appTypography,
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
            when (appearance.backgroundType) {
                AppearancePreferences.BackgroundType.TARTAN -> {
                    Image(
                        painter = painterResource(R.drawable.image_favourite),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                }

                AppearancePreferences.BackgroundType.PHOTO -> {
                    if (appearance.photoUri.isBlank()) {
                        Image(
                            painter = painterResource(R.drawable.image_favourite),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    } else {
                        AsyncImage(
                            model = Uri.parse(appearance.photoUri),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    }
                }

                AppearancePreferences.BackgroundType.SOLID -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(appearance.solidBackgroundColor))
                    )
                }
            }
                content()
            }
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun androidx.compose.material3.Typography.withTextAppearance(
    textColor: Color?,
): androidx.compose.material3.Typography {
    fun TextStyle.applyAppearance(): TextStyle = copy(
        color = textColor ?: color,
    )

    return copy(
        displayLarge = displayLarge.applyAppearance(),
        displayMedium = displayMedium.applyAppearance(),
        displaySmall = displaySmall.applyAppearance(),
        headlineLarge = headlineLarge.applyAppearance(),
        headlineMedium = headlineMedium.applyAppearance(),
        headlineSmall = headlineSmall.applyAppearance(),
        titleLarge = titleLarge.applyAppearance(),
        titleMedium = titleMedium.applyAppearance(),
        titleSmall = titleSmall.applyAppearance(),
        bodyLarge = bodyLarge.applyAppearance(),
        bodyMedium = bodyMedium.applyAppearance(),
        bodySmall = bodySmall.applyAppearance(),
        labelLarge = labelLarge.applyAppearance(),
        labelMedium = labelMedium.applyAppearance(),
        labelSmall = labelSmall.applyAppearance(),
    )
}
