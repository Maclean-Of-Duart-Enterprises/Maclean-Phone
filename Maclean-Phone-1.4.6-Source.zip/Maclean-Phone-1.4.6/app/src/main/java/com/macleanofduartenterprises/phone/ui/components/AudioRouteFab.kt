package com.macleanofduartenterprises.phone.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.ui.accessibility.LocalAccessibilitySettings
import com.macleanofduartenterprises.phone.ui.accessibility.primaryCallControlSize
import kotlinx.coroutines.withTimeoutOrNull

@Composable
fun AudioRouteFab(
    @DrawableRes icon: Int,
    isSpeakerActive: Boolean,
    modifier: Modifier = Modifier,
    onShortClick: () -> Unit,
    onThreeSecondHold: () -> Unit,
) {
    val accessibility = LocalAccessibilitySettings.current
    val currentShortClick by rememberUpdatedState(onShortClick)
    val currentThreeSecondHold by rememberUpdatedState(onThreeSecondHold)
    val containerColor = if (isSpeakerActive) {
        MaterialTheme.colorScheme.inverseSurface
    } else {
        MaterialTheme.colorScheme.background
    }
    val contentColor = if (isSpeakerActive) {
        MaterialTheme.colorScheme.background
    } else {
        MaterialTheme.colorScheme.onBackground
    }

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(accessibility.primaryCallControlSize)
                .clip(CircleShape)
                .background(containerColor)
                .threeSecondHoldGesture(
                    onShortClick = { currentShortClick() },
                    onThreeSecondHold = { currentThreeSecondHold() },
                )
                .semantics {
                    role = Role.Button
                    stateDescription = if (isSpeakerActive) "Speaker on" else "Speaker off"
                    onClick(label = "Toggle speaker") {
                        onShortClick()
                        true
                    }
                    customActions = listOf(
                        CustomAccessibilityAction("Choose call audio device") {
                            onThreeSecondHold()
                            true
                        }
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(id = icon),
                contentDescription = null,
                tint = contentColor,
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text("Speaker")
        Text("Hold 3 sec", style = MaterialTheme.typography.labelSmall)
    }
}

private fun Modifier.threeSecondHoldGesture(
    onShortClick: () -> Unit,
    onThreeSecondHold: () -> Unit,
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        down.consume()
        val releasedBeforeHold = withTimeoutOrNull(3_000L) {
            waitForUpOrCancellation()
        }
        if (releasedBeforeHold != null) {
            releasedBeforeHold.consume()
            onShortClick()
        } else {
            onThreeSecondHold()
            waitForUpOrCancellation()?.consume()
        }
    }
}
