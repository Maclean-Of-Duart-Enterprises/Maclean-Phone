package com.macleanofduartenterprises.phone.ivr

class IvrMenuRouter(
    private val config: IvrConfig
) {
    var stage: IvrMenuStage = IvrMenuStage.LANGUAGE
        private set

    var language: IvrLanguage? = null
        private set

    private var unsuccessfulAttempts = 0

    fun reset(): IvrRouteDecision {
        stage = IvrMenuStage.LANGUAGE
        language = null
        unsuccessfulAttempts = 0
        return IvrRouteDecision(IvrRouteCommand.PLAY_LANGUAGE_MENU)
    }

    fun accept(rawDigit: Char): IvrRouteDecision {
        val digit = rawDigit.uppercaseChar()
        if (digit == '*') {
            return repeatCurrentMenu()
        }

        return when (stage) {
            IvrMenuStage.LANGUAGE -> acceptLanguage(digit)
            IvrMenuStage.DIRECTORY -> acceptDirectory(digit)
            IvrMenuStage.COMPLETE -> IvrRouteDecision(IvrRouteCommand.HANG_UP, language)
        }
    }

    fun noInput(): IvrRouteDecision = invalidDecision()

    private fun acceptLanguage(digit: Char): IvrRouteDecision {
        language = when (digit) {
            '1' -> IvrLanguage.ENGLISH
            '2' -> IvrLanguage.RUSSIAN
            else -> null
        }
        return if (language != null) {
            stage = IvrMenuStage.DIRECTORY
            unsuccessfulAttempts = 0
            IvrRouteDecision(
                command = IvrRouteCommand.PLAY_DIRECTORY,
                language = language
            )
        } else {
            invalidDecision()
        }
    }

    private fun acceptDirectory(digit: Char): IvrRouteDecision {
        val entry = config.directory.firstOrNull { it.digit.singleOrNull() == digit }
            ?: return invalidDecision()

        unsuccessfulAttempts = 0
        return when (entry.action) {
            DirectoryAction.TRANSFER -> {
                stage = IvrMenuStage.COMPLETE
                IvrRouteDecision(
                    command = IvrRouteCommand.TRANSFER,
                    language = language,
                    destination = entry.destination
                )
            }

            DirectoryAction.REPEAT_MENU -> IvrRouteDecision(
                command = IvrRouteCommand.PLAY_DIRECTORY,
                language = language
            )

            DirectoryAction.HANG_UP -> {
                stage = IvrMenuStage.COMPLETE
                IvrRouteDecision(IvrRouteCommand.HANG_UP, language)
            }
        }
    }

    private fun repeatCurrentMenu(): IvrRouteDecision =
        if (stage == IvrMenuStage.DIRECTORY) {
            IvrRouteDecision(IvrRouteCommand.PLAY_DIRECTORY, language)
        } else {
            IvrRouteDecision(IvrRouteCommand.PLAY_LANGUAGE_MENU)
        }

    private fun invalidDecision(): IvrRouteDecision {
        unsuccessfulAttempts += 1
        if (unsuccessfulAttempts < config.maxInvalidAttempts) {
            return repeatCurrentMenu().copy(invalidSelection = true)
        }

        val fallback = config.fallbackDestination
        stage = IvrMenuStage.COMPLETE
        return if (fallback.isNotBlank()) {
            IvrRouteDecision(
                command = IvrRouteCommand.TRANSFER,
                language = language,
                destination = fallback,
                invalidSelection = true
            )
        } else {
            IvrRouteDecision(
                command = IvrRouteCommand.HANG_UP,
                language = language,
                invalidSelection = true
            )
        }
    }
}
