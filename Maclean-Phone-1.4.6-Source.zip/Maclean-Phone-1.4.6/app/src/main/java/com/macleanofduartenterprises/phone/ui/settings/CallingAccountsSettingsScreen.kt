package com.macleanofduartenterprises.phone.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.PhoneInTalk
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.macleanofduartenterprises.phone.core.CallingAccountCatalog
import com.macleanofduartenterprises.phone.core.CallingAccountPreferences
import com.macleanofduartenterprises.phone.ivr.SipIvrRuntime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallingAccountsSettingsScreen(
    onBackClick: () -> Unit,
    onSipSettingsClick: () -> Unit,
) {
    val context = LocalContext.current
    val initialAccounts = remember(context) { CallingAccountCatalog.load(context) }
    var accounts by remember(context) { mutableStateOf(initialAccounts) }
    var choice by remember(context) {
        mutableStateOf(CallingAccountPreferences.load(context, initialAccounts))
    }
    val sipStatus by SipIvrRuntime.status.collectAsStateWithLifecycle()

    fun save(newChoice: CallingAccountPreferences.Snapshot) {
        choice = newChoice
        CallingAccountPreferences.save(context, newChoice)
    }

    fun refresh() {
        accounts = CallingAccountCatalog.load(context)
        choice = CallingAccountPreferences.load(context, accounts)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Calling accounts") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                "Choose which phone number or registered calling account Maclean Phone uses for outgoing calls.",
                style = MaterialTheme.typography.bodyMedium,
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                ),
            ) {
                val systemRoute = CallingAccountCatalog.systemRoute(context, accounts)
                CallingAccountChoice(
                    title = systemRoute.title,
                    detail = systemRoute.detail,
                    selected = choice.mode == CallingAccountPreferences.Mode.SYSTEM_DEFAULT,
                    onClick = {
                        save(CallingAccountPreferences.Snapshot(
                            mode = CallingAccountPreferences.Mode.SYSTEM_DEFAULT,
                        ))
                    },
                )
                CallingAccountChoice(
                    title = "Ask every time",
                    detail = "Choose Phone / system default, a SIM, or a registered VoIP account before each call.",
                    selected = choice.mode == CallingAccountPreferences.Mode.ASK_EVERY_TIME,
                    onClick = {
                        save(CallingAccountPreferences.Snapshot(
                            mode = CallingAccountPreferences.Mode.ASK_EVERY_TIME,
                        ))
                    },
                )
                accounts.forEach { account ->
                    CallingAccountChoice(
                        title = account.title,
                        detail = account.detail,
                        selected = choice.mode == CallingAccountPreferences.Mode.SPECIFIC_ACCOUNT &&
                            choice.accountKey == account.key,
                        onClick = {
                            save(CallingAccountPreferences.Snapshot(
                                mode = CallingAccountPreferences.Mode.SPECIFIC_ACCOUNT,
                                accountKey = account.key,
                            ))
                        },
                    )
                }
            }

            OutlinedButton(onClick = ::refresh, modifier = Modifier.align(Alignment.End)) {
                Icon(Icons.Outlined.Refresh, contentDescription = null)
                Text("Refresh calling accounts")
            }

            Text(
                "Google Voice appears as a direct choice only if it registers an enabled Android calling account. " +
                    "When Google Voice is Android's call-redirecting app, choose Phone / system default so its own per-call policy can run.",
                style = MaterialTheme.typography.bodySmall,
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                ),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(Icons.Outlined.PhoneInTalk, contentDescription = null)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Maclean SIP/VoIP IVR", style = MaterialTheme.typography.titleMedium)
                            Text(sipStatus.detail, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text(
                        "The built-in SIP feature answers incoming directory/IVR calls. An outbound VoIP provider is selectable above when it registers a telephone-capable Android calling account.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Button(onClick = onSipSettingsClick) { Text("Configure SIP account") }
                }
            }

            if (accounts.isEmpty()) {
                Text(
                    "No separate cellular or VoIP account is currently visible. Phone / system default remains available. Grant phone-number access and tap Refresh if accounts are missing.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun CallingAccountChoice(
    title: String,
    detail: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        RadioButton(selected = selected, onClick = null)
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(detail, style = MaterialTheme.typography.bodySmall)
        }
    }
}
