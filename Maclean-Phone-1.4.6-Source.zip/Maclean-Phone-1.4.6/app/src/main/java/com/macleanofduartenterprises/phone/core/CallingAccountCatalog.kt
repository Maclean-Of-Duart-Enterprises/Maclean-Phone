package com.macleanofduartenterprises.phone.core

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat

enum class CallingAccountKind(val label: String) {
    CELLULAR("Cellular"),
    VOIP("VoIP"),
    OTHER("Calling account"),
}

data class CallingAccountInfo(
    val key: String,
    val handle: PhoneAccountHandle,
    val label: String,
    val applicationLabel: String,
    val fromNumber: String,
    val kind: CallingAccountKind,
    val supportsTelephoneNumbers: Boolean,
) {
    val title: String
        get() = label.ifBlank { applicationLabel.ifBlank { kind.label } }

    val detail: String
        get() = buildList {
            if (fromNumber.isNotBlank()) add("Calls from $fromNumber")
            else add("Calling number not provided by provider")
            if (applicationLabel.isNotBlank() && !applicationLabel.equals(title, true)) {
                add(applicationLabel)
            }
            add(kind.label)
        }.distinct().joinToString(" • ")
}

data class SystemCallingRouteInfo(
    val title: String = "Phone / system default",
    val detail: String,
)

/** Enumerates the enabled telephone accounts Android Telecom exposes to this dialer. */
object CallingAccountCatalog {
    fun accountKey(handle: PhoneAccountHandle): String =
        "${handle.componentName.flattenToString()}|${handle.id}"

    fun legacyAccountKey(component: ComponentName, handleId: String): String =
        "${component.flattenToString()}|$handleId"

    @SuppressLint("MissingPermission")
    fun load(context: Context): List<CallingAccountInfo> {
        if (!canReadAccounts(context)) return emptyList()
        val telecom = context.getSystemService(TelecomManager::class.java) ?: return emptyList()
        return runCatching { telecom.callCapablePhoneAccounts }
            .getOrDefault(emptyList())
            .mapNotNull { handle ->
                val account = runCatching { telecom.getPhoneAccount(handle) }.getOrNull()
                    ?: return@mapNotNull null
                val supportsTel = runCatching {
                    account.supportsUriScheme(PhoneAccount.SCHEME_TEL)
                }.getOrDefault(false)
                if (!account.isEnabled || !supportsTel) return@mapNotNull null
                val appLabel = context.applicationLabel(handle.componentName.packageName)
                val number = firstNonBlankAddress(
                    account.subscriptionAddress,
                    account.address,
                )
                CallingAccountInfo(
                    key = accountKey(handle),
                    handle = handle,
                    label = account.label?.toString().orEmpty().trim(),
                    applicationLabel = appLabel,
                    fromNumber = number,
                    kind = if (account.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION)) {
                        CallingAccountKind.CELLULAR
                    } else if (account.hasCapabilities(PhoneAccount.CAPABILITY_CALL_PROVIDER) ||
                        account.hasCapabilities(PhoneAccount.CAPABILITY_SELF_MANAGED)
                    ) {
                        CallingAccountKind.VOIP
                    } else {
                        CallingAccountKind.OTHER
                    },
                    supportsTelephoneNumbers = supportsTel,
                )
            }
            .distinctBy(CallingAccountInfo::key)
            .sortedWith(compareBy<CallingAccountInfo>({ it.kind.ordinal }, { it.title.lowercase() }))
    }

    fun resolve(context: Context, accountKey: String): CallingAccountInfo? =
        resolve(accountKey, load(context))

    /** Also accepts the legacy 1.4.4 handle ID while its preference is being migrated. */
    fun resolve(accountKey: String, accounts: List<CallingAccountInfo>): CallingAccountInfo? {
        val exact = accounts.firstOrNull { it.key == accountKey }
        if (exact != null) return exact
        return accounts.singleOrNull { it.handle.id == accountKey }
    }

    @SuppressLint("MissingPermission")
    fun systemRoute(context: Context, accounts: List<CallingAccountInfo> = load(context)): SystemCallingRouteInfo {
        val telecom = context.getSystemService(TelecomManager::class.java)
        val defaultHandle = if (telecom != null && canReadAccounts(context)) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    telecom.userSelectedOutgoingPhoneAccount
                } else {
                    @Suppress("DEPRECATION")
                    telecom.getDefaultOutgoingPhoneAccount(PhoneAccount.SCHEME_TEL)
                }
            }.getOrNull()
        } else {
            null
        }
        val selected = defaultHandle?.let { handle ->
            accounts.firstOrNull { it.key == accountKey(handle) }
        }
        val detail = when {
            selected?.fromNumber?.isNotBlank() == true ->
                "Android default: ${selected.title} • ${selected.fromNumber}"
            selected != null -> "Android default: ${selected.title}"
            else -> "Let Android use the phone/SIM default and any configured call redirection."
        }
        return SystemCallingRouteInfo(detail = detail)
    }

    private fun canReadAccounts(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_NUMBERS) ==
                PackageManager.PERMISSION_GRANTED

    private fun firstNonBlankAddress(vararg addresses: Uri?): String = addresses
        .asSequence()
        .mapNotNull { uri ->
            uri?.let {
                Uri.decode(it.schemeSpecificPart?.takeIf(String::isNotBlank) ?: it.toString()).trim()
            }
        }
        .firstOrNull(String::isNotBlank)
        .orEmpty()

    @Suppress("DEPRECATION")
    private fun Context.applicationLabel(packageName: String): String = runCatching {
        val info = packageManager.getApplicationInfo(packageName, 0)
        packageManager.getApplicationLabel(info).toString().trim()
    }.getOrDefault("")
}
