package com.macleanofduartenterprises.phone.core

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.speech.tts.TextToSpeech
import com.macleanofduartenterprises.phone.domain.repo.ContactRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CallerIdAnnouncer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val contactRepository: ContactRepository,
) {
    private val audioManager = context.getSystemService(AudioManager::class.java)
    private var textToSpeech: TextToSpeech? = null

    suspend fun announce(phone: String) {
        val mode = PhoneSettingsPrefs.callerIdAnnouncement(context)
        if (mode == PhoneSettingsPrefs.CallerIdAnnouncement.NEVER) return
        if (
            mode == PhoneSettingsPrefs.CallerIdAnnouncement.HEADSET_ONLY &&
            !hasConnectedHeadset()
        ) {
            return
        }

        val contactName = runCatching { contactRepository.getContactByPhone(phone)?.name }
            .getOrNull()
            ?.takeIf(String::isNotBlank)
        val spokenCaller = contactName ?: phone.toSpokenPhone()
        val message = "Incoming call from $spokenCaller"
        val existing = textToSpeech
        if (existing != null) {
            existing.speak(message, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
            return
        }

        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.speak(
                    message,
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    UTTERANCE_ID,
                )
            }
        }
    }

    private fun hasConnectedHeadset(): Boolean {
        return audioManager
            ?.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            ?.any { device ->
                device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    device.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                        device.type == AudioDeviceInfo.TYPE_HEARING_AID) ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        device.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
            }
            ?: false
    }

    private fun String.toSpokenPhone(): String =
        map { character ->
            when (character) {
                '+' -> "plus"
                else -> character.toString()
            }
        }.joinToString(" ")

    companion object {
        private const val UTTERANCE_ID = "maclean_phone_incoming_caller_id"
    }
}
