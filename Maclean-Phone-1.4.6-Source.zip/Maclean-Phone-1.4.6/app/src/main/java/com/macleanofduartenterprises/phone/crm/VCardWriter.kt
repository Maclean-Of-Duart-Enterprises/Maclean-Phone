package com.macleanofduartenterprises.phone.crm

import java.io.OutputStream
import java.util.Base64

/** UTF-8 vCard 3.0 writer used by Save As and Android sharing. */
object VCardWriter {
    fun write(
        contacts: List<CrmContact>,
        groups: List<CrmGroup>,
        output: OutputStream,
        photoReader: (CrmContact) -> ByteArray? = { null },
    ): CrmExportResult {
        var exported = 0
        var failed = 0
        val messages = mutableListOf<String>()
        contacts.forEach { contact ->
            runCatching {
                val photo = if (contact.photoUri == null) null else {
                    photoReader(contact)
                        ?: error("Photo for ${contact.displayName} could not be read.")
                }
                cardLines(contact, groups, photo).forEach { line ->
                    output.write(foldUtf8(line).toByteArray(Charsets.UTF_8))
                    output.write(CRLF)
                }
            }.onSuccess {
                exported++
            }.onFailure { error ->
                failed++
                messages += "${contact.displayName}: ${error.message ?: error.javaClass.simpleName}"
            }
        }
        output.flush()
        return CrmExportResult(exported, failed, messages.take(8))
    }

    private fun cardLines(
        contact: CrmContact,
        groups: List<CrmGroup>,
        photo: ByteArray?,
    ): List<String> = buildList {
        add("BEGIN:VCARD")
        add("VERSION:3.0")
        add("PRODID:-//Maclean of Duart Enterprises//Maclean Phone 1.4.6//EN")
        add("FN:${escape(contact.displayName)}")
        add(
            "N:${escape(contact.lastName)};${escape(contact.firstName)};" +
                "${escape(contact.middleName)};;",
        )
        value("NICKNAME", contact.nickname)
        value("ORG", contact.company)
        value("BDAY", contact.birthday)
        value("NOTE", contact.notes)
        value("X-MACLEAN-HOUSEHOLD", contact.household)
        value("X-MACLEAN-STAGE", contact.stage)
        value("X-MACLEAN-SERVICE", contact.service)
        value("X-MACLEAN-SOURCE", contact.source)
        value("X-MACLEAN-REPRESENTATIVE", contact.representative)
        value("X-MACLEAN-NEXT-ACTION", contact.nextAction)
        if (contact.favorite) add("X-MACLEAN-FAVORITE:TRUE")

        contact.customFields.filter { it.value.isNotBlank() }.forEach { field ->
            val label = Base64.getUrlEncoder().withoutPadding()
                .encodeToString(field.label.toByteArray(Charsets.UTF_8))
            val labelParameter = ";X-MACLEAN-LABEL-B64=$label"
            when (field.type) {
                CrmFieldType.PHONE -> add(
                    "TEL;TYPE=VOICE$labelParameter" + countryParameter(field) +
                        ":${escape(field.completeValue())}",
                )
                CrmFieldType.FAX -> add(
                    "TEL;TYPE=FAX$labelParameter" + countryParameter(field) +
                        ":${escape(field.completeValue())}",
                )
                CrmFieldType.EMAIL -> add("EMAIL;TYPE=INTERNET$labelParameter:${escape(field.value)}")
                CrmFieldType.ADDRESS -> add(
                    "ADR;TYPE=POSTAL$labelParameter:;;${escape(field.value)};;;;",
                )
                CrmFieldType.WEBSITE -> add("URL$labelParameter:${escape(field.value)}")
                CrmFieldType.CUSTOM -> add(
                    "X-MACLEAN-CUSTOM$labelParameter:${escape(field.value)}",
                )
            }
        }
        val groupNames = groups.filter { it.id in contact.groupIds }.map(CrmGroup::name)
        if (groupNames.isNotEmpty()) {
            add("CATEGORIES:${groupNames.joinToString(",") { escape(it) }}")
        }
        if (photo != null && photo.isNotEmpty()) {
            add("PHOTO;ENCODING=b:${Base64.getEncoder().encodeToString(photo)}")
        }
        add("END:VCARD")
    }

    private fun MutableList<String>.value(name: String, value: String) {
        if (value.isNotBlank()) add("$name:${escape(value)}")
    }

    private fun countryParameter(field: CrmCustomField): String {
        val country = field.countryCode.trim()
        return if (country.isBlank()) "" else ";X-MACLEAN-COUNTRY-CODE=${escapeParameter(country)}"
    }

    private fun escape(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\r\n", "\\n")
        .replace("\r", "\\n")
        .replace("\n", "\\n")
        .replace(";", "\\;")
        .replace(",", "\\,")

    private fun escapeParameter(value: String): String = value
        .replace("\\", "")
        .replace(";", "")
        .replace(":", "")
        .replace(",", "")

    /** RFC 6350-style 75-octet folding, without splitting a UTF-8 code point. */
    internal fun foldUtf8(line: String): String {
        val bytes = line.toByteArray(Charsets.UTF_8)
        if (bytes.size <= 75) return line
        val result = StringBuilder(line.length + bytes.size / 70 * 3)
        var start = 0
        var first = true
        while (start < bytes.size) {
            val limit = if (first) 75 else 74
            var end = minOf(start + limit, bytes.size)
            while (end < bytes.size && end > start && (bytes[end].toInt() and 0xC0) == 0x80) {
                end--
            }
            check(end > start) { "Unable to fold UTF-8 vCard line." }
            if (!first) result.append("\r\n ")
            result.append(String(bytes, start, end - start, Charsets.UTF_8))
            start = end
            first = false
        }
        return result.toString()
    }

    private val CRLF = byteArrayOf('\r'.code.toByte(), '\n'.code.toByte())
}
