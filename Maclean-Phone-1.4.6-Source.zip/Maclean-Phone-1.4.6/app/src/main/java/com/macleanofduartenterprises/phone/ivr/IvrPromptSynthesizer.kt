package com.macleanofduartenterprises.phone.ivr

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

data class IvrPromptSet(
    val languageEnglish: File,
    val languageRussian: File,
    val directoryEnglish: File,
    val directoryRussian: File,
    val invalidEnglish: File,
    val invalidRussian: File,
    val transferEnglish: File,
    val transferRussian: File,
    val goodbyeEnglish: File,
    val goodbyeRussian: File
) {
    fun directory(language: IvrLanguage): File =
        if (language == IvrLanguage.ENGLISH) directoryEnglish else directoryRussian

    fun invalid(language: IvrLanguage): File =
        if (language == IvrLanguage.ENGLISH) invalidEnglish else invalidRussian

    fun transfer(language: IvrLanguage): File =
        if (language == IvrLanguage.ENGLISH) transferEnglish else transferRussian

    fun goodbye(language: IvrLanguage): File =
        if (language == IvrLanguage.ENGLISH) goodbyeEnglish else goodbyeRussian
}

class IvrPromptSynthesizer(
    private val context: Context
) {
    suspend fun synthesize(config: IvrConfig): Result<IvrPromptSet> = runCatching {
        val engine = createEngine()
        try {
            val directory = File(context.filesDir, "ivr-prompts").apply { mkdirs() }
            val languageEnglish = File(directory, "language-en.wav")
            val languageRussian = File(directory, "language-ru.wav")
            val directoryEnglish = File(directory, "directory-en.wav")
            val directoryRussian = File(directory, "directory-ru.wav")
            val invalidEnglish = File(directory, "invalid-en.wav")
            val invalidRussian = File(directory, "invalid-ru.wav")
            val transferEnglish = File(directory, "transfer-en.wav")
            val transferRussian = File(directory, "transfer-ru.wav")
            val goodbyeEnglish = File(directory, "goodbye-en.wav")
            val goodbyeRussian = File(directory, "goodbye-ru.wav")

            synthesizeFile(
                engine,
                Locale.US,
                IvrPromptBuilder.languageEnglish(config),
                languageEnglish
            )
            synthesizeFile(
                engine,
                Locale.forLanguageTag("ru-RU"),
                IvrPromptBuilder.languageRussian(config),
                languageRussian
            )
            synthesizeFile(
                engine,
                Locale.US,
                IvrPromptBuilder.directory(config, IvrLanguage.ENGLISH),
                directoryEnglish
            )
            synthesizeFile(
                engine,
                Locale.forLanguageTag("ru-RU"),
                IvrPromptBuilder.directory(config, IvrLanguage.RUSSIAN),
                directoryRussian
            )
            synthesizeFile(
                engine,
                Locale.US,
                IvrPromptBuilder.invalid(IvrLanguage.ENGLISH),
                invalidEnglish
            )
            synthesizeFile(
                engine,
                Locale.forLanguageTag("ru-RU"),
                IvrPromptBuilder.invalid(IvrLanguage.RUSSIAN),
                invalidRussian
            )
            synthesizeFile(
                engine,
                Locale.US,
                IvrPromptBuilder.transfer(IvrLanguage.ENGLISH),
                transferEnglish
            )
            synthesizeFile(
                engine,
                Locale.forLanguageTag("ru-RU"),
                IvrPromptBuilder.transfer(IvrLanguage.RUSSIAN),
                transferRussian
            )
            synthesizeFile(
                engine,
                Locale.US,
                IvrPromptBuilder.goodbye(IvrLanguage.ENGLISH),
                goodbyeEnglish
            )
            synthesizeFile(
                engine,
                Locale.forLanguageTag("ru-RU"),
                IvrPromptBuilder.goodbye(IvrLanguage.RUSSIAN),
                goodbyeRussian
            )

            IvrPromptSet(
                languageEnglish = languageEnglish,
                languageRussian = languageRussian,
                directoryEnglish = directoryEnglish,
                directoryRussian = directoryRussian,
                invalidEnglish = invalidEnglish,
                invalidRussian = invalidRussian,
                transferEnglish = transferEnglish,
                transferRussian = transferRussian,
                goodbyeEnglish = goodbyeEnglish,
                goodbyeRussian = goodbyeRussian
            )
        } finally {
            engine.shutdown()
        }
    }

    private suspend fun createEngine(): TextToSpeech =
        suspendCancellableCoroutine { continuation ->
            lateinit var engine: TextToSpeech
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    continuation.resume(engine)
                } else {
                    continuation.resumeWith(Result.failure(
                        IllegalStateException("Android text-to-speech could not start.")
                    ))
                }
            }
            continuation.invokeOnCancellation { engine.shutdown() }
        }

    private suspend fun synthesizeFile(
        engine: TextToSpeech,
        locale: Locale,
        text: String,
        output: File
    ) {
        val languageResult = engine.setLanguage(locale)
        check(
            languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            "The ${locale.displayLanguage} text-to-speech voice is not installed."
        }

        suspendCancellableCoroutine { continuation ->
            val utteranceId = UUID.randomUUID().toString()
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) = Unit

                override fun onDone(id: String?) {
                    if (id == utteranceId && continuation.isActive) {
                        continuation.resume(Unit)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    onError(id, TextToSpeech.ERROR)
                }

                override fun onError(id: String?, errorCode: Int) {
                    if (id == utteranceId && continuation.isActive) {
                        continuation.resumeWith(
                            Result.failure(
                                IllegalStateException(
                                    "Text-to-speech failed while preparing a prompt ($errorCode)."
                                )
                            )
                        )
                    }
                }
            })
            val result = engine.synthesizeToFile(
                text,
                Bundle(),
                output,
                utteranceId
            )
            if (result != TextToSpeech.SUCCESS && continuation.isActive) {
                continuation.resumeWith(
                    Result.failure(IllegalStateException("Could not create the spoken prompt."))
                )
            }
        }
    }
}
