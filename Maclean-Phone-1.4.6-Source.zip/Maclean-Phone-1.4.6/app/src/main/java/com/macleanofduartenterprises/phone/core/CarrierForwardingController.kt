package com.macleanofduartenterprises.phone.core

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.telecom.PhoneAccount
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

sealed interface CarrierForwardingResult {
    data class Success(val networkResponse: String) : CarrierForwardingResult
    data class Failure(val message: String) : CarrierForwardingResult
}

/** Sends carrier forwarding codes directly through a physical SIM subscription. */
object CarrierForwardingController {

    @SuppressLint("MissingPermission")
    fun send(
        context: Context,
        accountId: String,
        carrierCode: String,
        onResult: (CarrierForwardingResult) -> Unit,
    ) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            onResult(CarrierForwardingResult.Failure("Phone permission is required."))
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            onResult(CarrierForwardingResult.Failure("Phone-state permission is required."))
            return
        }

        val telecomManager = context.getSystemService(TelecomManager::class.java)
        val telephonyManager = context.getSystemService(TelephonyManager::class.java)
        if (telecomManager == null || telephonyManager == null) {
            onResult(CarrierForwardingResult.Failure("Cellular service is unavailable."))
            return
        }

        val phoneAccountHandle = runCatching {
            telecomManager.callCapablePhoneAccounts.firstOrNull { handle ->
                handle.id == accountId &&
                    telecomManager.getPhoneAccount(handle)
                        ?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
            }
        }.getOrNull()
        if (phoneAccountHandle == null) {
            onResult(CarrierForwardingResult.Failure("The selected physical SIM is unavailable."))
            return
        }

        val simTelephonyManager = runCatching {
            telephonyManager.createForPhoneAccountHandle(phoneAccountHandle)
        }.getOrNull()
        if (simTelephonyManager == null) {
            onResult(CarrierForwardingResult.Failure("Android could not open the selected SIM."))
            return
        }

        val mainHandler = Handler(Looper.getMainLooper())
        runCatching {
            simTelephonyManager.sendUssdRequest(
                carrierCode,
                object : TelephonyManager.UssdResponseCallback() {
                    override fun onReceiveUssdResponse(
                        telephonyManager: TelephonyManager,
                        request: String,
                        response: CharSequence,
                    ) {
                        onResult(
                            CarrierForwardingResult.Success(
                                response.toString().trim().take(500),
                            )
                        )
                    }

                    override fun onReceiveUssdResponseFailed(
                        telephonyManager: TelephonyManager,
                        request: String,
                        failureCode: Int,
                    ) {
                        val message = when (failureCode) {
                            TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL ->
                                "The carrier forwarding service is temporarily unavailable."
                            TelephonyManager.USSD_RETURN_FAILURE ->
                                "The carrier did not accept this forwarding code."
                            else -> "The carrier forwarding request failed (code $failureCode)."
                        }
                        onResult(CarrierForwardingResult.Failure(message))
                    }
                },
                mainHandler,
            )
        }.onFailure {
            onResult(
                CarrierForwardingResult.Failure(
                    "Android could not send this code directly through the selected SIM.",
                )
            )
        }
    }
}
