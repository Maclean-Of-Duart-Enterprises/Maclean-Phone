package com.macleanofduartenterprises.phone.ivr

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class SipIvrBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            return
        }
        val repository = IvrSettingsRepository(context.applicationContext)
        if (repository.loadConfig().enabled) {
            ContextCompat.startForegroundService(
                context,
                SipIvrService.intent(context, SipIvrService.ACTION_START)
            )
        }
    }
}
