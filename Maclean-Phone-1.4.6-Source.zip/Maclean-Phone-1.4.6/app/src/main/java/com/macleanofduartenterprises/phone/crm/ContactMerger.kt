package com.macleanofduartenterprises.phone.crm

import java.text.Normalizer
import java.util.Locale

internal data class ContactMergePlan(
    val merged: CrmContact,
    val sourcesToDelete: List<CrmContact>,
)

/** Deterministic, loss-averse merge and duplicate-candidate logic. No candidate is auto-merged. */
object ContactMerger {
    internal fun merge(contacts: List<CrmContact>): ContactMergePlan {
        val unique = contacts.distinctBy(CrmContact::stableId)
        require(unique.size >= 2) { "Select at least two different contacts to merge." }
        val target = unique.firstOrNull { !it.readOnly && it.id > 0L }
            ?: unique.firstOrNull { !it.readOnly && !it.systemOnly }
        val useCopy = target == null
        val basis = target ?: unique.first()

        val fields = linkedMapOf<String, CrmCustomField>()
        unique.flatMap(CrmContact::customFields).forEach { field ->
            if (field.value.isBlank()) return@forEach
            fields.putIfAbsent(field.identityKey(), field)
        }
        val notes = unique.map(CrmContact::notes)
            .map(String::trim)
            .filter(String::isNotBlank)
            .distinct()
            .joinToString("\n")
        val merged = basis.copy(
            id = if (useCopy) 0 else basis.id,
            systemContactId = if (useCopy) null else basis.systemContactId,
            rawContactId = if (useCopy) null else basis.rawContactId,
            storage = if (useCopy) ContactStorage.APP else basis.storage,
            firstName = firstValue(unique, CrmContact::firstName),
            middleName = firstValue(unique, CrmContact::middleName),
            lastName = firstValue(unique, CrmContact::lastName),
            nickname = firstValue(unique, CrmContact::nickname),
            household = firstValue(unique, CrmContact::household),
            company = firstValue(unique, CrmContact::company),
            birthday = firstValue(unique, CrmContact::birthday),
            notes = notes,
            photoUri = unique.firstNotNullOfOrNull(CrmContact::photoUri),
            stage = unique.map(CrmContact::stage).firstOrNull { it.isNotBlank() && it != CRM_STAGES.first() }
                ?: firstValue(unique, CrmContact::stage).ifBlank { CRM_STAGES.first() },
            service = firstValue(unique, CrmContact::service),
            source = firstValue(unique, CrmContact::source),
            representative = firstValue(unique, CrmContact::representative),
            nextAction = firstValue(unique, CrmContact::nextAction),
            favorite = unique.any(CrmContact::favorite),
            readOnly = false,
            customFields = fields.values.mapIndexed { index, field -> field.copy(id = 0, position = index) },
            groupIds = unique.flatMap(CrmContact::groupIds).toSet(),
            createdAt = unique.minOf(CrmContact::createdAt),
            updatedAt = System.currentTimeMillis(),
            systemOnly = false,
        )
        return ContactMergePlan(
            merged = merged,
            sourcesToDelete = unique.filter { it.stableId != basis.stableId || useCopy },
        )
    }

    fun findSuspectedDuplicates(contacts: List<CrmContact>): List<DuplicateMatch> {
        val candidates = contacts.distinctBy(CrmContact::stableId)
        if (candidates.size < 2) return emptyList()
        val parent = IntArray(candidates.size) { it }
        val reasonsByPair = mutableMapOf<Pair<Int, Int>, MutableSet<String>>()

        fun root(index: Int): Int {
            var current = index
            while (parent[current] != current) {
                parent[current] = parent[parent[current]]
                current = parent[current]
            }
            return current
        }
        fun union(left: Int, right: Int, reason: String) {
            val a = root(left)
            val b = root(right)
            if (a != b) parent[b] = a
            reasonsByPair.getOrPut(minOf(left, right) to maxOf(left, right), ::linkedSetOf)
                .add(reason)
        }

        for (left in 0 until candidates.lastIndex) {
            for (right in left + 1 until candidates.size) {
                val a = candidates[left]
                val b = candidates[right]
                val phonesA = a.customFields.filter { it.type in setOf(CrmFieldType.PHONE, CrmFieldType.FAX) }
                    .map { it.completeValue().normalizedPhoneKey() }.filter { it.length >= 7 }.toSet()
                val phonesB = b.customFields.filter { it.type in setOf(CrmFieldType.PHONE, CrmFieldType.FAX) }
                    .map { it.completeValue().normalizedPhoneKey() }.filter { it.length >= 7 }.toSet()
                if (phonesA.any(phonesB::contains)) union(left, right, "same phone")
                val emailsA = a.customFields.filter { it.type == CrmFieldType.EMAIL }
                    .map { it.value.trim().lowercase(Locale.ROOT) }.filter(String::isNotBlank).toSet()
                val emailsB = b.customFields.filter { it.type == CrmFieldType.EMAIL }
                    .map { it.value.trim().lowercase(Locale.ROOT) }.filter(String::isNotBlank).toSet()
                if (emailsA.any(emailsB::contains)) union(left, right, "same email")
                val nameA = a.displayName.normalizedName()
                val nameB = b.displayName.normalizedName()
                if (nameA.isNotBlank() && nameA == nameB) union(left, right, "exact normalized name")
            }
        }
        return candidates.indices.groupBy(::root).values
            .filter { it.size > 1 }
            .map { indices ->
                val reasons = reasonsByPair
                    .filterKeys { (a, b) -> a in indices && b in indices }
                    .values.flatten().toSet()
                DuplicateMatch(indices.map(candidates::get), reasons)
            }
    }

    private fun firstValue(
        contacts: List<CrmContact>,
        selector: (CrmContact) -> String,
    ): String = contacts.asSequence().map(selector).firstOrNull(String::isNotBlank).orEmpty()

    private fun CrmCustomField.identityKey(): String = when (type) {
        CrmFieldType.PHONE, CrmFieldType.FAX -> "$type:${completeValue().normalizedPhoneKey()}"
        CrmFieldType.EMAIL -> "$type:${value.trim().lowercase(Locale.ROOT)}"
        else -> "$type:${label.normalizedName()}:${value.trim().normalizedName()}"
    }

    private fun String.normalizedName(): String = Normalizer.normalize(this, Normalizer.Form.NFKC)
        .lowercase(Locale.ROOT)
        .filter { it.isLetterOrDigit() }
}
