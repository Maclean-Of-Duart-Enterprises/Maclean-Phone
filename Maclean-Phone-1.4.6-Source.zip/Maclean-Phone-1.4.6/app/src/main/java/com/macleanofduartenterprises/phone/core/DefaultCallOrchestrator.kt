package com.macleanofduartenterprises.phone.core

import android.content.Context
import android.net.Uri
import android.os.Build
import android.telecom.Call
import android.telecom.Call.Callback
import android.telecom.PhoneAccount
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.telephony.TelephonyManager
import android.util.Log
import com.macleanofduartenterprises.phone.App
import com.macleanofduartenterprises.phone.domain.CallAction
import com.macleanofduartenterprises.phone.domain.CallOrchestrator
import com.macleanofduartenterprises.phone.domain.CallServiceAudioDelegate
import com.macleanofduartenterprises.phone.domain.entity.CallDirection
import com.macleanofduartenterprises.phone.domain.entity.CallState
import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo
import com.macleanofduartenterprises.phone.domain.entity.GroupCallParticipant
import com.macleanofduartenterprises.phone.domain.entity.GroupCallParticipantState
import com.macleanofduartenterprises.phone.domain.entity.GroupCallState
import com.macleanofduartenterprises.phone.domain.repo.BlockedNumberRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private const val TAG = "DefaultCallOrchestrator"

/** Tracks every Telecom call until Telecom removes it, including conferences. */
@Singleton
class DefaultCallOrchestrator @Inject constructor(
    private val blockedNumberRepository: BlockedNumberRepository,
    private val callUiEffects: CallUiEffects,
    @ApplicationContext private val context: Context,
) : CallOrchestrator {

    private data class TrackedCall(
        val id: String,
        val call: Call,
        val initialState: Int,
        val isIncoming: Boolean,
        var state: Int,
        val callback: Callback,
    )

    private val _callState = MutableStateFlow<CallState>(CallState.Idle)
    override val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _groupCallState = MutableStateFlow(GroupCallState.Empty)
    override val groupCallState: StateFlow<GroupCallState> = _groupCallState.asStateFlow()

    private val trackedCalls = LinkedHashMap<Call, TrackedCall>()
    private val nextCallId = AtomicLong(1)
    private var sessionScope: CoroutineScope? = null
    private var timerJob: Job? = null
    private var callServiceAudioDelegate: CallServiceAudioDelegate? = null
    private var serviceCanAddCall = false
    private var micMuted = false
    private var speakerOn = false
    private var statusMessage: String? = null
    private var conferenceObserved = false
    private var simError: CallState.SimError? = null

    private val telephonyManager = context.getSystemService(TelephonyManager::class.java)
    private val telecomManager = context.getSystemService(TelecomManager::class.java)

    override fun onAction(callAction: CallAction) {
        when (callAction) {
            CallAction.Answer -> foregroundCall()?.answer(VideoProfile.STATE_AUDIO_ONLY)
            CallAction.Hangup -> foregroundCall()?.disconnect()
            is CallAction.Hold -> foregroundCall()?.let { call ->
                if (callAction.enabled) call.hold() else call.unhold()
            }
            is CallAction.Mute -> {
                micMuted = callAction.enabled
                callServiceAudioDelegate?.setMicMuted(callAction.enabled)
                publishState()
            }
            is CallAction.Speaker -> {
                speakerOn = callAction.enabled
                callServiceAudioDelegate?.setSpeaker(callAction.enabled)
                publishState()
            }
            is CallAction.StartDialTone -> foregroundCall()?.playDtmfTone(callAction.char)
            CallAction.StopDialTone -> foregroundCall()?.stopDtmfTone()
            is CallAction.AddCall -> addCall(callAction.phone)
            CallAction.MergeCalls -> mergeCalls()
            CallAction.SwapCalls -> swapCalls()
            is CallAction.FocusCall -> focusCall(callAction.callId)
            is CallAction.SeparateFromConference -> separate(callAction.callId)
            is CallAction.DisconnectParticipant -> disconnectParticipant(callAction.callId)
            CallAction.ClearGroupCallMessage -> {
                statusMessage = null
                publishState()
            }
        }
    }

    override fun setCallServiceAudioDelegate(audioController: CallServiceAudioDelegate) {
        callServiceAudioDelegate = audioController
    }

    override fun selectAudioRoute(routeId: String) {
        callServiceAudioDelegate?.selectAudioRoute(routeId)
    }

    override fun onCanAddCallChanged(canAddCall: Boolean) {
        serviceCanAddCall = canAddCall
        publishState()
    }

    override fun onCallAdded(call: Call) {
        if (trackedCalls.containsKey(call)) return
        Log.d(TAG, "onCallAdded: $call")
        val wasEmpty = trackedCalls.isEmpty()
        if (wasEmpty) startNewSession()
        App.needCallLogRefresh = true
        checkSimState(call)

        val initialState = call.stateCompat
        val callback = object : Callback() {
            override fun onStateChanged(changedCall: Call, state: Int) {
                trackedCalls[changedCall]?.state = state
                Log.d(TAG, "onStateChanged: id=${trackedCalls[changedCall]?.id}, state=$state")
                publishState()
            }
            override fun onDetailsChanged(changedCall: Call, details: Call.Details) {
                trackedCalls[changedCall]?.state = changedCall.stateCompat
                publishState()
            }
            override fun onParentChanged(changedCall: Call, parent: Call?) = publishState()
            override fun onChildrenChanged(changedCall: Call, children: MutableList<Call>) =
                publishState()
            override fun onConferenceableCallsChanged(
                changedCall: Call,
                conferenceableCalls: MutableList<Call>,
            ) = publishState()
        }
        trackedCalls[call] = TrackedCall(
            id = "call-${nextCallId.getAndIncrement()}",
            call = call,
            initialState = initialState,
            isIncoming = call.isIncoming(initialState),
            state = initialState,
            callback = callback,
        )
        call.registerCallback(callback)
        publishState()

        val phone = call.callerPhone()
        when (initialState) {
            Call.STATE_CONNECTING, Call.STATE_DIALING -> {
                if (wasEmpty) callUiEffects.launchCallScreen(phone)
                callUiEffects.showOutgoing(phone, context.resolveCallingLine(call))
            }
            Call.STATE_RINGING -> {
                if (blockedNumberRepository.isBlocked(phone)) {
                    call.disconnect()
                    return
                }
                callUiEffects.showIncoming(phone, context.resolveCalledLine(call))
            }
        }
    }

    override fun onCallRemoved(call: Call) {
        Log.d(TAG, "onCallRemoved: $call")
        val tracked = trackedCalls.remove(call) ?: return
        runCatching { call.unregisterCallback(tracked.callback) }
        App.needCallLogRefresh = true

        val missed = tracked.initialState == Call.STATE_RINGING &&
            call.details.connectTimeMillis == 0L &&
            (tracked.state == Call.STATE_DISCONNECTED || call.stateCompat == Call.STATE_DISCONNECTED)
        if (missed) {
            sessionScopeOrCreate().launch { callUiEffects.showMissedCall(call.callerPhone()) }
        }

        if (trackedCalls.isEmpty()) {
            timerJob?.cancel()
            timerJob = null
            statusMessage = null
            conferenceObserved = false
            serviceCanAddCall = false
            simError = null
            _groupCallState.value = GroupCallState.Empty
            _callState.value = CallState.CallDisconnected
            callUiEffects.stopCallUi()
        } else {
            publishState()
        }
    }

    override fun onDestroy() {
        trackedCalls.values.forEach { tracked ->
            runCatching { tracked.call.unregisterCallback(tracked.callback) }
        }
        trackedCalls.clear()
        callUiEffects.stopCallUi()
        callServiceAudioDelegate = null
        cancelSession()
        serviceCanAddCall = false
        micMuted = false
        speakerOn = false
        statusMessage = null
        conferenceObserved = false
        simError = null
        _groupCallState.value = GroupCallState.Empty
        _callState.value = CallState.Idle
    }

    private fun addCall(rawPhone: String) {
        val phone = rawPhone.trim()
        if (phone.isEmpty()) {
            showStatus("Enter a phone number before adding a call.")
            return
        }
        val directOwner = GroupCallPolicy.directAddOwner(policyCalls())
            ?.let(::trackedById)
            ?.call
        if (directOwner != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val assisted = PhoneSettingsPrefs.applyAssistedDialing(context, phone)
            val requested = runCatching {
                directOwner.addConferenceParticipants(
                    listOf(Uri.fromParts("tel", assisted, null)),
                )
            }.isSuccess
            showStatus(if (requested) {
                "Add-call request sent. Waiting for the calling account."
            } else {
                "The calling account rejected the add-call request."
            })
            return
        }

        val owner = foregroundTracked()
        if (!serviceCanAddCall || owner == null) {
            showStatus("This calling account does not currently allow another call.")
            return
        }
        val placed = context.dialAdditionalCall(phone, owner.call.details.accountHandle)
        showStatus(if (placed) {
            "Second call requested. Merge becomes available when your carrier allows it."
        } else {
            "The second call could not be placed. Check call permission and account service."
        })
    }

    private fun mergeCalls() {
        when (val operation = GroupCallPolicy.mergeOperation(policyCalls())) {
            is GroupCallPolicy.MergeOperation.MergeExistingConference -> {
                val requested = trackedById(operation.ownerId)?.call?.let { owner ->
                    runCatching { owner.mergeConference() }.isSuccess
                } == true
                showStatus(mergeRequestMessage(requested))
            }
            is GroupCallPolicy.MergeOperation.ConferenceCalls -> {
                val owner = trackedById(operation.ownerId)?.call
                val other = trackedById(operation.otherId)?.call
                val requested = owner != null && other != null &&
                    runCatching { owner.conference(other) }.isSuccess
                showStatus(mergeRequestMessage(requested))
            }
            null -> showStatus(
                "Merge is not available yet. Wait for the second call to connect, or check carrier support.",
            )
        }
    }

    private fun mergeRequestMessage(requested: Boolean): String = if (requested) {
        "Merge requested. Waiting for the carrier to connect the conference."
    } else {
        "The calling account rejected the merge request."
    }

    private fun swapCalls() {
        val live = trackedCalls.values.filter { it.state != Call.STATE_DISCONNECTED }
        val owner = live.firstOrNull {
            it.call.details.can(Call.Details.CAPABILITY_SWAP_CONFERENCE)
        }
        if (owner != null) {
            val requested = runCatching { owner.call.swapConference() }.isSuccess
            showStatus(if (requested) "Call swap requested." else "Unable to swap conference calls.")
            return
        }
        val active = live.firstOrNull { it.state == Call.STATE_ACTIVE }
        val held = live.firstOrNull { it.state == Call.STATE_HOLDING }
        if (active == null || held == null || !canHold(active.call)) {
            showStatus("There is no active and held call pair to swap.")
            return
        }
        val requested = runCatching {
            active.call.hold()
            held.call.unhold()
        }.isSuccess
        showStatus(if (requested) "Call swap requested." else "The calling account rejected the swap.")
    }

    private fun focusCall(callId: String) {
        val target = trackedById(callId) ?: return
        if (target.state == Call.STATE_HOLDING) {
            trackedCalls.values
                .firstOrNull { it.state == Call.STATE_ACTIVE && it.id != target.id }
                ?.call
                ?.takeIf(::canHold)
                ?.let { runCatching { it.hold() } }
            val requested = runCatching { target.call.unhold() }.isSuccess
            showStatus(if (requested) "Switch requested." else "Unable to switch to that call.")
        } else {
            publishState(preferredId = target.id)
        }
    }

    private fun separate(callId: String) {
        val target = trackedById(callId)
        if (target == null ||
            !target.call.details.can(Call.Details.CAPABILITY_SEPARATE_FROM_CONFERENCE)
        ) {
            showStatus("This participant cannot be separated by the calling account.")
            return
        }
        val requested = runCatching { target.call.splitFromConference() }.isSuccess
        showStatus(if (requested) "Separate-call request sent." else "Unable to separate this call.")
    }

    private fun disconnectParticipant(callId: String) {
        val target = trackedById(callId) ?: return
        if (target.call.parent != null &&
            !target.call.details.can(Call.Details.CAPABILITY_DISCONNECT_FROM_CONFERENCE)
        ) {
            showStatus("This calling account cannot end that participant separately.")
            return
        }
        val requested = runCatching { target.call.disconnect() }.isSuccess
        showStatus(if (requested) "End-call request sent." else "Unable to end that call.")
    }

    private fun publishState(preferredId: String? = null) {
        val live = trackedCalls.values.filter { it.state != Call.STATE_DISCONNECTED }
        if (live.isEmpty()) {
            if (trackedCalls.isNotEmpty()) _callState.value = CallState.CallDisconnected
            _groupCallState.value = GroupCallState.Empty
            return
        }

        val policyCalls = policyCalls()
        val foreground = preferredId?.let(::trackedById)
            ?.takeIf { it.state != Call.STATE_DISCONNECTED }
            ?: GroupCallPolicy.preferredForeground(policyCalls)?.let(::trackedById)
            ?: live.first()
        val isConference = GroupCallPolicy.isConference(policyCalls)
        if (isConference && !conferenceObserved) statusMessage = "Conference connected."
        conferenceObserved = isConference

        val participantIds = GroupCallPolicy.participantIds(policyCalls).toSet()
        val participants = live.filter { it.id in participantIds }.map { tracked ->
            GroupCallParticipant(
                id = tracked.id,
                name = tracked.call.callerName(),
                phone = tracked.call.callerPhone(),
                state = tracked.state.toParticipantState(),
                isForeground = tracked.id == foreground.id,
                canSeparate = tracked.call.parent != null && tracked.call.details.can(
                    Call.Details.CAPABILITY_SEPARATE_FROM_CONFERENCE,
                ),
                canDisconnect = tracked.call.parent == null || tracked.call.details.can(
                    Call.Details.CAPABILITY_DISCONNECT_FROM_CONFERENCE,
                ),
            )
        }
        _groupCallState.value = GroupCallState(
            participants = participants,
            foregroundCallId = foreground.id,
            foregroundIsIncoming = foreground.isIncoming,
            calledLine = if (foreground.isIncoming) {
                context.resolveCalledLine(foreground.call)
            } else {
                CalledLineInfo.Unknown
            },
            outgoingLine = if (foreground.isIncoming) {
                CalledLineInfo.Unknown
            } else {
                context.resolveCallingLine(foreground.call)
            },
            canAddCall = GroupCallPolicy.directAddOwner(policyCalls) != null || serviceCanAddCall,
            canMerge = GroupCallPolicy.mergeOperation(policyCalls) != null,
            canSwap = GroupCallPolicy.canSwap(policyCalls),
            isConference = isConference,
            canManageConference = isConference || live.any {
                it.call.details.can(Call.Details.CAPABILITY_MANAGE_CONFERENCE)
            },
            statusMessage = statusMessage,
        )

        simError?.let {
            _callState.value = it
            return
        }
        _callState.value = foreground.toCallState()
        when (foreground.state) {
            Call.STATE_ACTIVE -> callUiEffects.showOngoing(
                foreground.call.callerPhone(),
                callDurationSeconds(foreground.call),
                if (foreground.isIncoming) {
                    CalledLineInfo.Unknown
                } else {
                    context.resolveCallingLine(foreground.call)
                },
            )
            Call.STATE_RINGING -> callUiEffects.showIncoming(
                foreground.call.callerPhone(),
                context.resolveCalledLine(foreground.call),
            )
            Call.STATE_CONNECTING, Call.STATE_DIALING ->
                callUiEffects.showOutgoing(
                    foreground.call.callerPhone(),
                    context.resolveCallingLine(foreground.call),
                )
        }
    }

    private fun TrackedCall.toCallState(): CallState = when (state) {
        Call.STATE_ACTIVE -> CallState.Active(
            duration = callDurationSeconds(call),
            isMuted = micMuted,
            isSpeakerOn = speakerOn,
            isOnHold = false,
        )
        Call.STATE_CONNECTING -> CallState.Connecting
        Call.STATE_DIALING -> CallState.Ringing(CallDirection.OUTGOING)
        Call.STATE_RINGING -> CallState.Ringing(CallDirection.INCOMING)
        Call.STATE_HOLDING -> CallState.OnHold
        Call.STATE_DISCONNECTED -> CallState.CallDisconnected
        else -> CallState.Connecting
    }

    private fun policyCalls(): List<GroupCallPolicy.CallInfo> = trackedCalls.values.map { tracked ->
        val call = tracked.call
        GroupCallPolicy.CallInfo(
            id = tracked.id,
            state = tracked.state.toPolicyState(),
            parentId = trackedCalls[call.parent]?.id,
            childIds = call.children.mapNotNull { trackedCalls[it]?.id }.toSet(),
            conferenceableIds = call.conferenceableCalls.mapNotNull { trackedCalls[it]?.id }.toSet(),
            canMergeConference = call.details.can(Call.Details.CAPABILITY_MERGE_CONFERENCE),
            canSwapConference = call.details.can(Call.Details.CAPABILITY_SWAP_CONFERENCE),
            canAddParticipant = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                call.details.can(Call.Details.CAPABILITY_ADD_PARTICIPANT),
            canManageConference = call.details.can(Call.Details.CAPABILITY_MANAGE_CONFERENCE),
            canHold = canHold(call),
        )
    }

    private fun foregroundTracked(): TrackedCall? =
        GroupCallPolicy.preferredForeground(policyCalls())?.let(::trackedById)

    private fun foregroundCall(): Call? = foregroundTracked()?.call

    private fun trackedById(id: String): TrackedCall? =
        trackedCalls.values.firstOrNull { it.id == id }

    private fun canHold(call: Call): Boolean = call.details.can(Call.Details.CAPABILITY_HOLD) ||
        call.details.can(Call.Details.CAPABILITY_SUPPORT_HOLD)

    private fun showStatus(message: String) {
        statusMessage = message
        publishState()
    }

    private fun checkSimState(call: Call) {
        val isSimAccount = runCatching {
            telecomManager?.getPhoneAccount(call.details.accountHandle)
                ?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
        }.getOrDefault(false)
        if (!isSimAccount) {
            simError = null
            return
        }
        val state = telephonyManager?.simState ?: TelephonyManager.SIM_STATE_UNKNOWN
        simError = if (state == TelephonyManager.SIM_STATE_READY) null else {
            CallState.SimError(state, state.toSimStateReadable())
        }
    }

    private fun callDurationSeconds(call: Call): Int {
        val connectedAt = call.details.connectTimeMillis
        if (connectedAt <= 0L) return 0
        return ((System.currentTimeMillis() - connectedAt).coerceAtLeast(0L) / 1_000L)
            .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    }

    private fun startNewSession() {
        cancelSession()
        sessionScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        micMuted = false
        speakerOn = false
        statusMessage = null
        conferenceObserved = false
        simError = null
        timerJob = sessionScopeOrCreate().launch {
            while (isActive) {
                delay(1_000)
                publishState()
            }
        }
    }

    private fun sessionScopeOrCreate(): CoroutineScope {
        sessionScope?.let { return it }
        return CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate).also {
            sessionScope = it
        }
    }

    private fun cancelSession() {
        timerJob?.cancel()
        timerJob = null
        sessionScope?.cancel()
        sessionScope = null
    }

    private fun Int.toPolicyState(): GroupCallPolicy.State = when (this) {
        Call.STATE_RINGING -> GroupCallPolicy.State.RINGING
        Call.STATE_CONNECTING -> GroupCallPolicy.State.CONNECTING
        Call.STATE_DIALING -> GroupCallPolicy.State.DIALING
        Call.STATE_ACTIVE -> GroupCallPolicy.State.ACTIVE
        Call.STATE_HOLDING -> GroupCallPolicy.State.HELD
        Call.STATE_DISCONNECTED -> GroupCallPolicy.State.DISCONNECTED
        else -> GroupCallPolicy.State.UNKNOWN
    }

    private fun Int.toParticipantState(): GroupCallParticipantState = when (this) {
        Call.STATE_RINGING -> GroupCallParticipantState.RINGING
        Call.STATE_CONNECTING -> GroupCallParticipantState.CONNECTING
        Call.STATE_DIALING -> GroupCallParticipantState.DIALING
        Call.STATE_ACTIVE -> GroupCallParticipantState.ACTIVE
        Call.STATE_HOLDING -> GroupCallParticipantState.HELD
        Call.STATE_DISCONNECTED -> GroupCallParticipantState.DISCONNECTED
        else -> GroupCallParticipantState.UNKNOWN
    }

    private fun Call.isIncoming(initialState: Int): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            details.callDirection == Call.Details.DIRECTION_INCOMING
        } else {
            initialState == Call.STATE_RINGING
        }
}
