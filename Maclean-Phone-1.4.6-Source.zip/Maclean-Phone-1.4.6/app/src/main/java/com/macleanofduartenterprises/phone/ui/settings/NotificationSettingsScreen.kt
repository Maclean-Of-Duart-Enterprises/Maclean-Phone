package com.macleanofduartenterprises.phone.ui.settings

import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.core.NotificationPreferences

private enum class SoundPickerTarget { INCOMING, MISSED }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationSettingsScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    var settings by remember(context) { mutableStateOf(NotificationPreferences.load(context)) }
    var pickerTarget by remember { mutableStateOf(SoundPickerTarget.INCOMING) }

    fun update(snapshot: NotificationPreferences.Snapshot) {
        settings = snapshot
        NotificationPreferences.save(context, snapshot)
    }

    val ringtonePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            @Suppress("DEPRECATION")
            val uri = result.data?.getParcelableExtra<Uri>(
                RingtoneManager.EXTRA_RINGTONE_PICKED_URI
            )
            when (pickerTarget) {
                SoundPickerTarget.INCOMING -> update(
                    settings.copy(incomingRingtoneUri = uri?.toString().orEmpty())
                )

                SoundPickerTarget.MISSED -> update(
                    settings.copy(missedSoundUri = uri?.toString().orEmpty())
                )
            }
        }
    }

    fun launchPicker(target: SoundPickerTarget) {
        pickerTarget = target
        val type = if (target == SoundPickerTarget.INCOMING) {
            RingtoneManager.TYPE_RINGTONE
        } else {
            RingtoneManager.TYPE_NOTIFICATION
        }
        val current = when (target) {
            SoundPickerTarget.INCOMING -> settings.incomingRingtoneUri
            SoundPickerTarget.MISSED -> settings.missedSoundUri
        }
        ringtonePicker.launch(
            Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, type)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, target == SoundPickerTarget.MISSED)
                if (current.isNotBlank()) {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(current))
                }
            }
        )
    }

    fun soundTitle(uriString: String, defaultLabel: String): String {
        if (uriString.isBlank()) return defaultLabel
        return runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(uriString))?.getTitle(context)
        }.getOrNull().orEmpty().ifBlank { defaultLabel }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Notifications & sounds") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Incoming calls", style = MaterialTheme.typography.titleMedium)
            Card {
                ListItem(
                    modifier = Modifier.clickable { launchPicker(SoundPickerTarget.INCOMING) },
                    headlineContent = { Text("Ringtone") },
                    supportingContent = {
                        Text(soundTitle(settings.incomingRingtoneUri, "System default ringtone"))
                    },
                )
                SettingToggle(
                    title = "Vibrate for incoming calls",
                    checked = settings.incomingVibration,
                    onCheckedChange = { update(settings.copy(incomingVibration = it)) },
                )
            }
            Text(
                "The call notification stays silent so it does not compete with the looping ringtone.",
                style = MaterialTheme.typography.bodySmall,
            )

            Text("Missed calls", style = MaterialTheme.typography.titleMedium)
            Card {
                SettingToggle(
                    title = "Show missed-call notification",
                    checked = settings.missedEnabled,
                    onCheckedChange = { update(settings.copy(missedEnabled = it)) },
                )
                SettingToggle(
                    title = "Play notification sound",
                    checked = settings.missedSoundEnabled,
                    enabled = settings.missedEnabled,
                    onCheckedChange = { update(settings.copy(missedSoundEnabled = it)) },
                )
                ListItem(
                    modifier = Modifier.clickable(
                        enabled = settings.missedEnabled && settings.missedSoundEnabled,
                    ) { launchPicker(SoundPickerTarget.MISSED) },
                    headlineContent = { Text("Missed-call sound") },
                    supportingContent = {
                        Text(soundTitle(settings.missedSoundUri, "System default notification"))
                    },
                )
                SettingToggle(
                    title = "Vibrate for missed calls",
                    checked = settings.missedVibration,
                    enabled = settings.missedEnabled,
                    onCheckedChange = { update(settings.copy(missedVibration = it)) },
                )
            }

            Button(
                onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    )
                },
            ) {
                Icon(Icons.Outlined.Notifications, contentDescription = null)
                Text("Open Android notification controls")
            }
            Text(
                "Android notification controls can override the choices made inside the app.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun SettingToggle(
    title: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
        )
    }
}
