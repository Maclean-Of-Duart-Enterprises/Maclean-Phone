package com.macleanofduartenterprises.phone

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.macleanofduartenterprises.phone.core.dial
import com.macleanofduartenterprises.phone.core.CallingAccountPreferences
import com.macleanofduartenterprises.phone.core.CallingAccountCatalog
import com.macleanofduartenterprises.phone.core.CallingAccountInfo
import com.macleanofduartenterprises.phone.core.CallingAccountSelection
import com.macleanofduartenterprises.phone.core.CallingAccountSelectionPolicy
import com.macleanofduartenterprises.phone.ui.MainNavGraph
import com.macleanofduartenterprises.phone.ui.onboarding.OnboardingActivity
import com.macleanofduartenterprises.phone.ui.theme.MacleanPhoneTheme
import com.macleanofduartenterprises.phone.util.PermissionChecker
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions(), {})

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            handleDialIntent(intent)
        }
        checkPermission()
        setContent {
            MacleanPhoneTheme {
                MainNavGraph()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleDialIntent(intent)
    }

    private fun handleDialIntent(intent: Intent) {
        val phoneNumber = extractPhoneNumber(intent) ?: return

        when (intent.action) {
            Intent.ACTION_CALL,
            Intent.ACTION_VOICE_COMMAND,
            Intent.ACTION_CALL_BUTTON,
            Intent.ACTION_DIAL,
            Intent.ACTION_VIEW -> requestDial(phoneNumber)
        }
    }

    private fun requestDial(phone: String) {
        val accounts = CallingAccountCatalog.load(this)
        val preference = CallingAccountPreferences.load(this, accounts)
        when (val selection = CallingAccountSelectionPolicy.select(preference, accounts)) {
            CallingAccountSelection.SystemDefault -> placeOrReport(phone)
            CallingAccountSelection.ShowChooser -> showCallingAccountChooser(phone, accounts)
            is CallingAccountSelection.Specific -> {
                if (!dial(phone = phone, accountKey = selection.account.key)) {
                    showCallingAccountChooser(phone, accounts)
                }
            }
        }
    }

    private fun showCallingAccountChooser(
        phone: String,
        accounts: List<CallingAccountInfo>,
    ) {
        val systemRoute = CallingAccountCatalog.systemRoute(this, accounts)
        val items = buildList {
            add("${systemRoute.title}\n${systemRoute.detail}")
            accounts.forEach { add("${it.title}\n${it.detail}") }
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Choose calling number")
            .setItems(items) { dialog, which ->
                if (which == 0) {
                    placeOrReport(phone)
                } else {
                    val selected = accounts.getOrNull(which - 1)
                    if (selected != null && !dial(phone = phone, accountKey = selected.key)) {
                        Toast.makeText(
                            this,
                            "The selected calling account could not place the call.",
                            Toast.LENGTH_LONG,
                        ).show()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun placeOrReport(phone: String) {
        if (!dial(phone)) {
            Toast.makeText(this, "The call could not be placed.", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractPhoneNumber(intent: Intent): String? {
        val data: Uri? = intent.data
        val fromData = data?.schemeSpecificPart?.takeIf { it.isNotBlank() }
        if (fromData != null) return fromData

        val fromExtra = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER)?.takeIf { it.isNotBlank() }
        if (fromExtra != null) return fromExtra

        return null
    }


    private fun checkPermission() {
        val defaultPhoneApp = PermissionChecker.isDefaultPhoneApp(this)
        val voipOnlyMode = PermissionChecker.isVoipOnlyMode(this)
        if (defaultPhoneApp.not() && voipOnlyMode.not()) {
            startActivity(Intent(this, OnboardingActivity::class.java)).also { finish() }
        } else {
            val hasRequiredPermissions = if (defaultPhoneApp) {
                PermissionChecker.hasAllPermissions(this)
            } else {
                PermissionChecker.hasVoipPermissions(this)
            }
            if (hasRequiredPermissions.not()) {
                permissionLauncher.launch(
                    buildList {
                        if (defaultPhoneApp) {
                            add(android.Manifest.permission.CALL_PHONE)
                            add(android.Manifest.permission.READ_PHONE_STATE)
                            add(android.Manifest.permission.READ_PHONE_NUMBERS)
                            add(android.Manifest.permission.READ_CALL_LOG)
                        }
                        add(android.Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            add(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }.toTypedArray()
                )
            }
        }
    }
}
