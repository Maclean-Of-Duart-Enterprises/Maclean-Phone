package com.macleanofduartenterprises.phone.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CallAudioRouteType {
    PHONE,
    SPEAKER,
    BLUETOOTH,
    WIRED_HEADSET,
    USB,
    HEARING_AID,
    OTHER,
}

data class CallAudioRoute(
    val id: String,
    val label: String,
    val type: CallAudioRouteType,
)

/** Live audio endpoints published by the active Android InCallService. */
object CallAudioRouteState {
    private val _availableRoutes = MutableStateFlow<List<CallAudioRoute>>(emptyList())
    val availableRoutes: StateFlow<List<CallAudioRoute>> = _availableRoutes.asStateFlow()

    private val _selectedRouteId = MutableStateFlow<String?>(null)
    val selectedRouteId: StateFlow<String?> = _selectedRouteId.asStateFlow()

    internal fun publish(routes: List<CallAudioRoute>, selectedRouteId: String?) {
        _availableRoutes.value = routes.distinctBy(CallAudioRoute::id)
        _selectedRouteId.value = selectedRouteId
    }

    internal fun clear() {
        _availableRoutes.value = emptyList()
        _selectedRouteId.value = null
    }
}
