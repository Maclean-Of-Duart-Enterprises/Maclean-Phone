package com.macleanofduartenterprises.phone.domain

interface CallServiceAudioDelegate {
    fun setMicMuted(muted: Boolean)
    fun setSpeaker(enabled: Boolean)
    fun selectAudioRoute(routeId: String)
}
