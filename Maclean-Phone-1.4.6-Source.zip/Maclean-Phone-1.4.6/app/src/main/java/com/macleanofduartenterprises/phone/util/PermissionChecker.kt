package com.macleanofduartenterprises.phone.util

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Context.ROLE_SERVICE
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import com.macleanofduartenterprises.phone.MainActivity


object PermissionChecker {
    private const val APP_MODE_PREFS = "app_mode"
    private const val KEY_VOIP_ONLY_MODE = "voip_only_mode"

    fun isDefaultPhoneApp(context: Context): Boolean {

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(ROLE_SERVICE) as RoleManager
            roleManager.isRoleHeld(RoleManager.ROLE_DIALER)

        } else {
            val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val componentName = ComponentName(context, MainActivity::class.java)
            componentName.packageName == telecomManager.defaultDialerPackage
        }

    }

    fun changeDialogRequestUiIntent(context: Activity): Intent {
      return  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = context.getSystemService(ROLE_SERVICE) as RoleManager
            val intent = rm.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            intent
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, context.packageName)
            intent
        }
    }

    fun isVoipOnlyMode(context: Context): Boolean =
        context.getSharedPreferences(APP_MODE_PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_VOIP_ONLY_MODE, false)

    fun setVoipOnlyMode(context: Context, enabled: Boolean) {
        context.getSharedPreferences(APP_MODE_PREFS, Context.MODE_PRIVATE)
            .edit { putBoolean(KEY_VOIP_ONLY_MODE, enabled) }
    }


    fun hasAllPermissions(context: Context): Boolean {
        return (hasCallPhonePermission(context)
                && hasReadPhoneStatePermission(context)
                && hasReadPhoneNumbersPermission(context)
                && hasReadCallLogPermission(context)
                && hasVoipPermissions(context))
    }

    fun hasVoipPermissions(context: Context): Boolean =
        hasPostNotificationPermission(context) && hasRecordAudioPermission(context)

    fun hasCallPhonePermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasReadPhoneStatePermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasReadPhoneNumbersPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_NUMBERS,
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasReadCallLogPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED
    }
    fun hasPostNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasRecordAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasReadContactsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasWriteContactsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }
}
