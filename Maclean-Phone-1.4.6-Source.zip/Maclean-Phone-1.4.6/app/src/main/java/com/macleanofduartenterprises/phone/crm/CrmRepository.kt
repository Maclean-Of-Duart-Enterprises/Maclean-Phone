package com.macleanofduartenterprises.phone.crm

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.text.Collator
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CrmRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val database = CrmDatabase(context)
    private val systemContacts = SystemContactGateway(context)
    private val writeMutex = Mutex()
    private val photoDirectory = File(context.filesDir, "crm_contact_photos")
    private val exportDirectory = File(context.cacheDir, "crm_exports")

    suspend fun loadSnapshot(
        query: String = "",
        sortField: CrmSortField = CrmSortField.FIRST_NAME,
        ascending: Boolean = true,
        groupId: Long? = null,
        favoritesOnly: Boolean = false,
    ): CrmSnapshot = withContext(Dispatchers.IO) {
        val stored = database.loadContacts()
        val system = systemContacts.loadContacts()
        val systemByRaw = system.mapNotNull { item -> item.rawContactId?.let { it to item } }.toMap()
        val systemByContact = system.mapNotNull { item -> item.systemContactId?.let { it to item } }.toMap()
        val linkedRawIds = stored.mapNotNull(CrmContact::rawContactId).toSet()
        val linkedContactIds = stored.mapNotNull(CrmContact::systemContactId).toSet()
        val localContacts = stored.map { local ->
            val live = local.rawContactId?.let(systemByRaw::get)
                ?: local.systemContactId?.let(systemByContact::get)
            if (live == null) local else local.copy(
                systemContactId = live.systemContactId,
                rawContactId = live.rawContactId,
                storage = live.storage,
                readOnly = live.readOnly,
                photoUri = local.photoUri ?: live.photoUri,
            )
        }
        val systemOnlyContacts = system.filter {
            it.rawContactId !in linkedRawIds && it.systemContactId !in linkedContactIds
        }
        val groups = database.loadGroups()
        val needle = query.trim().lowercase(Locale.ROOT)
        val contacts = (localContacts + systemOnlyContacts)
            .asSequence()
            .filter { groupId == null || groupId in it.groupIds }
            .filter { !favoritesOnly || it.favorite }
            .filter { needle.isBlank() || needle in it.searchableText(groups) }
            .toList()
            .sortedForCrm(sortField, ascending)
        cleanupOrphanPhotos(stored.map(CrmContact::id).toSet())
        CrmSnapshot(
            contacts = contacts,
            groups = groups,
            storageOptions = systemContacts.availableStorageOptions(),
        )
    }

    suspend fun saveContact(
        contact: CrmContact,
        importedPhotoBytes: ByteArray? = null,
    ): CrmContact = withContext(Dispatchers.IO) {
        writeMutex.withLock { saveContactLocked(contact, importedPhotoBytes) }
    }

    private fun saveContactLocked(
        contact: CrmContact,
        importedPhotoBytes: ByteArray? = null,
    ): CrmContact {
        val existing = contact.id.takeIf { it > 0L }?.let(database::getContact)
        val requested = contact.copy(
            id = if (contact.systemOnly || contact.id < 0L) 0 else contact.id,
            systemOnly = false,
        )
        val storageChanged = existing != null && existing.storage != requested.storage
        val providerDraft = if (storageChanged && requested.storage != ContactStorage.APP) {
            requested.copy(systemContactId = null, rawContactId = null, readOnly = false)
        } else requested
        var createdProvider: CrmContact? = null
        val systemResult = if (requested.storage != ContactStorage.APP) {
            systemContacts.save(providerDraft, importedPhotoBytes).also { result ->
                if (result.rawContactId != existing?.rawContactId) {
                    createdProvider = providerDraft.copy(
                        systemContactId = result.contactId,
                        rawContactId = result.rawContactId,
                        readOnly = false,
                    )
                }
            }
        } else null
        val linked = requested.copy(
            systemContactId = systemResult?.contactId,
            rawContactId = systemResult?.rawContactId,
            readOnly = false,
        )
        val contactId = try {
            database.saveContact(linked)
        } catch (error: Throwable) {
            createdProvider?.let { runCatching { systemContacts.delete(it) } }
            throw error
        }

        if (storageChanged && existing?.storage != ContactStorage.APP) {
            runCatching { systemContacts.delete(existing) }.onFailure { error ->
                runCatching { database.saveContact(existing) }
                createdProvider?.let { runCatching { systemContacts.delete(it) } }
                throw IllegalStateException(
                    "The new contact was rolled back because the old Android/SIM record could not be removed: ${error.userMessage()}",
                    error,
                )
            }
        }
        val persistedPhoto = persistPhoto(contactId, linked.photoUri, importedPhotoBytes)
        if (persistedPhoto != linked.photoUri) {
            database.updateSystemLink(
                contactId,
                linked.systemContactId,
                linked.rawContactId,
                persistedPhoto,
            )
        }
        return database.getContact(contactId)
            ?: error("The CRM contact was saved but could not be reloaded.")
    }

    suspend fun deleteContact(contact: CrmContact): CrmOperationResult = withContext(Dispatchers.IO) {
        writeMutex.withLock { deleteContactsLocked(listOf(contact)) }
    }

    suspend fun deleteContacts(contacts: List<CrmContact>): CrmOperationResult = withContext(Dispatchers.IO) {
        writeMutex.withLock { deleteContactsLocked(contacts) }
    }

    private fun deleteContactsLocked(contacts: List<CrmContact>): CrmOperationResult {
        var succeeded = 0
        var failed = 0
        val messages = mutableListOf<String>()
        contacts.distinctBy(CrmContact::stableId).forEach { contact ->
            runCatching {
                if (contact.storage != ContactStorage.APP || contact.systemOnly) {
                    systemContacts.delete(contact)
                }
                if (contact.id > 0L) database.deleteContact(contact.id)
                deletePhoto(contact.id)
            }.onSuccess { succeeded++ }.onFailure { error ->
                failed++
                messages += "${contact.displayName}: ${error.userMessage()}"
            }
        }
        return CrmOperationResult(succeeded, failed, messages.take(8))
    }

    suspend fun copyContacts(
        contacts: List<CrmContact>,
        storage: ContactStorage = ContactStorage.APP,
    ): CrmOperationResult = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            var succeeded = 0
            var failed = 0
            val messages = mutableListOf<String>()
            contacts.distinctBy(CrmContact::stableId).forEach { source ->
                runCatching {
                    saveContactLocked(
                        source.copy(
                            id = 0,
                            systemContactId = null,
                            rawContactId = null,
                            storage = storage,
                            readOnly = false,
                            systemOnly = false,
                            createdAt = System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis(),
                            customFields = source.customFields.map { it.copy(id = 0) },
                        ),
                        source.photoUri?.let { readPhoto(source) },
                    )
                }.onSuccess { succeeded++ }.onFailure { error ->
                    failed++
                    messages += "${source.displayName}: ${error.userMessage()}"
                }
            }
            CrmOperationResult(succeeded, failed, messages.take(8))
        }
    }

    suspend fun setFavorite(contact: CrmContact, favorite: Boolean): CrmContact =
        withContext(Dispatchers.IO) {
            writeMutex.withLock {
                val local = ensureLocalRecordLocked(contact)
                database.setFavorite(local.id, favorite)
                database.getContact(local.id) ?: error("The favorite change could not be reloaded.")
            }
        }

    suspend fun updateGroupMembership(
        contacts: List<CrmContact>,
        groupIds: Set<Long>,
        add: Boolean,
    ): CrmOperationResult = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            var succeeded = 0
            var failed = 0
            val messages = mutableListOf<String>()
            contacts.distinctBy(CrmContact::stableId).forEach { contact ->
                runCatching {
                    val local = ensureLocalRecordLocked(contact)
                    database.updateGroupMembership(listOf(local.id), groupIds, add)
                }.onSuccess { succeeded++ }.onFailure { error ->
                    failed++
                    messages += "${contact.displayName}: ${error.userMessage()}"
                }
            }
            CrmOperationResult(succeeded, failed, messages.take(8))
        }
    }

    private fun ensureLocalRecordLocked(contact: CrmContact): CrmContact {
        if (contact.id > 0L) return database.getContact(contact.id)
            ?: error("Contact ${contact.id} no longer exists.")
        val id = database.saveContact(contact.copy(id = 0, systemOnly = false))
        val photo = persistPhoto(id, contact.photoUri, null)
        if (photo != contact.photoUri) {
            database.updateSystemLink(id, contact.systemContactId, contact.rawContactId, photo)
        }
        return database.getContact(id) ?: error("The CRM extension could not be reloaded.")
    }

    suspend fun importVCard(uri: Uri, storage: ContactStorage): VCardImportResult =
        withContext(Dispatchers.IO) {
            val parsed = context.contentResolver.openInputStream(uri)?.use(VCardParser::parse)
                ?: error("The selected VCF file could not be opened.")
            var imported = 0
            var failed = 0
            val messages = mutableListOf<String>()
            writeMutex.withLock {
                parsed.forEachIndexed { index, card ->
                    runCatching {
                        val groupIds = card.groupNames.mapNotNull { name ->
                            database.ensureGroup(name).takeIf { it > 0 }
                        }.toSet()
                        saveContactLocked(
                            card.contact.copy(storage = storage, groupIds = groupIds),
                            card.photoBytes,
                        )
                    }.onSuccess { imported++ }.onFailure { error ->
                        failed++
                        messages += "Card ${index + 1}: ${error.userMessage()}"
                    }
                }
            }
            VCardImportResult(imported, failed, messages.take(8))
        }

    suspend fun exportContacts(
        uri: Uri,
        contacts: List<CrmContact>,
        groups: List<CrmGroup>,
    ): CrmExportResult = withContext(Dispatchers.IO) {
        require(contacts.isNotEmpty()) { "There are no contacts to export." }
        val result = context.contentResolver.openOutputStream(uri, "wt")?.use { output ->
            VCardWriter.write(contacts.distinctBy(CrmContact::stableId), groups, output, ::readPhoto)
        } ?: error("The selected Save As destination could not be opened.")
        check(result.exported > 0) { result.messages.firstOrNull() ?: "No contacts were exported." }
        result
    }

    suspend fun createShareFile(
        contacts: List<CrmContact>,
        groups: List<CrmGroup>,
        label: String = "Maclean-Contacts",
    ): CrmSharedFile = withContext(Dispatchers.IO) {
        require(contacts.isNotEmpty()) { "There are no contacts to share." }
        exportDirectory.mkdirs()
        cleanupExportCache()
        val displayName = "${label.safeFileName()}-${System.currentTimeMillis()}.vcf"
        val target = File(exportDirectory, displayName)
        val result = target.outputStream().buffered().use { output ->
            VCardWriter.write(contacts.distinctBy(CrmContact::stableId), groups, output, ::readPhoto)
        }
        check(result.exported > 0) { result.messages.firstOrNull() ?: "No contacts were shared." }
        CrmSharedFile(
            uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", target),
            export = result,
            displayName = displayName,
        )
    }

    suspend fun mergeContacts(contacts: List<CrmContact>): CrmMergeResult =
        withContext(Dispatchers.IO) {
            writeMutex.withLock {
                val plan = ContactMerger.merge(contacts)
                val photoSource = contacts.firstOrNull { it.photoUri == plan.merged.photoUri }
                val saved = saveContactLocked(
                    plan.merged,
                    photoSource?.photoUri?.let { readPhoto(photoSource) },
                )
                val deletion = deleteContactsLocked(plan.sourcesToDelete)
                CrmMergeResult(
                    mergedContact = saved,
                    deletedSources = deletion.succeeded,
                    failedDeletes = deletion.failed,
                    messages = deletion.messages,
                )
            }
        }

    suspend fun findSuspectedDuplicates(contacts: List<CrmContact>): List<DuplicateMatch> =
        withContext(Dispatchers.Default) { ContactMerger.findSuspectedDuplicates(contacts) }

    suspend fun saveGroup(group: CrmGroup): Long = withContext(Dispatchers.IO) {
        writeMutex.withLock { database.saveGroup(group.copy(name = group.name.trim())) }
    }

    suspend fun deleteGroup(groupId: Long) = withContext(Dispatchers.IO) {
        writeMutex.withLock { database.deleteGroup(groupId) }
    }

    suspend fun moveGroup(groupId: Long, direction: Int) = withContext(Dispatchers.IO) {
        writeMutex.withLock { database.moveGroup(groupId, direction.coerceIn(-1, 1)) }
    }

    suspend fun findByPhone(phone: String): CrmContact? = withContext(Dispatchers.IO) {
        database.findByPhone(phone)
    }

    suspend fun getCompanyForLegacyId(legacyId: Long): String? = withContext(Dispatchers.IO) {
        (if (legacyId >= 0) database.getContactBySystemId(legacyId)?.company
        else database.getContact(-legacyId)?.company).orEmpty().takeIf(String::isNotBlank)
    }

    suspend fun searchLegacyContacts(
        query: String,
        limit: Int,
    ): List<com.macleanofduartenterprises.phone.domain.entity.Contact> = withContext(Dispatchers.IO) {
        val groups = database.loadGroups()
        val needle = query.trim().lowercase(Locale.ROOT)
        database.loadContacts().asSequence()
            .filter { needle.isNotBlank() && needle in it.searchableText(groups) }
            .map(CrmContact::toLegacyContact)
            .take(limit)
            .toList()
    }

    private fun persistPhoto(contactId: Long, sourceUri: String?, bytes: ByteArray?): String? {
        val target = File(photoDirectory, "contact_$contactId.img")
        if (bytes == null && sourceUri == null) {
            target.delete()
            return null
        }
        if (bytes == null && sourceUri?.let(Uri::parse)?.scheme == "file") {
            val existing = runCatching { File(requireNotNull(Uri.parse(sourceUri).path)) }.getOrNull()
            if (existing?.canonicalPath == target.canonicalPath && target.exists()) {
                return Uri.fromFile(target).toString()
            }
        }
        photoDirectory.mkdirs()
        val temporary = File(photoDirectory, "contact_$contactId.tmp")
        val input = bytes?.let(::ByteArrayInputStream)
            ?: sourceUri?.let(Uri::parse)?.let(context.contentResolver::openInputStream)
            ?: return sourceUri
        try {
            input.use { source ->
                temporary.outputStream().use { destination ->
                    copyBounded(source, destination, MAX_LOCAL_PHOTO_BYTES)
                }
            }
            if (!temporary.renameTo(target)) {
                temporary.copyTo(target, overwrite = true)
                check(temporary.delete()) { "The temporary contact photo could not be removed." }
            }
        } finally {
            temporary.delete()
        }
        return Uri.fromFile(target).toString()
    }

    private fun readPhoto(contact: CrmContact): ByteArray? {
        val uriText = contact.photoUri ?: return null
        return context.contentResolver.openInputStream(Uri.parse(uriText))?.use { input ->
            val output = java.io.ByteArrayOutputStream()
            copyBounded(input, output, MAX_LOCAL_PHOTO_BYTES)
            output.toByteArray()
        } ?: error("The contact photo could not be opened.")
    }

    private fun copyBounded(
        input: java.io.InputStream,
        output: java.io.OutputStream,
        maximum: Int,
    ) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maximum) { "The selected photo is larger than 8 MB." }
            output.write(buffer, 0, read)
        }
    }

    private fun deletePhoto(contactId: Long) {
        if (contactId > 0L) File(photoDirectory, "contact_$contactId.img").delete()
    }

    private fun cleanupOrphanPhotos(validIds: Set<Long>) {
        photoDirectory.listFiles()?.forEach { file ->
            val id = file.name.removePrefix("contact_").substringBefore('.').toLongOrNull()
            if (id == null || id !in validIds) file.delete()
        }
    }

    private fun cleanupExportCache() {
        val cutoff = System.currentTimeMillis() - EXPORT_CACHE_MAX_AGE
        exportDirectory.listFiles()?.filter { it.lastModified() < cutoff }?.forEach(File::delete)
    }

    companion object {
        private const val MAX_LOCAL_PHOTO_BYTES = 8 * 1024 * 1024
        private const val EXPORT_CACHE_MAX_AGE = 24 * 60 * 60 * 1000L
    }
}

private fun List<CrmContact>.sortedForCrm(
    field: CrmSortField,
    ascending: Boolean,
): List<CrmContact> {
    val collator = Collator.getInstance(Locale.getDefault()).apply { strength = Collator.PRIMARY }
    val comparator = when (field) {
        CrmSortField.FIRST_NAME -> compareByWithCollator(collator) { it.firstName.ifBlank { it.displayName } }
        CrmSortField.LAST_NAME -> compareByWithCollator(collator) { it.lastName.ifBlank { it.displayName } }
        CrmSortField.COMPANY -> compareByWithCollator(collator) { it.company.ifBlank { it.displayName } }
        CrmSortField.RECENTLY_UPDATED -> compareBy<CrmContact> { it.updatedAt }
        CrmSortField.DATE_ADDED -> compareBy<CrmContact> { it.createdAt }
    }
    val resolved = if (ascending) comparator else comparator.reversed()
    return sortedWith(resolved.thenBy { it.displayName.lowercase(Locale.ROOT) })
}

private fun compareByWithCollator(
    collator: Collator,
    selector: (CrmContact) -> String,
): Comparator<CrmContact> = Comparator { left, right -> collator.compare(selector(left), selector(right)) }

private fun String.safeFileName(): String = replace(Regex("[^A-Za-z0-9._-]+"), "-")
    .trim('-').ifBlank { "Maclean-Contacts" }.take(60)

private fun Throwable.userMessage(): String = message?.takeIf(String::isNotBlank) ?: javaClass.simpleName
