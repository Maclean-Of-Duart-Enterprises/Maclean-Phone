package com.macleanofduartenterprises.phone.core

import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.OutcomeReceiver
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.CallEndpoint
import android.telecom.CallEndpointException
import android.telecom.InCallService
import android.util.Log
import androidx.annotation.RequiresApi
import com.macleanofduartenterprises.phone.domain.CallOrchestrator
import com.macleanofduartenterprises.phone.domain.CallServiceAudioDelegate
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CallService"

/**
 * Owns call audio routing for the default-dialer UI.
 *
 * Android 14 moved route ownership from AudioManager/CallAudioState to Telecom's
 * CallEndpoint API. Using AudioManager.setCommunicationDevice() during a Telecom
 * call can appear to succeed and then be immediately overridden by Telecom. This
 * service therefore uses CallEndpoint on API 34+ and retains setAudioRoute only
 * as the pre-Android-14 compatibility path.
 */
@AndroidEntryPoint
class CallService : InCallService(), CallServiceAudioDelegate {
    @Inject
    lateinit var callOrchestrator: CallOrchestrator

    private val audioManager by lazy { getSystemService(AudioManager::class.java) }
    private var telecomEndpoints: List<CallEndpoint> = emptyList()
    private var currentTelecomEndpoint: CallEndpoint? = null

    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            refreshAudioRoutes(callAudioState)
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            refreshAudioRoutes(callAudioState)
        }
    }

    override fun onCreate() {
        Log.d(TAG, "onCreate")
        super.onCreate()
        callOrchestrator.setCallServiceAudioDelegate(this)
        callOrchestrator.onCanAddCallChanged(canAddCall())
        audioManager?.registerAudioDeviceCallback(audioDeviceCallback, null)
        refreshAudioRoutes(callAudioState)
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        callOrchestrator.onCallAdded(call)
        callOrchestrator.onCanAddCallChanged(canAddCall())
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            applyPreferredHearingAid(callAudioState)
        }
        refreshAudioRoutes(callAudioState)
    }

    @Suppress("DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        super.onCallAudioStateChanged(audioState)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            applyPreferredHearingAid(audioState)
        }
        refreshAudioRoutes(audioState)
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    override fun onAvailableCallEndpointsChanged(availableEndpoints: MutableList<CallEndpoint>) {
        super.onAvailableCallEndpointsChanged(availableEndpoints)
        telecomEndpoints = availableEndpoints.toList()
        publishTelecomEndpoints()
        applyPreferredHearingEndpoint()
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    override fun onCallEndpointChanged(callEndpoint: CallEndpoint) {
        super.onCallEndpointChanged(callEndpoint)
        currentTelecomEndpoint = callEndpoint
        publishTelecomEndpoints()
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        callOrchestrator.onCallRemoved(call)
        callOrchestrator.onCanAddCallChanged(canAddCall())
        refreshAudioRoutes(callAudioState)
    }

    override fun onCanAddCallChanged(canAddCall: Boolean) {
        super.onCanAddCallChanged(canAddCall)
        callOrchestrator.onCanAddCallChanged(canAddCall)
    }

    override fun onDestroy() {
        Log.d(TAG, "onDestroy")
        callOrchestrator.onDestroy()
        HearingAidSupport.clearCommunicationRoute(this)
        runCatching { audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback) }
        telecomEndpoints = emptyList()
        currentTelecomEndpoint = null
        CallAudioRouteState.clear()
        super.onDestroy()
    }

    override fun setMicMuted(muted: Boolean) {
        setMuted(muted)
    }

    @Suppress("DEPRECATION")
    override fun setSpeaker(enabled: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val preferredType = if (enabled) {
                CallEndpoint.TYPE_SPEAKER
            } else {
                CallEndpoint.TYPE_EARPIECE
            }
            val endpoint = telecomEndpoints.firstOrNull { it.endpointType == preferredType }
                ?: if (!enabled) {
                    telecomEndpoints.firstOrNull {
                        it.endpointType == CallEndpoint.TYPE_WIRED_HEADSET
                    }
                } else {
                    null
                }
            if (endpoint != null) {
                requestTelecomEndpoint(endpoint)
                return
            }
        }

        val route = if (enabled) {
            CallAudioState.ROUTE_SPEAKER
        } else if (shouldUseHearingAid(callAudioState)) {
            HearingAidSupport.routeCommunicationAudio(this)
            CallAudioState.ROUTE_BLUETOOTH
        } else {
            CallAudioState.ROUTE_EARPIECE
        }
        setAudioRoute(route)
        refreshAudioRoutes(callAudioState)
    }

    @Suppress("DEPRECATION")
    override fun selectAudioRoute(routeId: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            routeId.startsWith(ENDPOINT_PREFIX)
        ) {
            val endpointId = routeId.removePrefix(ENDPOINT_PREFIX)
            telecomEndpoints.firstOrNull { it.identifier.toString() == endpointId }
                ?.let(::requestTelecomEndpoint)
            return
        }

        val legacyRoute = when (routeId) {
            LEGACY_SPEAKER -> CallAudioState.ROUTE_SPEAKER
            LEGACY_BLUETOOTH -> CallAudioState.ROUTE_BLUETOOTH
            LEGACY_WIRED -> CallAudioState.ROUTE_WIRED_HEADSET
            LEGACY_PHONE -> CallAudioState.ROUTE_EARPIECE
            else -> null
        } ?: return
        setAudioRoute(legacyRoute)
        refreshAudioRoutes(callAudioState)
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    private fun requestTelecomEndpoint(endpoint: CallEndpoint) {
        requestCallEndpointChange(
            endpoint,
            mainExecutor,
            object : OutcomeReceiver<Void, CallEndpointException> {
                override fun onResult(result: Void?) {
                    Log.d(TAG, "Audio endpoint request accepted: ${endpoint.endpointName}")
                }

                override fun onError(error: CallEndpointException) {
                    Log.w(TAG, "Unable to change call endpoint", error)
                    publishTelecomEndpoints()
                }
            },
        )
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    private fun publishTelecomEndpoints() {
        if (telecomEndpoints.isEmpty()) return
        val routes = telecomEndpoints
            .map(::endpointToRoute)
            .sortedBy { it.sortOrder() }
        val selected = currentTelecomEndpoint
            ?.identifier
            ?.toString()
            ?.let { "$ENDPOINT_PREFIX$it" }
        CallAudioRouteState.publish(routes, selected)
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    private fun endpointToRoute(endpoint: CallEndpoint): CallAudioRoute {
        val type = when (endpoint.endpointType) {
            CallEndpoint.TYPE_EARPIECE -> CallAudioRouteType.PHONE
            CallEndpoint.TYPE_SPEAKER -> CallAudioRouteType.SPEAKER
            CallEndpoint.TYPE_BLUETOOTH -> CallAudioRouteType.BLUETOOTH
            CallEndpoint.TYPE_WIRED_HEADSET -> CallAudioRouteType.WIRED_HEADSET
            CallEndpoint.TYPE_STREAMING -> CallAudioRouteType.OTHER
            else -> CallAudioRouteType.OTHER
        }
        val platformName = endpoint.endpointName.toString().trim()
        val label = when {
            type == CallAudioRouteType.PHONE -> "Phone"
            type == CallAudioRouteType.SPEAKER -> "Speaker"
            platformName.isNotBlank() -> platformName
            type == CallAudioRouteType.BLUETOOTH -> "Bluetooth device"
            type == CallAudioRouteType.WIRED_HEADSET -> "Wired headset"
            else -> "Audio device"
        }
        return CallAudioRoute(
            id = "$ENDPOINT_PREFIX${endpoint.identifier}",
            label = label,
            type = type,
        )
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    private fun applyPreferredHearingEndpoint() {
        if (!AccessibilityPreferences.load(this).preferHearingAid) return
        val hearingDevice = HearingAidSupport.connectedDevice(this) ?: return
        val productName = hearingDevice.name
        val endpoint = telecomEndpoints.firstOrNull { candidate ->
            candidate.endpointType == CallEndpoint.TYPE_BLUETOOTH &&
                (productName.isBlank() ||
                    candidate.endpointName.toString().contains(productName, ignoreCase = true))
        } ?: telecomEndpoints.firstOrNull {
            it.endpointType == CallEndpoint.TYPE_BLUETOOTH &&
                it.endpointName.toString().contains("hearing", ignoreCase = true)
        }
        if (endpoint != null && endpoint != currentTelecomEndpoint) {
            requestTelecomEndpoint(endpoint)
        }
    }

    @Suppress("DEPRECATION")
    private fun applyPreferredHearingAid(audioState: CallAudioState?) {
        if (!shouldUseHearingAid(audioState)) return
        if (audioState?.route == CallAudioState.ROUTE_BLUETOOTH) return
        HearingAidSupport.routeCommunicationAudio(this)
        setAudioRoute(CallAudioState.ROUTE_BLUETOOTH)
        refreshAudioRoutes(audioState)
    }

    private fun shouldUseHearingAid(audioState: CallAudioState?): Boolean {
        if (!AccessibilityPreferences.load(this).preferHearingAid) return false
        if (HearingAidSupport.connectedDevice(this) == null) return false
        val supportedRoutes = audioState?.supportedRouteMask ?: 0
        return supportedRoutes.and(CallAudioState.ROUTE_BLUETOOTH) != 0
    }

    @Suppress("DEPRECATION")
    private fun refreshAudioRoutes(audioState: CallAudioState?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            telecomEndpoints.isNotEmpty()
        ) {
            publishTelecomEndpoints()
            return
        }

        val supported = audioState?.supportedRouteMask ?: 0
        val routes = buildList {
            if (supported and CallAudioState.ROUTE_EARPIECE != 0) {
                add(CallAudioRoute(LEGACY_PHONE, "Phone", CallAudioRouteType.PHONE))
            }
            if (supported and CallAudioState.ROUTE_WIRED_HEADSET != 0) {
                add(CallAudioRoute(LEGACY_WIRED, "Wired headset", CallAudioRouteType.WIRED_HEADSET))
            }
            if (supported and CallAudioState.ROUTE_BLUETOOTH != 0) {
                add(CallAudioRoute(LEGACY_BLUETOOTH, "Bluetooth device", CallAudioRouteType.BLUETOOTH))
            }
            if (supported and CallAudioState.ROUTE_SPEAKER != 0) {
                add(CallAudioRoute(LEGACY_SPEAKER, "Speaker", CallAudioRouteType.SPEAKER))
            }
        }
        val selected = when (audioState?.route) {
            CallAudioState.ROUTE_SPEAKER -> LEGACY_SPEAKER
            CallAudioState.ROUTE_BLUETOOTH -> LEGACY_BLUETOOTH
            CallAudioState.ROUTE_WIRED_HEADSET -> LEGACY_WIRED
            CallAudioState.ROUTE_EARPIECE -> LEGACY_PHONE
            else -> null
        }
        CallAudioRouteState.publish(routes, selected)
    }

    private fun CallAudioRoute.sortOrder(): Int = when (type) {
        CallAudioRouteType.BLUETOOTH,
        CallAudioRouteType.HEARING_AID -> 0
        CallAudioRouteType.WIRED_HEADSET,
        CallAudioRouteType.USB -> 1
        CallAudioRouteType.SPEAKER -> 2
        CallAudioRouteType.PHONE -> 3
        CallAudioRouteType.OTHER -> 4
    }

    companion object {
        private const val ENDPOINT_PREFIX = "endpoint-"
        private const val LEGACY_PHONE = "legacy-phone"
        private const val LEGACY_SPEAKER = "legacy-speaker"
        private const val LEGACY_BLUETOOTH = "legacy-bluetooth"
        private const val LEGACY_WIRED = "legacy-wired"
    }
}
