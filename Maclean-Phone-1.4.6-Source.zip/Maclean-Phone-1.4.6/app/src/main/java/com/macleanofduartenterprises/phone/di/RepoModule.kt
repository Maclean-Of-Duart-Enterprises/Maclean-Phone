package com.macleanofduartenterprises.phone.di

import com.macleanofduartenterprises.phone.data.ContactPhotoProviderImpl
import com.macleanofduartenterprises.phone.data.BlockedNumberRepositoryImpl
import com.macleanofduartenterprises.phone.core.CallUiEffects
import com.macleanofduartenterprises.phone.core.CallUiEffectsHandler
import com.macleanofduartenterprises.phone.core.DefaultCallOrchestrator
import com.macleanofduartenterprises.phone.core.DefaultDtmfToneGenerator
import com.macleanofduartenterprises.phone.core.DefaultNotificationController
import com.macleanofduartenterprises.phone.data.SimInfoProviderImpl
import com.macleanofduartenterprises.phone.data.CallLogRepositoryImpl
import com.macleanofduartenterprises.phone.data.ContactDetailProviderImpl
import com.macleanofduartenterprises.phone.data.ContactsRepositoryImpl
import com.macleanofduartenterprises.phone.data.DefaultRingToneController
import com.macleanofduartenterprises.phone.domain.CallOrchestrator
import com.macleanofduartenterprises.phone.domain.DtmfToneGenerator
import com.macleanofduartenterprises.phone.domain.NotificationController
import com.macleanofduartenterprises.phone.domain.RingToneController
import com.macleanofduartenterprises.phone.domain.repo.SimInfoProvider
import com.macleanofduartenterprises.phone.domain.repo.BlockedNumberRepository
import com.macleanofduartenterprises.phone.domain.repo.CallLogRepository
import com.macleanofduartenterprises.phone.domain.repo.ContactDetailProvider
import com.macleanofduartenterprises.phone.domain.repo.ContactPhotoProvider
import com.macleanofduartenterprises.phone.domain.repo.ContactRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepoModule {

    @Binds
    @Singleton
    abstract fun bindRingtoneController(
        defaultRingToneController: DefaultRingToneController
    ): RingToneController

    @Binds
    @Singleton
    abstract fun bindNotificationController(
        notificationController: DefaultNotificationController
    ): NotificationController


    @Binds
    @Singleton
    abstract fun bindCallOrchestrator(
        callOrchestrator: DefaultCallOrchestrator
    ): CallOrchestrator

    @Binds
    @Singleton
    abstract fun bindCallUiEffects(
        impl: CallUiEffectsHandler
    ): CallUiEffects

    @Binds
    abstract fun bindCallLogRepo(
        impl: CallLogRepositoryImpl
    ): CallLogRepository

    @Binds
    abstract fun bindContactRepo(
        impl: ContactsRepositoryImpl
    ): ContactRepository

    @Binds
    @Singleton
    abstract fun bindToneGenerator(
        impl: DefaultDtmfToneGenerator
    ): DtmfToneGenerator

    @Binds
    @Singleton
    abstract fun bindContactPhotoProvider(
        impl: ContactPhotoProviderImpl
    ): ContactPhotoProvider

    @Binds
    @Singleton
    abstract fun bindContactDetailProvider(
        impl: ContactDetailProviderImpl
    ): ContactDetailProvider

    @Binds
    @Singleton
    abstract fun bindSimInfoProvider(
        impl: SimInfoProviderImpl
    ): SimInfoProvider

    @Binds
    @Singleton
    abstract fun bindBlockedNumberRepository(
        impl: BlockedNumberRepositoryImpl
    ): BlockedNumberRepository
}
