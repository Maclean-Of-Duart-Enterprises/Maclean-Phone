package com.macleanofduartenterprises.phone.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.macleanofduartenterprises.phone.R
import com.macleanofduartenterprises.phone.core.AppearancePreferences
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import kotlin.math.roundToInt

private data class ColorChoice(val name: String, val color: Int)

private val accentChoices = listOf(
    ColorChoice("Maclean green", 0xFF286C4D.toInt()),
    ColorChoice("Dress blue", 0xFF426CA8.toInt()),
    ColorChoice("Tartan red", 0xFFA84D37.toInt()),
    ColorChoice("Heritage gold", 0xFF9A7313.toInt()),
    ColorChoice("Silver", 0xFF68747A.toInt()),
)

private val backgroundChoices = listOf(
    ColorChoice("Warm white", 0xFFF3F6F2.toInt()),
    ColorChoice("Pale blue", 0xFFDDE9F5.toInt()),
    ColorChoice("Pale green", 0xFFDCEADD.toInt()),
    ColorChoice("Charcoal", 0xFF202522.toInt()),
)

private val textChoices = listOf(
    ColorChoice("Black", 0xFF111111.toInt()),
    ColorChoice("White", 0xFFFFFFFF.toInt()),
    ColorChoice("Maclean green", 0xFF286C4D.toInt()),
    ColorChoice("Dress blue", 0xFF426CA8.toInt()),
    ColorChoice("Tartan red", 0xFFA84D37.toInt()),
    ColorChoice("Heritage gold", 0xFF9A7313.toInt()),
    ColorChoice("Silver", 0xFF68747A.toInt()),
)

private val textWindowChoices = listOf(
    ColorChoice("Warm white", 0xFFF8FBF7.toInt()),
    ColorChoice("Black", 0xFF111111.toInt()),
    ColorChoice("Pale blue", 0xFFDDE9F5.toInt()),
    ColorChoice("Pale green", 0xFFDCEADD.toInt()),
    ColorChoice("Soft gold", 0xFFF1E5BD.toInt()),
    ColorChoice("Charcoal", 0xFF202522.toInt()),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceSettingsScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    var appearance by remember(context) { mutableStateOf(AppearancePreferences.load(context)) }
    var themeMode by remember(context) { mutableStateOf(PhoneSettingsPrefs.themeMode(context)) }
    var accentHex by remember(appearance.accentColor) {
        mutableStateOf(AppearancePreferences.formatHexColor(appearance.accentColor))
    }
    var backgroundHex by remember(appearance.solidBackgroundColor) {
        mutableStateOf(AppearancePreferences.formatHexColor(appearance.solidBackgroundColor))
    }
    var textHex by remember(appearance.textColor) {
        mutableStateOf(AppearancePreferences.formatHexColor(appearance.textColor))
    }
    var textWindowHex by remember(appearance.textWindowColor) {
        mutableStateOf(AppearancePreferences.formatHexColor(appearance.textWindowColor))
    }
    var colorError by remember { mutableStateOf<String?>(null) }

    fun update(snapshot: AppearancePreferences.Snapshot) {
        appearance = snapshot
        AppearancePreferences.save(context, snapshot)
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            update(
                appearance.copy(
                    backgroundType = AppearancePreferences.BackgroundType.PHOTO,
                    photoUri = uri.toString(),
                )
            )
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Color & appearance") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Text("Theme", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PhoneSettingsPrefs.ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = themeMode == mode,
                        onClick = {
                            themeMode = mode
                            PhoneSettingsPrefs.preferences(context).edit()
                                .putString(PhoneSettingsPrefs.KEY_THEME_MODE, mode.name)
                                .apply()
                        },
                        label = { Text(mode.label) },
                    )
                }
            }

            Text("Accent color", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                accentChoices.forEach { choice ->
                    FilterChip(
                        selected = appearance.accentColor == choice.color,
                        onClick = {
                            accentHex = AppearancePreferences.formatHexColor(choice.color)
                            update(appearance.copy(accentColor = choice.color))
                        },
                        label = { Text(choice.name) },
                    )
                }
            }
            OutlinedTextField(
                value = accentHex,
                onValueChange = { accentHex = it.take(9) },
                label = { Text("Custom accent hex") },
                supportingText = { Text("Example: #286C4D") },
                singleLine = true,
                trailingIcon = {
                    Button(
                        onClick = {
                            val parsed = AppearancePreferences.parseHexColor(accentHex)
                            if (parsed == null) {
                                colorError = "Enter a six-digit hex color."
                            } else {
                                colorError = null
                                update(appearance.copy(accentColor = parsed))
                            }
                        },
                    ) { Text("Apply") }
                },
            )

            Text("Letter and word color", style = MaterialTheme.typography.titleMedium)
            Text(
                "Use the theme's automatic text color or choose a palette color for app letters and words.",
                style = MaterialTheme.typography.bodySmall,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = appearance.textColorMode ==
                        AppearancePreferences.TextColorMode.AUTOMATIC,
                    onClick = {
                        update(
                            appearance.copy(
                                textColorMode = AppearancePreferences.TextColorMode.AUTOMATIC,
                            )
                        )
                    },
                    label = { Text("Automatic") },
                )
                textChoices.forEach { choice ->
                    ColorChoiceChip(
                        selected = appearance.textColorMode ==
                            AppearancePreferences.TextColorMode.CUSTOM &&
                            appearance.textColor == choice.color,
                        choice = choice,
                        onClick = {
                            textHex = AppearancePreferences.formatHexColor(choice.color)
                            colorError = null
                            update(
                                appearance.copy(
                                    textColorMode = AppearancePreferences.TextColorMode.CUSTOM,
                                    textColor = choice.color,
                                )
                            )
                        },
                    )
                }
            }
            OutlinedTextField(
                value = textHex,
                onValueChange = { textHex = it.take(9) },
                label = { Text("Custom letter and word hex") },
                supportingText = { Text("Example: #111111") },
                singleLine = true,
                trailingIcon = {
                    Button(
                        onClick = {
                            val parsed = AppearancePreferences.parseHexColor(textHex)
                            if (parsed == null) {
                                colorError = "Enter a six-digit hex color."
                            } else {
                                colorError = null
                                update(
                                    appearance.copy(
                                        textColorMode =
                                            AppearancePreferences.TextColorMode.CUSTOM,
                                        textColor = parsed,
                                    )
                                )
                            }
                        },
                    ) { Text("Apply") }
                },
            )

            Text("App background", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppearancePreferences.BackgroundType.entries.forEach { type ->
                    FilterChip(
                        selected = appearance.backgroundType == type,
                        onClick = {
                            if (type == AppearancePreferences.BackgroundType.PHOTO &&
                                appearance.photoUri.isBlank()
                            ) {
                                photoPicker.launch(arrayOf("image/*"))
                            } else {
                                update(appearance.copy(backgroundType = type))
                            }
                        },
                        label = { Text(type.label) },
                    )
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp),
                shape = RoundedCornerShape(24.dp),
            ) {
                when (appearance.backgroundType) {
                    AppearancePreferences.BackgroundType.TARTAN -> Image(
                        painter = painterResource(R.drawable.image_favourite),
                        contentDescription = "Maclean Of Duart ancient dress tartan",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )

                    AppearancePreferences.BackgroundType.PHOTO -> AsyncImage(
                        model = Uri.parse(appearance.photoUri),
                        contentDescription = "Selected app background",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )

                    AppearancePreferences.BackgroundType.SOLID -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(appearance.solidBackgroundColor))
                    )
                }
            }

            if (appearance.backgroundType == AppearancePreferences.BackgroundType.PHOTO) {
                OutlinedButton(onClick = { photoPicker.launch(arrayOf("image/*")) }) {
                    Icon(Icons.Outlined.AddPhotoAlternate, contentDescription = null)
                    Text("Choose another photo")
                }
            }

            if (appearance.backgroundType == AppearancePreferences.BackgroundType.SOLID) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    backgroundChoices.forEach { choice ->
                        FilterChip(
                            selected = appearance.solidBackgroundColor == choice.color,
                            onClick = {
                                backgroundHex = AppearancePreferences.formatHexColor(choice.color)
                                update(appearance.copy(solidBackgroundColor = choice.color))
                            },
                            label = { Text(choice.name) },
                        )
                    }
                }
                OutlinedTextField(
                    value = backgroundHex,
                    onValueChange = { backgroundHex = it.take(9) },
                    label = { Text("Custom background hex") },
                    singleLine = true,
                    trailingIcon = {
                        Button(
                            onClick = {
                                val parsed = AppearancePreferences.parseHexColor(backgroundHex)
                                if (parsed == null) {
                                    colorError = "Enter a six-digit hex color."
                                } else {
                                    colorError = null
                                    update(appearance.copy(solidBackgroundColor = parsed))
                                }
                            },
                        ) { Text("Apply") }
                    },
                )
            }

            Text(
                "App panel opacity: ${(appearance.panelOpacity * 100).roundToInt()}%",
                style = MaterialTheme.typography.titleMedium,
            )
            Slider(
                value = appearance.panelOpacity,
                onValueChange = { update(appearance.copy(panelOpacity = it)) },
                valueRange = 0.01f..1f,
                steps = 98,
            )
            Text(
                "Higher opacity improves text readability; lower opacity shows more of the background.",
                style = MaterialTheme.typography.bodySmall,
            )

            Text("Text windows", style = MaterialTheme.typography.titleMedium)
            Text(
                "Place a colored window directly behind app text, or leave the text window clear.",
                style = MaterialTheme.typography.bodySmall,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppearancePreferences.TextWindowMode.entries.forEach { mode ->
                    FilterChip(
                        selected = appearance.textWindowMode == mode,
                        onClick = { update(appearance.copy(textWindowMode = mode)) },
                        label = { Text(mode.label) },
                    )
                }
            }
            if (appearance.textWindowMode == AppearancePreferences.TextWindowMode.COLORED) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    textWindowChoices.forEach { choice ->
                        ColorChoiceChip(
                            selected = appearance.textWindowColor == choice.color,
                            choice = choice,
                            onClick = {
                                textWindowHex =
                                    AppearancePreferences.formatHexColor(choice.color)
                                colorError = null
                                update(appearance.copy(textWindowColor = choice.color))
                            },
                        )
                    }
                }
                OutlinedTextField(
                    value = textWindowHex,
                    onValueChange = { textWindowHex = it.take(9) },
                    label = { Text("Custom text-window hex") },
                    supportingText = { Text("Example: #F8FBF7") },
                    singleLine = true,
                    trailingIcon = {
                        Button(
                            onClick = {
                                val parsed = AppearancePreferences.parseHexColor(textWindowHex)
                                if (parsed == null) {
                                    colorError = "Enter a six-digit hex color."
                                } else {
                                    colorError = null
                                    update(appearance.copy(textWindowColor = parsed))
                                }
                            },
                        ) { Text("Apply") }
                    },
                )
                Text(
                    "Text-window opacity: " +
                        "${(appearance.textWindowOpacity * 100).roundToInt()}%",
                    style = MaterialTheme.typography.titleMedium,
                )
                Slider(
                    value = appearance.textWindowOpacity,
                    onValueChange = { update(appearance.copy(textWindowOpacity = it)) },
                    valueRange = 0.01f..1f,
                    steps = 98,
                )
                Text(
                    "Adjust the colored text window from 1% through 100% opacity.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    "Text-highlight corners: " +
                        if (appearance.textWindowCornerRadius == 0f) {
                            "Square"
                        } else {
                            "${appearance.textWindowCornerRadius.roundToInt()} dp rounded"
                        },
                    style = MaterialTheme.typography.titleMedium,
                )
                Slider(
                    value = appearance.textWindowCornerRadius,
                    onValueChange = {
                        update(appearance.copy(textWindowCornerRadius = it))
                    },
                    valueRange = 0f..32f,
                    steps = 31,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "Square" to 0f,
                        "Soft" to 8f,
                        "Rounded" to 20f,
                    ).forEach { (label, radius) ->
                        FilterChip(
                            selected = appearance.textWindowCornerRadius == radius,
                            onClick = {
                                update(appearance.copy(textWindowCornerRadius = radius))
                            },
                            label = { Text(label) },
                        )
                    }
                }
                Text(
                    "Move to 0 dp for square highlighting or increase the value for more rounded corners.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            colorError?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            OutlinedButton(
                onClick = {
                    AppearancePreferences.reset(context)
                    appearance = AppearancePreferences.load(context)
                    accentHex = AppearancePreferences.formatHexColor(appearance.accentColor)
                    backgroundHex = AppearancePreferences.formatHexColor(
                        appearance.solidBackgroundColor
                    )
                    textHex = AppearancePreferences.formatHexColor(appearance.textColor)
                    textWindowHex =
                        AppearancePreferences.formatHexColor(appearance.textWindowColor)
                    colorError = null
                },
            ) {
                Icon(Icons.Outlined.RestartAlt, contentDescription = null)
                Text("Restore Maclean defaults")
            }
        }
    }
}

@Composable
private fun ColorChoiceChip(
    selected: Boolean,
    choice: ColorChoice,
    onClick: () -> Unit,
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        leadingIcon = {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .background(Color(choice.color), CircleShape),
            )
        },
        label = { Text(choice.name) },
    )
}
