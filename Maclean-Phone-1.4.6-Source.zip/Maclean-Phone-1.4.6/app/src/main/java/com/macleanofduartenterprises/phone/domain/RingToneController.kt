package com.macleanofduartenterprises.phone.domain

interface RingToneController {
    fun playCallRingTone()
    fun stepCallRingTone()
}