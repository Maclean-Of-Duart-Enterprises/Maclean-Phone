package com.macleanofduartenterprises.phone.domain.entity

/**
 * The local destination that received an incoming call.
 *
 * This is deliberately separate from the remote caller identity. Some connection services
 * expose only an account label and not the actual number, so both values are retained.
 */
data class CalledLineInfo(
    val number: String = "",
    val accountLabel: String = "",
) {
    val hasNumber: Boolean
        get() = number.isNotBlank()

    val hasAccountLabel: Boolean
        get() = accountLabel.isNotBlank()

    companion object {
        val Unknown = CalledLineInfo()
    }
}
