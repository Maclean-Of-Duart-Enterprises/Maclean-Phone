package com.macleanofduartenterprises.phone.ui.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.R

/**
 * Created by Muhammad Usman : msusman97@gmail.com on 11/16/2023.
 */

@Preview(name = "Onboarding", showBackground = true, showSystemUi = true)
@Composable
fun OnboardingScreenPreview() {
    OnboardingScreen({}, {})
}


@Composable
fun OnboardingScreen(
    onRequestDialerPermission: () -> Unit,
    onUseVoipOnly: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                painter = painterResource(id = R.drawable.app_logo_short),
                contentDescription = "Maclean Of Duart Enterprises Corp logo"
            )
            Spacer(modifier = Modifier.height(56.dp))
            Text(
                style = MaterialTheme.typography.titleMedium,
                text = "Use Maclean Phone as a full phone app, or continue with only the " +
                    "SIP/VoIP automated directory. Android will separately ask before " +
                    "granting the Phone and Caller ID & spam roles. Maclean Phone leaves " +
                    "outgoing call redirection available for Google Voice.",
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Normal

            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onRequestDialerPermission) {
                Text(text = "Use as default phone")
            }
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(onClick = onUseVoipOnly) {
                Text(text = "Use SIP IVR only")
            }
        }
    }

}
