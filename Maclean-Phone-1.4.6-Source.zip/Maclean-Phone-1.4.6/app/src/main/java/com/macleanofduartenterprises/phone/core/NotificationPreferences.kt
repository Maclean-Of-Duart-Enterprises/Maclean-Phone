package com.macleanofduartenterprises.phone.core

import android.content.Context

object NotificationPreferences {
    const val KEY_INCOMING_RINGTONE_URI = "notification_incoming_ringtone_uri"
    const val KEY_INCOMING_VIBRATION = "notification_incoming_vibration"
    const val KEY_MISSED_ENABLED = "notification_missed_enabled"
    const val KEY_MISSED_SOUND_ENABLED = "notification_missed_sound_enabled"
    const val KEY_MISSED_SOUND_URI = "notification_missed_sound_uri"
    const val KEY_MISSED_VIBRATION = "notification_missed_vibration"

    data class Snapshot(
        val incomingRingtoneUri: String,
        val incomingVibration: Boolean,
        val missedEnabled: Boolean,
        val missedSoundEnabled: Boolean,
        val missedSoundUri: String,
        val missedVibration: Boolean,
    )

    fun load(context: Context): Snapshot {
        val prefs = PhoneSettingsPrefs.preferences(context)
        return Snapshot(
            incomingRingtoneUri = prefs.getString(KEY_INCOMING_RINGTONE_URI, "").orEmpty(),
            incomingVibration = prefs.getBoolean(KEY_INCOMING_VIBRATION, true),
            missedEnabled = prefs.getBoolean(KEY_MISSED_ENABLED, true),
            missedSoundEnabled = prefs.getBoolean(KEY_MISSED_SOUND_ENABLED, true),
            missedSoundUri = prefs.getString(KEY_MISSED_SOUND_URI, "").orEmpty(),
            missedVibration = prefs.getBoolean(KEY_MISSED_VIBRATION, true),
        )
    }

    fun save(context: Context, snapshot: Snapshot) {
        PhoneSettingsPrefs.preferences(context).edit()
            .putString(KEY_INCOMING_RINGTONE_URI, snapshot.incomingRingtoneUri)
            .putBoolean(KEY_INCOMING_VIBRATION, snapshot.incomingVibration)
            .putBoolean(KEY_MISSED_ENABLED, snapshot.missedEnabled)
            .putBoolean(KEY_MISSED_SOUND_ENABLED, snapshot.missedSoundEnabled)
            .putString(KEY_MISSED_SOUND_URI, snapshot.missedSoundUri)
            .putBoolean(KEY_MISSED_VIBRATION, snapshot.missedVibration)
            .apply()
    }
}
