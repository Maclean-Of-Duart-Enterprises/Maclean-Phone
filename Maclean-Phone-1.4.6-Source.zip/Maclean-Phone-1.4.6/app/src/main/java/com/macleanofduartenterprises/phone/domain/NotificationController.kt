package com.macleanofduartenterprises.phone.domain

import android.app.Notification
import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo

interface NotificationController {
    suspend fun buildIncomingCallNotification(
        phone: String,
        calledLine: CalledLineInfo,
    ): Notification
    suspend fun buildOutgoingCallNotification(
        phone: String,
        callingLine: CalledLineInfo,
    ): Notification
    suspend fun buildOngoingCallNotification(
        phone: String,
        durationSeconds: Int,
        callingLine: CalledLineInfo,
    ): Notification
    suspend fun showMissedCallNotification(phone: String)
}
