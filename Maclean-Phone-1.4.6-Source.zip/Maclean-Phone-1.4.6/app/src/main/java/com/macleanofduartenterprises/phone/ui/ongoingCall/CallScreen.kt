package com.macleanofduartenterprises.phone.ui.ongoingCall

import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.R
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import com.macleanofduartenterprises.phone.core.CallAudioRoute
import com.macleanofduartenterprises.phone.core.CallAudioRouteType
import com.macleanofduartenterprises.phone.core.CallRecordingState
import com.macleanofduartenterprises.phone.core.CallerAssessment
import com.macleanofduartenterprises.phone.core.CallerCategory
import com.macleanofduartenterprises.phone.domain.CallAction
import com.macleanofduartenterprises.phone.domain.entity.CallState
import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.entity.GroupCallParticipantState
import com.macleanofduartenterprises.phone.domain.entity.GroupCallState
import com.macleanofduartenterprises.phone.ui.components.ContactAvatar
import com.macleanofduartenterprises.phone.ui.components.AudioRouteFab
import com.macleanofduartenterprises.phone.ui.components.SimErrorDialog
import com.macleanofduartenterprises.phone.ui.components.ToggleFab
import com.macleanofduartenterprises.phone.ui.accessibility.LocalAccessibilitySettings
import com.macleanofduartenterprises.phone.ui.accessibility.minimumControlSize
import com.macleanofduartenterprises.phone.ui.accessibility.primaryCallControlSize
import com.macleanofduartenterprises.phone.ui.home.KeyPad
import com.macleanofduartenterprises.phone.ui.theme.MacleanPhoneTheme
import com.macleanofduartenterprises.phone.ui.theme.green
import com.macleanofduartenterprises.phone.ui.theme.red
import com.macleanofduartenterprises.phone.util.secondsToReadableTime
import kotlinx.coroutines.delay

/**
 * Created by Muhammad Usman : msusman97@gmail.com on 11/17/2023.
 */

@Preview
@Composable
private fun CallScreenPrev() {
    MacleanPhoneTheme(darkTheme = false) {
        CallScreen(
            contact = ContactWithCompanyName(
                contact = Contact(
                    id = 232L,
                    name = "ALi",
                    phone = "45678o",
                    image = null,

                    ),
                companyName = "Visa",
            ),
            uiState = CallState.Idle,
            onAction = {},
            onFinish = {}
        )
    }
}


@Composable
fun CallScreen(
    contact: ContactWithCompanyName,
    uiState: CallState,
    groupCallState: GroupCallState = GroupCallState.Empty,
    onAction: (CallAction) -> Unit,
    callerAssessment: CallerAssessment = CallerAssessment.Unavailable,
    availableAudioRoutes: List<CallAudioRoute> = emptyList(),
    selectedAudioRouteId: String? = null,
    recordingState: CallRecordingState = CallRecordingState.Idle,
    onAudioRouteSelected: (String) -> Unit = {},
    onManualStartRecording: () -> Unit = {},
    onManualStopRecording: () -> Unit = {},
    onCallEnded: () -> Unit = {},
    onFinish: () -> Unit,
) {

    var keyboardOpen by rememberSaveable { mutableStateOf(false) }
    var showRecordingConsent by rememberSaveable { mutableStateOf(false) }
    var showAudioRoutePicker by rememberSaveable { mutableStateOf(false) }
    var showAddCallDialog by rememberSaveable { mutableStateOf(false) }
    var showManageCalls by rememberSaveable { mutableStateOf(false) }
    var additionalPhone by rememberSaveable { mutableStateOf("") }
    var visualAlertOn by remember { mutableStateOf(false) }
    val accessibility = LocalAccessibilitySettings.current
    LaunchedEffect(uiState.isIncomingCall(), accessibility.visualAlerts) {
        if (!uiState.isIncomingCall() || !accessibility.visualAlerts) {
            visualAlertOn = false
            return@LaunchedEffect
        }
        while (true) {
            visualAlertOn = !visualAlertOn
            delay(450)
        }
    }
    LaunchedEffect(uiState) {
        Log.d("CallScreen", "uiState: $uiState")
        if (uiState == CallState.CallDisconnected) {
            // A call ending must safely finalize an active file, but it never
            // starts a recording. Starting and ordinary stopping remain tied
            // exclusively to the visible manual control below.
            onCallEnded()
            onFinish()
        }
    }
    if (uiState is CallState.SimError) {
        SimErrorDialog(
            message = uiState.message,
            onDismiss = {
                onFinish()
            }
        )
    }


    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface).statusBarsPadding(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
        CallHeader(
            modifier = Modifier.weight(1.0f),
            contact = contact.contact,
            companyName = contact.companyName,
            callerAssessment = callerAssessment,
            uiState = uiState,
            groupCallState = groupCallState,
            onContactDetailClick = {}
        )

        KeyPad(
            keyboardOpen = keyboardOpen,
            startTone = { onAction(CallAction.StartDialTone(it)) },
            stopTone = { onAction(CallAction.StopDialTone) }
        )
        Column(
            modifier = Modifier
                .background(color = MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {

            if (accessibility.largeControls || accessibility.textScale > 1.2f) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        ToggleFab(
                            icon = R.drawable.baseline_dialpad_24,
                            text = "Keyboard",
                            modifier = Modifier.weight(1f),
                            onAction = { keyboardOpen = it },
                        )
                        ToggleFab(
                            icon = R.drawable.outline_pause_24,
                            text = "Hold",
                            modifier = Modifier.weight(1f),
                            onAction = { onAction(CallAction.Hold(it)) },
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        ToggleFab(
                            icon = R.drawable.outline_mic_off_24,
                            text = "Mute",
                            modifier = Modifier.weight(1f),
                            onAction = { onAction(CallAction.Mute(it)) },
                        )
                        AudioRouteFab(
                            icon = R.drawable.outline_volume_up_24,
                            isSpeakerActive = availableAudioRoutes
                                .firstOrNull { it.id == selectedAudioRouteId }
                                ?.type == CallAudioRouteType.SPEAKER,
                            modifier = Modifier.weight(1f),
                            onShortClick = {
                                val speakerOn = availableAudioRoutes
                                    .firstOrNull { it.id == selectedAudioRouteId }
                                    ?.type == CallAudioRouteType.SPEAKER
                                onAction(CallAction.Speaker(!speakerOn))
                            },
                            onThreeSecondHold = { showAudioRoutePicker = true },
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ToggleFab(
                        icon = R.drawable.baseline_dialpad_24,
                        text = "Keyboard",
                        onAction = { keyboardOpen = it },
                    )
                    ToggleFab(
                        icon = R.drawable.outline_pause_24,
                        text = "Hold",
                        onAction = { onAction(CallAction.Hold(it)) },
                    )
                    ToggleFab(
                        icon = R.drawable.outline_mic_off_24,
                        text = "Mute",
                        onAction = { onAction(CallAction.Mute(it)) },
                    )
                    AudioRouteFab(
                        icon = R.drawable.outline_volume_up_24,
                        isSpeakerActive = availableAudioRoutes
                            .firstOrNull { it.id == selectedAudioRouteId }
                            ?.type == CallAudioRouteType.SPEAKER,
                        onShortClick = {
                            val speakerOn = availableAudioRoutes
                                .firstOrNull { it.id == selectedAudioRouteId }
                                ?.type == CallAudioRouteType.SPEAKER
                            onAction(CallAction.Speaker(!speakerOn))
                        },
                        onThreeSecondHold = { showAudioRoutePicker = true },
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            if (uiState != CallState.Idle &&
                uiState != CallState.CallDisconnected &&
                uiState !is CallState.SimError &&
                !uiState.isIncomingCall()
            ) {
                GroupCallControls(
                    state = groupCallState,
                    onAddCall = { showAddCallDialog = true },
                    onMergeCalls = { onAction(CallAction.MergeCalls) },
                    onSwapCalls = { onAction(CallAction.SwapCalls) },
                    onManageCalls = { showManageCalls = true },
                    onDismissMessage = { onAction(CallAction.ClearGroupCallMessage) },
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
            val isRecording = recordingState is CallRecordingState.Recording
            val canRecord = uiState is CallState.Active || uiState is CallState.OnHold
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Button(
                    modifier = Modifier.heightIn(min = accessibility.minimumControlSize),
                    enabled = canRecord || isRecording,
                    onClick = {
                        if (isRecording) {
                            onManualStopRecording()
                        } else {
                            showRecordingConsent = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRecording) red else MaterialTheme.colorScheme.primary,
                    ),
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.baseline_fiber_manual_record_24),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(if (isRecording) "Stop recording" else "Start recording")
                }
                when (recordingState) {
                    is CallRecordingState.Recording -> Text(
                        "Recording in progress — ${recordingState.captureDescription}",
                        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                        color = red,
                        style = MaterialTheme.typography.labelMedium,
                    )

                    is CallRecordingState.Saved -> Text(
                        "Saved: ${recordingState.displayName} — " +
                            recordingState.captureDescription,
                        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                        style = MaterialTheme.typography.labelSmall,
                    )

                    is CallRecordingState.Error -> Text(
                        recordingState.message,
                        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Assertive },
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center,
                    )

                    CallRecordingState.Idle -> Text(
                        "Manual control — recording stays off until you press Start recording.",
                        style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            CallActionButtons(
                phone = contact.contact.phone,
                uiState = uiState,
                onAnswer = { onAction(CallAction.Answer) },
                onHangup = { onAction(CallAction.Hangup) }
            )

        }

        }

        if (visualAlertOn) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.32f))
            )
        }
    }

    if (showRecordingConsent) {
        AlertDialog(
            onDismissRequest = { showRecordingConsent = false },
            title = { Text("Record this call?") },
            text = {
                Text(
                    "Recording never starts automatically. Only continue when everyone has " +
                        "consented and local law permits it. For the best chance of hearing " +
                        "both people, use Speaker so the microphone can hear the other caller. " +
                        "Android may still block cellular call audio on this device."
                )
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(
                        onClick = {
                            showRecordingConsent = false
                            onManualStartRecording()
                        },
                    ) { Text("Record current audio route") }
                    Button(
                        onClick = {
                            showRecordingConsent = false
                            onAction(CallAction.Speaker(true))
                            onManualStartRecording()
                        },
                    ) { Text("Use speaker & record both voices") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecordingConsent = false }) { Text("Cancel") }
            },
        )
    }

    if (showAudioRoutePicker) {
        val routes = availableAudioRoutes.ifEmpty {
            listOf(
                CallAudioRoute("legacy-phone", "Phone", CallAudioRouteType.PHONE),
                CallAudioRoute("legacy-speaker", "Speaker", CallAudioRouteType.SPEAKER),
            )
        }
        AlertDialog(
            onDismissRequest = { showAudioRoutePicker = false },
            title = { Text("Call sound output") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Choose a connected Bluetooth, hearing, wired, phone, or speaker output.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    routes.forEachIndexed { index, route ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onAudioRouteSelected(route.id)
                                    showAudioRoutePicker = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = route.id == selectedAudioRouteId,
                                onClick = null,
                            )
                            Text(route.label, modifier = Modifier.padding(start = 8.dp))
                        }
                        if (index < routes.lastIndex) HorizontalDivider()
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioRoutePicker = false }) { Text("Done") }
            },
        )
    }

    if (showAddCallDialog) {
        AlertDialog(
            onDismissRequest = { showAddCallDialog = false },
            title = { Text("Add call") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter the second number. The existing call remains managed by Android Telecom.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    OutlinedTextField(
                        value = additionalPhone,
                        onValueChange = { additionalPhone = it },
                        label = { Text("Phone number") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = additionalPhone.isNotBlank(),
                    onClick = {
                        onAction(CallAction.AddCall(additionalPhone))
                        additionalPhone = ""
                        showAddCallDialog = false
                    },
                ) { Text("Call") }
            },
            dismissButton = {
                TextButton(onClick = { showAddCallDialog = false }) { Text("Cancel") }
            },
        )
    }

    if (showManageCalls) {
        AlertDialog(
            onDismissRequest = { showManageCalls = false },
            title = {
                Text(if (groupCallState.isConference) "Manage conference" else "Manage calls")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    groupCallState.participants.forEachIndexed { index, participant ->
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                participant.name.takeUnless { it == "Unknown" || it.isBlank() }
                                    ?: participant.phone.ifBlank { "Unknown caller" },
                                fontWeight = FontWeight.Bold,
                            )
                            if (participant.phone.isNotBlank()) {
                                Text(participant.phone, style = MaterialTheme.typography.bodySmall)
                            }
                            Text(
                                participant.state.readableLabel(),
                                style = MaterialTheme.typography.labelSmall,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (!participant.isForeground &&
                                    (participant.state == GroupCallParticipantState.ACTIVE ||
                                        participant.state == GroupCallParticipantState.HELD)
                                ) {
                                    TextButton(
                                        onClick = { onAction(CallAction.FocusCall(participant.id)) },
                                    ) { Text("Switch") }
                                }
                                if (participant.canSeparate) {
                                    TextButton(
                                        onClick = {
                                            onAction(CallAction.SeparateFromConference(participant.id))
                                        },
                                    ) { Text("Separate") }
                                }
                                if (participant.canDisconnect) {
                                    TextButton(
                                        onClick = {
                                            onAction(CallAction.DisconnectParticipant(participant.id))
                                        },
                                    ) { Text("End") }
                                }
                            }
                        }
                        if (index < groupCallState.participants.lastIndex) HorizontalDivider()
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showManageCalls = false }) { Text("Done") }
            },
        )
    }
}

@Composable
private fun GroupCallControls(
    state: GroupCallState,
    onAddCall: () -> Unit,
    onMergeCalls: () -> Unit,
    onSwapCalls: () -> Unit,
    onManageCalls: () -> Unit,
    onDismissMessage: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(
                modifier = Modifier.weight(1f),
                enabled = state.canAddCall,
                onClick = onAddCall,
            ) { Text("Add call") }
            Button(
                modifier = Modifier.weight(1f),
                enabled = state.canMerge,
                onClick = onMergeCalls,
            ) { Text("Merge calls") }
        }
        if (state.canSwap || state.participants.size > 1 || state.canManageConference) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.canSwap) {
                    OutlinedButton(onClick = onSwapCalls) { Text("Swap calls") }
                }
                if (state.participants.size > 1 || state.canManageConference) {
                    OutlinedButton(onClick = onManageCalls) {
                        Text("Manage (${state.participants.size})")
                    }
                }
            }
        }
        if (!state.canAddCall && state.participants.isNotEmpty()) {
            Text(
                "The current calling account has not enabled another call.",
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
            )
        } else if (state.participants.size > 1 && !state.canMerge && !state.isConference) {
            Text(
                "Waiting for the carrier to make these calls mergeable.",
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
            )
        }
        state.statusMessage?.let { message ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    message,
                    modifier = Modifier
                        .weight(1f)
                        .semantics { liveRegion = LiveRegionMode.Polite },
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                )
                TextButton(onClick = onDismissMessage) { Text("Dismiss") }
            }
        }
    }
}

private fun GroupCallParticipantState.readableLabel(): String = when (this) {
    GroupCallParticipantState.RINGING -> "Ringing"
    GroupCallParticipantState.CONNECTING -> "Connecting"
    GroupCallParticipantState.DIALING -> "Dialing"
    GroupCallParticipantState.ACTIVE -> "Active"
    GroupCallParticipantState.HELD -> "On hold"
    GroupCallParticipantState.DISCONNECTED -> "Ended"
    GroupCallParticipantState.UNKNOWN -> "Call"
}

@Composable
fun CallHeader(
    modifier: Modifier = Modifier,
    contact: Contact,
    companyName: String?,
    callerAssessment: CallerAssessment,
    uiState: CallState,
    groupCallState: GroupCallState,
    onContactDetailClick: (Contact) -> Unit
) {
    Surface {
        Column(
            modifier = modifier
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(56.dp))
            ContactAvatar(
                modifier = Modifier.size(96.dp),
                contact = contact,
                onClick = { onContactDetailClick(contact) })
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                contact.name,
                modifier = Modifier.semantics { heading() },
                style = MaterialTheme.typography.titleLarge,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(companyName ?: "", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(contact.phone, style = MaterialTheme.typography.bodyLarge)
            if (groupCallState.foregroundIsIncoming) {
                Spacer(modifier = Modifier.height(12.dp))
                IncomingCalledLine(calledLine = groupCallState.calledLine)
            } else if (uiState != CallState.Idle && uiState != CallState.CallDisconnected) {
                Spacer(modifier = Modifier.height(12.dp))
                OutgoingCallingLine(callingLine = groupCallState.outgoingLine)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Llama Local: ${callerAssessment.displayLabel}",
                color = when (callerAssessment.category) {
                    CallerCategory.BLOCKED,
                    CallerCategory.LIKELY_SPAM -> MaterialTheme.colorScheme.error
                    CallerCategory.CAUTION -> MaterialTheme.colorScheme.tertiary
                    else -> MaterialTheme.colorScheme.primary
                },
                style = MaterialTheme.typography.labelLarge,
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                uiState.toReadableStatus(),
                modifier = Modifier.semantics {
                    liveRegion = LiveRegionMode.Assertive
                },
                style = MaterialTheme.typography.bodySmall
            )
            if (groupCallState.isConference) {
                Text(
                    "Group call • ${groupCallState.participants.size} participants",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            if (uiState is CallState.Active) {
                Text(
                    text = secondsToReadableTime(uiState.duration),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
            } else if (uiState is CallState.OnHold) {
                Text(
                    text = "Call On Hold",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun OutgoingCallingLine(callingLine: CalledLineInfo) {
    Surface(
        modifier = Modifier
            .widthIn(max = 360.dp)
            .padding(horizontal = 24.dp)
            .semantics { liveRegion = LiveRegionMode.Polite },
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.tertiaryContainer,
        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Calling from",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                callingLine.number.ifBlank { "Number not provided by this calling account" },
                style = if (callingLine.hasNumber) {
                    MaterialTheme.typography.titleMedium
                } else {
                    MaterialTheme.typography.bodySmall
                },
                textAlign = TextAlign.Center,
            )
            if (callingLine.hasAccountLabel) {
                Text(
                    "Account: ${callingLine.accountLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun IncomingCalledLine(calledLine: CalledLineInfo) {
    Surface(
        modifier = Modifier
            .widthIn(max = 360.dp)
            .padding(horizontal = 24.dp)
            .semantics { liveRegion = LiveRegionMode.Polite },
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Called number",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                calledLine.number.ifBlank { "Not provided by this calling account" },
                style = if (calledLine.hasNumber) {
                    MaterialTheme.typography.titleMedium
                } else {
                    MaterialTheme.typography.bodySmall
                },
                textAlign = TextAlign.Center,
            )
            if (calledLine.hasAccountLabel) {
                Text(
                    "Line: ${calledLine.accountLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
fun KeyPad(keyboardOpen: Boolean, startTone: (Char) -> Unit, stopTone: () -> Unit) {
    var dialed by rememberSaveable { mutableStateOf("") }
    androidx.compose.animation.AnimatedVisibility(
        visible = keyboardOpen,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = slideOutVertically { it / 2 } + fadeOut(),

        ) {

        KeyPad(
            phone = dialed,
            onTapDown = {
                dialed += it
                startTone(it)
            },
            onTapUp = stopTone,
            onBackSpaceClicked = {
                dialed = dialed.dropLast(1)
            },
            onClearClicked = {
                dialed = ""
            },
            onCallClicked = {},
            showCallButton = false,
            showClearButton = false,
        )
    }
}


@Composable
fun CallActionButtons(
    phone: String,
    uiState: CallState,
    onAnswer: () -> Unit,
    onHangup: () -> Unit,
) {
    val context = LocalContext.current
    val accessibility = LocalAccessibilitySettings.current
    val useSwipeToAnswer =
        PhoneSettingsPrefs.incomingGesture(context) ==
                PhoneSettingsPrefs.IncomingGesture.SWIPE
    var swipeProgress by rememberSaveable(uiState) { mutableStateOf(0f) }
    var showQuickResponses by rememberSaveable { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
        horizontalArrangement = if (uiState.isIncomingCall()) Arrangement.SpaceBetween else Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {

        if (uiState.isIncomingCall() && useSwipeToAnswer) {
            FloatingActionButton(
                onClick = onHangup,
                modifier = Modifier.size(accessibility.primaryCallControlSize),
                containerColor = red,
                contentColor = Color.White
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_call_end_24),
                    contentDescription = "Decline"
                )
            }
            TextButton(onClick = { showQuickResponses = true }) {
                Text("Reply")
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "Swipe right to answer",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelLarge,
                )
                Slider(
                    value = swipeProgress,
                    onValueChange = { swipeProgress = it },
                    onValueChangeFinished = {
                        if (swipeProgress >= 0.85f) {
                            onAnswer()
                        }
                        swipeProgress = 0f
                    },
                    valueRange = 0f..1f,
                )
            }
        } else if (uiState.isIncomingCall()) {
            FloatingActionButton(
                onClick = onHangup,
                modifier = Modifier.size(accessibility.primaryCallControlSize),
                containerColor = red,
                contentColor = Color.White
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_call_end_24),
                    contentDescription = "Decline"
                )
            }
            TextButton(onClick = { showQuickResponses = true }) {
                Text("Reply")
            }
            FloatingActionButton(
                onClick = onAnswer,
                modifier = Modifier.size(accessibility.primaryCallControlSize),
                containerColor = green,
                contentColor = Color.White
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_call_24),
                    contentDescription = "Accept"
                )
            }
        } else {
            FloatingActionButton(
                onClick = onHangup,
                modifier = Modifier.size(accessibility.primaryCallControlSize),
                containerColor = red,
                contentColor = Color.White
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_call_end_24),
                    contentDescription = "End Call"
                )
            }
        }
    }

    if (showQuickResponses) {
        AlertDialog(
            onDismissRequest = { showQuickResponses = false },
            title = { Text("Reply with a message") },
            text = {
                Column {
                    PhoneSettingsPrefs.quickResponses(context).forEach { response ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                showQuickResponses = false
                                onHangup()
                                val intent = Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse("smsto:${Uri.encode(phone)}"),
                                ).putExtra("sms_body", response)
                                runCatching { context.startActivity(intent) }
                            },
                        ) {
                            Text(
                                text = response,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Start,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickResponses = false }) {
                    Text("Cancel")
                }
            },
        )
    }
}
