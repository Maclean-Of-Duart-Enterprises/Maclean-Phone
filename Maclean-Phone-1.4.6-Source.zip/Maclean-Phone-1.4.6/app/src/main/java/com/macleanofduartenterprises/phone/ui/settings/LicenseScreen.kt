package com.macleanofduartenterprises.phone.ui.settings

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.ui.components.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object AppLicenseText {
    const val ASSET_PATH = "licenses/AGPL-3.0.txt"

    fun load(context: Context): Result<String> = runCatching {
        context.assets.open(ASSET_PATH).bufferedReader(Charsets.UTF_8).use { reader ->
            reader.readText()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LicenseScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val licenseResult by produceState<Result<String>?>(initialValue = null, context) {
        value = withContext(Dispatchers.IO) { AppLicenseText.load(context) }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("License") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        when (val result = licenseResult) {
            null -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }

            else -> result.fold(
                onSuccess = { licenseText ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Text(
                            text = "GNU Affero General Public License v3.0",
                            style = MaterialTheme.typography.headlineSmall,
                        )
                        Text(
                            text = "Maclean Phone is distributed under the GNU AGPLv3. " +
                                "Third-party components retain the licenses identified in " +
                                "the source archive. The complete license text is bundled " +
                                "below and remains readable without an internet connection.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        HorizontalDivider(modifier = Modifier.fillMaxWidth())
                        SelectionContainer {
                            Text(
                                text = licenseText,
                                modifier = Modifier.fillMaxWidth(),
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                            )
                        }
                    }
                },
                onFailure = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "The bundled AGPLv3 license text could not be opened.",
                            style = MaterialTheme.typography.bodyLarge,
                        )
                    }
                },
            )
        }
    }
}
