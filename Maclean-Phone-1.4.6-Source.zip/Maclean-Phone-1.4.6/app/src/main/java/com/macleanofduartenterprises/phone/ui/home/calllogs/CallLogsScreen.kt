package com.macleanofduartenterprises.phone.ui.home.calllogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import com.macleanofduartenterprises.phone.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import androidx.paging.compose.collectAsLazyPagingItems
import com.macleanofduartenterprises.phone.App
import com.macleanofduartenterprises.phone.domain.entity.CallLogData
import com.macleanofduartenterprises.phone.domain.entity.CallLogFilter
import com.macleanofduartenterprises.phone.ui.components.LazyPagedColumn
import com.macleanofduartenterprises.phone.ui.home.CallLogItem
import com.macleanofduartenterprises.phone.ui.home.HeaderItem
import com.macleanofduartenterprises.phone.util.toDayCategory


@Composable
fun CallLogsScreen(
    onCallClick: (String) -> Unit,
    onCallLogClick: (CallLogData) -> Unit,
    onContactDetailClick: (CallLogData) -> Unit,
    vm: CallLogsViewModel = hiltViewModel()
) {
    val callLogs: LazyPagingItems<CallLogUiModel> = vm.callLogs.collectAsLazyPagingItems()
    val selectedFilter by vm.selectedFilter.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner, callLogs) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (App.needCallLogRefresh) {
                    App.needCallLogRefresh = false
                    callLogs.refresh()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    CallLogsScreenInternal(
        callLogs = callLogs,
        selectedFilter = selectedFilter,
        onFilterSelected = vm::selectFilter,
        onContactDetailClick = onContactDetailClick,
        onCallClick = onCallClick,
        onCallLogClick = onCallLogClick
    )
}

@Composable
fun CallLogsScreenInternal(
    callLogs: LazyPagingItems<CallLogUiModel>,
    selectedFilter: CallLogFilter,
    onFilterSelected: (CallLogFilter) -> Unit,
    onContactDetailClick: (CallLogData) -> Unit,
    onCallClick: (String) -> Unit,
    onCallLogClick: (CallLogData) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 10.dp,
                bottom = 6.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(CallLogFilter.entries, key = CallLogFilter::name) { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { onFilterSelected(filter) },
                    label = { Text(filter.label) },
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            LazyPagedColumn(
                modifier = Modifier.fillMaxSize(),
                pagingItems = callLogs
            ) {
                items(callLogs.itemCount, key = { index ->
                    when (val item = callLogs[index]) {
                        is CallLogUiModel.Header -> "header_${item.date.time}"
                        is CallLogUiModel.Item -> "item_${item.log.id}"
                        null -> index
                    }
                }) { index ->
                    when (val model = callLogs.peek(index)) {
                        is CallLogUiModel.Header -> {
                            HeaderItem(text = model.date.toDayCategory())
                        }

                        is CallLogUiModel.Item -> {
                            CallLogItem(
                                logData = model.log,
                                onCallLogClick = onCallLogClick,
                                onCallClick = { onCallClick(model.log.phone) },
                                onContactDetailClick = onContactDetailClick
                            )
                        }

                        null -> Unit
                    }
                }
            }

            if (callLogs.itemCount == 0 && callLogs.loadState.refresh is LoadState.NotLoading) {
                Text(
                    text = "No ${selectedFilter.label.lowercase()} calls found",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
