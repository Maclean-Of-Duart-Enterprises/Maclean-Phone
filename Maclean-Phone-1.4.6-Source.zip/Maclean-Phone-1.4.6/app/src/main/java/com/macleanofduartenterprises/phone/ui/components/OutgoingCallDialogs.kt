package com.macleanofduartenterprises.phone.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.PhoneForwarded
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.macleanofduartenterprises.phone.core.CallingAccountInfo
import com.macleanofduartenterprises.phone.core.SystemCallingRouteInfo
import com.macleanofduartenterprises.phone.domain.entity.ContactPhone

@Composable
fun PhoneNumberSelectionDialog(
    contactName: String,
    phones: List<ContactPhone>,
    onSelected: (ContactPhone) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Call $contactName") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    "Choose which number to call.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                phones.forEach { phone ->
                    SelectionRow(
                        title = phone.label.ifBlank { "Phone" },
                        detail = phone.number + if (phone.isPrimary) " • Primary" else "",
                        onClick = { onSelected(phone) },
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun CallingAccountSelectionDialog(
    systemRoute: SystemCallingRouteInfo,
    accounts: List<CallingAccountInfo>,
    onSystemSelected: () -> Unit,
    onAccountSelected: (CallingAccountInfo) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose calling number") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    "Choose which phone, SIM, or registered VoIP account places this call.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                SelectionRow(
                    title = systemRoute.title,
                    detail = systemRoute.detail,
                    onClick = onSystemSelected,
                    system = true,
                )
                accounts.forEach { account ->
                    SelectionRow(
                        title = account.title,
                        detail = account.detail,
                        onClick = { onAccountSelected(account) },
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SelectionRow(
    title: String,
    detail: String,
    onClick: () -> Unit,
    system: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            if (system) Icons.Outlined.Phone else Icons.AutoMirrored.Outlined.PhoneForwarded,
            contentDescription = null,
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (detail.isNotBlank()) {
                Text(detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
