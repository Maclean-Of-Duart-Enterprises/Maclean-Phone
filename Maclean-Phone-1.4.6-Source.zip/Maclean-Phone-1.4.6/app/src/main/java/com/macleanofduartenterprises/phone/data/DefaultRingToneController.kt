package com.macleanofduartenterprises.phone.data

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.net.Uri
import com.macleanofduartenterprises.phone.core.NotificationPreferences
import com.macleanofduartenterprises.phone.domain.RingToneController
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class DefaultRingToneController @Inject constructor(
    @ApplicationContext private val context: Context
) : RingToneController {
    private var ringtone: Ringtone? = null
    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun createRingtone(): Ringtone? {
        val selected = NotificationPreferences.load(context).incomingRingtoneUri
        val ringtoneUri = selected.takeIf(String::isNotBlank)?.let(Uri::parse)
            ?: RingtoneManager.getActualDefaultRingtoneUri(
                context,
                RingtoneManager.TYPE_RINGTONE
            )
            ?: return null
        return RingtoneManager.getRingtone(context, ringtoneUri)?.apply {
            audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                isLooping = true
            }
        }
    }

    override fun playCallRingTone() {
        if (ringtone?.isPlaying != true) {
            ringtone = createRingtone()
            ringtone?.play()
        }
        if (NotificationPreferences.load(context).incomingVibration && vibrator.hasVibrator()) {
            vibrator.cancel()
            vibrator.vibrate(
                VibrationEffect.createWaveform(
                    longArrayOf(0L, 600L, 500L, 600L, 1_500L),
                    0,
                )
            )
        }
    }

    override fun stepCallRingTone() {
        if (ringtone?.isPlaying == true) {
            ringtone?.stop()
        }
        ringtone = null
        vibrator.cancel()
    }
}
