package com.macleanofduartenterprises.phone.data

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.telecom.PhoneAccount
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import com.macleanofduartenterprises.phone.domain.repo.SimInfoProvider
import com.macleanofduartenterprises.phone.domain.entity.SimInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SimInfoProviderImpl @Inject constructor(
    @ApplicationContext context: Context
) : SimInfoProvider {
    private val telecomManager =
        context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
    private val subscriptionManager =
        context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
    private val telephonyManager =
        context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    @SuppressLint("MissingPermission")
    override fun getSimsInfo(): List<SimInfo> {
        val handles = runCatching { telecomManager.callCapablePhoneAccounts }
            .getOrDefault(emptyList())

        return handles.mapIndexedNotNull { index, handle ->
            val account = runCatching { telecomManager.getPhoneAccount(handle) }.getOrNull()
                ?: return@mapIndexedNotNull null
            if (!account.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION)) {
                return@mapIndexedNotNull null
            }

            val subscriptionId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                runCatching { telephonyManager.getSubscriptionId(handle) }
                    .getOrDefault(SubscriptionManager.INVALID_SUBSCRIPTION_ID)
            } else {
                handle.id.toIntOrNull() ?: SubscriptionManager.INVALID_SUBSCRIPTION_ID
            }
            val info = if (subscriptionId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                runCatching { subscriptionManager.getActiveSubscriptionInfo(subscriptionId) }
                    .getOrNull()
            } else {
                null
            }

            SimInfo(
                accountId = handle.id,
                simSlotIndex = info?.simSlotIndex ?: index,
                displayName = info?.displayName?.toString()
                    ?.takeIf(String::isNotBlank)
                    ?: account.label?.toString()?.takeIf(String::isNotBlank),
            )
        }
    }
}
