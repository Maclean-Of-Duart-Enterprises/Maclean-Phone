package com.macleanofduartenterprises.phone.ui.home.contacts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil3.compose.AsyncImage
import com.macleanofduartenterprises.phone.crm.CRM_STAGES
import com.macleanofduartenterprises.phone.crm.ContactStorage
import com.macleanofduartenterprises.phone.crm.ContactStorageOption
import com.macleanofduartenterprises.phone.crm.CrmContact
import com.macleanofduartenterprises.phone.crm.CrmCustomField
import com.macleanofduartenterprises.phone.crm.CrmFieldType
import com.macleanofduartenterprises.phone.crm.CrmGroup

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CrmContactEditor(
    original: CrmContact,
    groups: List<CrmGroup>,
    storageOptions: List<ContactStorageOption>,
    working: Boolean,
    onPickPhoto: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (CrmContact) -> Unit,
) {
    var draft by remember(original) { mutableStateOf(original) }
    val fields = remember(original) { original.customFields.toMutableStateList() }
    var storageMenu by remember { mutableStateOf(false) }
    var stageMenu by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = { if (!working) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(if (original.systemOnly || original.id == 0L) "Add CRM contact" else "Edit CRM contact")
                        },
                        navigationIcon = {
                            IconButton(enabled = !working, onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "Close editor")
                            }
                        },
                        actions = {
                            if (working) {
                                CircularProgressIndicator(
                                    modifier = Modifier.padding(end = 18.dp).size(24.dp),
                                    strokeWidth = 2.dp,
                                )
                            } else {
                                TextButton(
                                    enabled = draft.displayName != "Unnamed contact" ||
                                        fields.any { it.value.isNotBlank() },
                                    onClick = {
                                        onSave(
                                            draft.copy(
                                                customFields = fields.mapIndexed { index, field ->
                                                    field.copy(position = index)
                                                },
                                            ),
                                        )
                                    },
                                ) { Text("Save") }
                            }
                        },
                    )
                },
            ) { padding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            ContactPhoto(
                                photoUri = draft.photoUri,
                                initials = draft.displayName
                                    .split(Regex("\\s+"))
                                    .filter(String::isNotBlank)
                                    .take(2)
                                    .joinToString("") { it.take(1) }
                                    .uppercase(),
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(onClick = onPickPhoto) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                    Text(" Choose photo")
                                }
                                if (draft.photoUri != null) {
                                    TextButton(onClick = { draft = draft.copy(photoUri = null) }) {
                                        Text("Remove photo")
                                    }
                                }
                            }
                        }
                    }

                    item { SectionTitle("Name") }
                    item {
                        LabeledField("First name", draft.firstName) {
                            draft = draft.copy(firstName = it)
                        }
                    }
                    item {
                        LabeledField("Middle name", draft.middleName) {
                            draft = draft.copy(middleName = it)
                        }
                    }
                    item {
                        LabeledField("Last name", draft.lastName) {
                            draft = draft.copy(lastName = it)
                        }
                    }
                    item {
                        LabeledField("Nickname", draft.nickname) {
                            draft = draft.copy(nickname = it)
                        }
                    }

                    item { SectionTitle("Storage") }
                    item {
                        Box {
                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { storageMenu = true },
                            ) {
                                Text(draft.storage.label)
                            }
                            DropdownMenu(
                                expanded = storageMenu,
                                onDismissRequest = { storageMenu = false },
                            ) {
                                storageOptions.ifEmpty {
                                    listOf(
                                        ContactStorageOption(ContactStorage.APP, detail = "Stored in Maclean Phone."),
                                        ContactStorageOption(ContactStorage.PHONE, detail = "Stored in Android contacts."),
                                        ContactStorageOption(ContactStorage.SIM, false, "SIM support is unavailable."),
                                    )
                                }.forEach { option ->
                                    DropdownMenuItem(
                                        enabled = option.enabled,
                                        text = {
                                            Column {
                                                Text(option.storage.label)
                                                Text(
                                                    option.detail,
                                                    style = MaterialTheme.typography.bodySmall,
                                                )
                                            }
                                        },
                                        onClick = {
                                            draft = draft.copy(storage = option.storage)
                                            storageMenu = false
                                        },
                                    )
                                }
                            }
                        }
                    }
                    item {
                        Text(
                            "Custom fields and Maclean groups always remain in the local CRM. " +
                                "SIM cards normally accept only a name and a small number of phone fields.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }

                    item { SectionTitle("Contact fields") }
                    itemsIndexed(
                        items = fields,
                        key = { index, field -> "${field.id}_${field.position}_$index" },
                    ) { index, field ->
                        CustomFieldEditor(
                            field = field,
                            onChange = { fields[index] = it },
                            onRemove = { fields.removeAt(index) },
                        )
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            AddFieldButton("Phone", CrmFieldType.PHONE, Modifier.weight(1f)) {
                                fields += newField(it, fields.size)
                            }
                            AddFieldButton("Email", CrmFieldType.EMAIL, Modifier.weight(1f)) {
                                fields += newField(it, fields.size)
                            }
                            AddFieldButton("Address", CrmFieldType.ADDRESS, Modifier.weight(1f)) {
                                fields += newField(it, fields.size)
                            }
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            AddFieldButton("Fax", CrmFieldType.FAX, Modifier.weight(1f)) {
                                fields += newField(it, fields.size)
                            }
                            AddFieldButton("Website", CrmFieldType.WEBSITE, Modifier.weight(1f)) {
                                fields += newField(it, fields.size)
                            }
                            AddFieldButton("Custom", CrmFieldType.CUSTOM, Modifier.weight(1f)) {
                                fields += newField(it, fields.size)
                            }
                        }
                    }

                    item { SectionTitle("Organization & CRM") }
                    item {
                        LabeledField("Company", draft.company) { draft = draft.copy(company = it) }
                    }
                    item {
                        LabeledField("Household / organization", draft.household) {
                            draft = draft.copy(household = it)
                        }
                    }
                    item {
                        Box {
                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { stageMenu = true },
                            ) { Text("Pipeline: ${draft.stage}") }
                            DropdownMenu(
                                expanded = stageMenu,
                                onDismissRequest = { stageMenu = false },
                            ) {
                                CRM_STAGES.forEach { stage ->
                                    DropdownMenuItem(
                                        text = { Text(stage) },
                                        onClick = {
                                            draft = draft.copy(stage = stage)
                                            stageMenu = false
                                        },
                                    )
                                }
                            }
                        }
                    }
                    item {
                        LabeledField("Service / interest", draft.service) {
                            draft = draft.copy(service = it)
                        }
                    }
                    item {
                        LabeledField("Lead source", draft.source) {
                            draft = draft.copy(source = it)
                        }
                    }
                    item {
                        LabeledField("Assigned representative", draft.representative) {
                            draft = draft.copy(representative = it)
                        }
                    }
                    item {
                        LabeledField("Next action / follow-up", draft.nextAction) {
                            draft = draft.copy(nextAction = it)
                        }
                    }
                    item {
                        LabeledField("Birthday (YYYY-MM-DD)", draft.birthday) {
                            draft = draft.copy(birthday = it)
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = draft.notes,
                            onValueChange = { draft = draft.copy(notes = it) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                            label = { Text("Notes") },
                            minLines = 4,
                        )
                    }

                    item { SectionTitle("Groups") }
                    if (groups.isEmpty()) {
                        item {
                            Text(
                                "Create groups from the Contacts toolbar, then assign them here.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    } else {
                        itemsIndexed(groups, key = { _, group -> group.id }) { _, group ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(
                                    checked = group.id in draft.groupIds,
                                    onCheckedChange = { checked ->
                                        draft = draft.copy(
                                            groupIds = if (checked) {
                                                draft.groupIds + group.id
                                            } else {
                                                draft.groupIds - group.id
                                            },
                                        )
                                    },
                                )
                                Text(group.name)
                            }
                        }
                    }

                    item {
                        Button(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            enabled = !working &&
                                (draft.displayName != "Unnamed contact" || fields.any { it.value.isNotBlank() }),
                            onClick = {
                                onSave(
                                    draft.copy(
                                        customFields = fields.mapIndexed { index, field ->
                                            field.copy(position = index)
                                        },
                                    ),
                                )
                            },
                        ) { Text(if (working) "Saving…" else "Save contact") }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun ContactPhoto(photoUri: String?, initials: String) {
    if (photoUri != null) {
        AsyncImage(
            model = photoUri,
            contentDescription = "Contact photo",
            modifier = Modifier.size(92.dp).clip(CircleShape),
            contentScale = ContentScale.Crop,
        )
    } else {
        Box(
            modifier = Modifier
                .size(92.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(initials.ifBlank { "?" }, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Column {
        Spacer(Modifier.height(8.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
        Divider(Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    onValueChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        singleLine = true,
    )
}

@Composable
private fun CustomFieldEditor(
    field: CrmCustomField,
    onChange: (CrmCustomField) -> Unit,
    onRemove: () -> Unit,
) {
    var typeMenu by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        tonalElevation = 2.dp,
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(onClick = { typeMenu = true }) { Text(field.type.label) }
                    DropdownMenu(
                        expanded = typeMenu,
                        onDismissRequest = { typeMenu = false },
                    ) {
                        CrmFieldType.entries.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.label) },
                                onClick = {
                                    onChange(field.copy(type = type))
                                    typeMenu = false
                                },
                            )
                        }
                    }
                }
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Remove field")
                }
            }
            LabeledField("Field label", field.label, onValueChange = {
                onChange(field.copy(label = it))
            })
            if (field.type == CrmFieldType.PHONE || field.type == CrmFieldType.FAX) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = field.countryCode,
                        onValueChange = { onChange(field.copy(countryCode = it)) },
                        modifier = Modifier.weight(0.34f),
                        label = { Text("Dial code") },
                        placeholder = { Text("+1") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = field.value,
                        onValueChange = { onChange(field.copy(value = it)) },
                        modifier = Modifier.weight(0.66f),
                        label = { Text(field.type.label) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                    )
                }
            } else {
                LabeledField(
                    label = field.type.label,
                    value = field.value,
                    keyboardType = when (field.type) {
                        CrmFieldType.EMAIL -> KeyboardType.Email
                        CrmFieldType.WEBSITE -> KeyboardType.Uri
                        else -> KeyboardType.Text
                    },
                    onValueChange = { onChange(field.copy(value = it)) },
                )
            }
        }
    }
}

@Composable
private fun AddFieldButton(
    label: String,
    type: CrmFieldType,
    modifier: Modifier = Modifier,
    onAdd: (CrmFieldType) -> Unit,
) {
    OutlinedButton(modifier = modifier, onClick = { onAdd(type) }) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
        Text(label, maxLines = 1)
    }
}

private fun newField(type: CrmFieldType, position: Int): CrmCustomField = CrmCustomField(
    type = type,
    label = when (type) {
        CrmFieldType.PHONE -> "Mobile"
        CrmFieldType.EMAIL -> "Email"
        CrmFieldType.ADDRESS -> "Mailing address"
        CrmFieldType.FAX -> "Work fax"
        CrmFieldType.WEBSITE -> "Website"
        CrmFieldType.CUSTOM -> "Custom field"
    },
    position = position,
)
