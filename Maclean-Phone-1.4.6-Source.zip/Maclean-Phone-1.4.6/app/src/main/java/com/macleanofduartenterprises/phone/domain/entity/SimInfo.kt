package com.macleanofduartenterprises.phone.domain.entity

data class SimInfo(
    val accountId: String,
    val simSlotIndex: Int,
    val displayName: String?
)