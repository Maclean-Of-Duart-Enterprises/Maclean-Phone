package com.macleanofduartenterprises.phone.ui.home.searchbar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.macleanofduartenterprises.phone.data.ContactsSearchPagingSource
import com.macleanofduartenterprises.phone.domain.DtmfToneGenerator
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.repo.CallLogRepository
import com.macleanofduartenterprises.phone.domain.repo.ContactRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import javax.inject.Inject

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val contactRepository: ContactRepository,
    private val callLogRepository: CallLogRepository,
    private val dtmfToneGenerator: DtmfToneGenerator
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
    val contacts: Flow<PagingData<Contact>> =
        query
            .debounce(300) // prevent excessive queries
            .distinctUntilChanged()
            .flatMapLatest { q ->
                Pager(
                    config = PagingConfig(
                        pageSize = ContactsSearchPagingSource.PAGE_SIZE,
                        enablePlaceholders = false
                    )
                ) {
                    ContactsSearchPagingSource(
                        contactRepository = contactRepository,
                        callLogRepository = callLogRepository,
                        query = q
                    )
                }.flow
            }
            .cachedIn(viewModelScope)

    fun onSearchQueryChanged(query: String) {
        _query.value = query
    }

    fun startTone(char: Char) {
        dtmfToneGenerator.startTone(char)
    }

    fun stopTone() {
        dtmfToneGenerator.stopTone()
    }

}
