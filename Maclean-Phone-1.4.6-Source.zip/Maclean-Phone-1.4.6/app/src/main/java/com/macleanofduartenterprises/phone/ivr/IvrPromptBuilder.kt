package com.macleanofduartenterprises.phone.ivr

object IvrPromptBuilder {
    fun languageEnglish(config: IvrConfig): String =
        join(config.englishGreeting, "Press 1 for English.")

    fun languageRussian(config: IvrConfig): String =
        join(config.russianGreeting, "Для русского языка нажмите 2.")

    fun directory(config: IvrConfig, language: IvrLanguage): String {
        val entries = config.directory.sortedBy { it.digit }
        if (entries.isEmpty()) {
            return when (language) {
                IvrLanguage.ENGLISH -> "No directory entries are configured."
                IvrLanguage.RUSSIAN -> "Пункты меню не настроены."
            }
        }

        val choices = entries.map { entry ->
            val label = when (language) {
                IvrLanguage.ENGLISH -> entry.englishLabel
                IvrLanguage.RUSSIAN -> entry.russianLabel
            }
            when (language) {
                IvrLanguage.ENGLISH -> "Press ${spokenDigit(entry.digit, language)} for $label."
                IvrLanguage.RUSSIAN -> "Нажмите ${spokenDigit(entry.digit, language)}, чтобы выбрать $label."
            }
        }

        val repeat = when (language) {
            IvrLanguage.ENGLISH -> "Press star to repeat this menu."
            IvrLanguage.RUSSIAN -> "Чтобы повторить меню, нажмите звёздочку."
        }
        return (choices + repeat).joinToString(" ")
    }

    fun invalid(language: IvrLanguage): String = when (language) {
        IvrLanguage.ENGLISH -> "That selection was not recognized. Please try again."
        IvrLanguage.RUSSIAN -> "Неверный выбор. Пожалуйста, попробуйте ещё раз."
    }

    fun transfer(language: IvrLanguage): String = when (language) {
        IvrLanguage.ENGLISH -> "Please hold while your call is transferred."
        IvrLanguage.RUSSIAN -> "Пожалуйста, подождите. Ваш звонок переводится."
    }

    fun goodbye(language: IvrLanguage): String = when (language) {
        IvrLanguage.ENGLISH -> "We could not complete your selection. Goodbye."
        IvrLanguage.RUSSIAN -> "Не удалось выполнить ваш выбор. До свидания."
    }

    private fun spokenDigit(digit: String, language: IvrLanguage): String {
        if (digit == "#") {
            return if (language == IvrLanguage.ENGLISH) "pound" else "решётку"
        }
        return digit
    }

    private fun join(first: String, second: String): String =
        listOf(first.trim(), second.trim())
            .filter(String::isNotBlank)
            .joinToString(" ")
}
