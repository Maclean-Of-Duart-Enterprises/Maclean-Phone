package com.macleanofduartenterprises.phone.crm

import com.google.i18n.phonenumbers.PhoneNumberUtil
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.charset.Charset
import java.util.Base64
import java.util.Locale

data class ParsedVCard(
    val contact: CrmContact,
    val groupNames: Set<String> = emptySet(),
    val photoBytes: ByteArray? = null,
)

/** Local vCard 2.1/3.0/4.0 importer with no network or account dependency. */
object VCardParser {
    private const val MAX_VCARD_BYTES = 128 * 1024 * 1024
    private const val MAX_PHOTO_BYTES = 6 * 1024 * 1024

    fun parse(input: InputStream): List<ParsedVCard> {
        val bytes = input.readUpTo(MAX_VCARD_BYTES + 1)
        require(bytes.size <= MAX_VCARD_BYTES) { "The VCF file is larger than 128 MB." }
        return parse(bytes.toString(Charsets.UTF_8))
    }

    fun parse(text: String): List<ParsedVCard> {
        val unfolded = unfold(text)
        val cards = mutableListOf<List<String>>()
        var current: MutableList<String>? = null
        unfolded.forEach { line ->
            when {
                line.equals("BEGIN:VCARD", ignoreCase = true) -> current = mutableListOf()
                line.equals("END:VCARD", ignoreCase = true) -> {
                    current?.let(cards::add)
                    current = null
                }
                current != null -> current?.add(line)
            }
        }
        return cards.mapNotNull(::parseCard)
    }

    private fun parseCard(lines: List<String>): ParsedVCard? {
        val properties = lines.mapNotNull(::parseProperty)
        val groupedLabels = properties
            .filter { it.name == "X-ABLABEL" && it.group != null }
            .associate { it.group.orEmpty() to decodeText(it) }

        var firstName = ""
        var middleName = ""
        var lastName = ""
        var nickname = ""
        var household = ""
        var company = ""
        var birthday = ""
        var notes = ""
        var photoUri: String? = null
        var photoBytes: ByteArray? = null
        var formattedName = ""
        var stage = CRM_STAGES.first()
        var service = ""
        var source = ""
        var representative = ""
        var nextAction = ""
        var favorite = false
        val fields = mutableListOf<CrmCustomField>()
        val groups = linkedSetOf<String>()

        properties.forEach { property ->
            when (property.name) {
                "N" -> {
                    val parts = splitEscaped(decodeRawText(property), ';')
                    lastName = parts.getOrNull(0).orEmpty()
                    firstName = parts.getOrNull(1).orEmpty()
                    middleName = parts.getOrNull(2).orEmpty()
                    parts.getOrNull(3)?.takeIf(String::isNotBlank)?.let {
                        fields += custom("Name prefix", it, fields.size)
                    }
                    parts.getOrNull(4)?.takeIf(String::isNotBlank)?.let {
                        fields += custom("Name suffix", it, fields.size)
                    }
                }
                "FN" -> formattedName = decodeText(property)
                "NICKNAME" -> nickname = decodeText(property)
                "ORG" -> {
                    val units = splitEscaped(decodeRawText(property), ';').filter(String::isNotBlank)
                    company = units.firstOrNull().orEmpty()
                    if (units.size > 1) {
                        fields += custom("Department", units.drop(1).joinToString(" / "), fields.size)
                    }
                }
                "TITLE", "ROLE" -> fields += custom(
                    if (property.name == "TITLE") "Job title" else "Role",
                    decodeText(property),
                    fields.size,
                )
                "BDAY" -> birthday = decodeText(property)
                "NOTE" -> notes = listOf(notes, decodeText(property))
                    .filter(String::isNotBlank)
                    .joinToString("\n")
                "TEL" -> {
                    val fullNumber = decodeText(property)
                    val (countryCode, localNumber) = splitCountryCode(fullNumber)
                    val explicitCountry = property.parameters["X-MACLEAN-COUNTRY-CODE"]
                        ?.firstOrNull().orEmpty()
                    fields += CrmCustomField(
                        type = if (property.types.any { it.contains("FAX") }) {
                            CrmFieldType.FAX
                        } else {
                            CrmFieldType.PHONE
                        },
                        label = decodeMacleanLabel(property).ifBlank {
                            groupedLabels[property.group]
                            ?.cleanAppleLabel()
                            ?: property.types.toFieldLabel(
                                fallback = if (property.types.any { it.contains("FAX") }) "Fax" else "Phone",
                            )
                        },
                        value = localNumber,
                        countryCode = explicitCountry.ifBlank { countryCode },
                        position = fields.size,
                    )
                }
                "EMAIL" -> fields += CrmCustomField(
                    type = CrmFieldType.EMAIL,
                    label = decodeMacleanLabel(property).ifBlank {
                        groupedLabels[property.group]?.cleanAppleLabel()
                            ?: property.types.toFieldLabel("Email")
                    },
                    value = decodeText(property),
                    position = fields.size,
                )
                "ADR" -> {
                    val address = splitEscaped(decodeRawText(property), ';')
                        .filter(String::isNotBlank)
                        .joinToString(", ")
                    fields += CrmCustomField(
                        type = CrmFieldType.ADDRESS,
                        label = decodeMacleanLabel(property).ifBlank {
                            groupedLabels[property.group]?.cleanAppleLabel()
                                ?: property.types.toFieldLabel("Mailing address")
                        },
                        value = address,
                        position = fields.size,
                    )
                }
                "URL" -> fields += CrmCustomField(
                    type = CrmFieldType.WEBSITE,
                    label = decodeMacleanLabel(property).ifBlank {
                        groupedLabels[property.group]?.cleanAppleLabel()
                            ?: property.types.toFieldLabel("Website")
                    },
                    value = decodeText(property),
                    position = fields.size,
                )
                "CATEGORIES" -> splitEscaped(decodeRawText(property), ',')
                    .map(String::trim)
                    .filter(String::isNotEmpty)
                    .forEach(groups::add)
                "X-MACLEAN-HOUSEHOLD" -> household = decodeText(property)
                "X-MACLEAN-STAGE" -> stage = decodeText(property).ifBlank { CRM_STAGES.first() }
                "X-MACLEAN-SERVICE" -> service = decodeText(property)
                "X-MACLEAN-SOURCE" -> source = decodeText(property)
                "X-MACLEAN-REPRESENTATIVE" -> representative = decodeText(property)
                "X-MACLEAN-NEXT-ACTION" -> nextAction = decodeText(property)
                "X-MACLEAN-FAVORITE" -> favorite = decodeText(property).equals("true", true) ||
                    decodeText(property) == "1"
                "X-MACLEAN-CUSTOM" -> {
                    val value = decodeText(property)
                    if (value.isNotBlank()) {
                        fields += custom(
                            decodeMacleanLabel(property).ifBlank { "Custom field" },
                            value,
                            fields.size,
                        )
                    }
                }
                "PHOTO", "LOGO" -> {
                    val value = property.rawValue.trim()
                    if (property.isBase64 || !value.contains("://")) {
                        photoBytes = runCatching {
                            Base64.getMimeDecoder().decode(value)
                        }.getOrNull()?.takeIf { it.size <= MAX_PHOTO_BYTES }
                    } else {
                        photoUri = decodeText(property).takeIf {
                            it.startsWith("content:") || it.startsWith("file:")
                        }
                    }
                }
                else -> if (
                    property.name.startsWith("X-") &&
                    property.name !in IGNORED_EXTENSIONS &&
                    property.name != "X-ABLABEL"
                ) {
                    val value = decodeText(property)
                    if (value.isNotBlank()) {
                        fields += custom(
                            property.name.removePrefix("X-").replace('-', ' ').titleCase(),
                            value,
                            fields.size,
                        )
                    }
                }
            }
        }

        if (firstName.isBlank() && middleName.isBlank() && lastName.isBlank() && formattedName.isNotBlank()) {
            val tokens = formattedName.trim().split(Regex("\\s+"))
            if (tokens.size == 1) {
                firstName = tokens.first()
            } else {
                firstName = tokens.first()
                lastName = tokens.drop(1).joinToString(" ")
            }
        }
        if (fields.none { it.type == CrmFieldType.PHONE } &&
            fields.none { it.type == CrmFieldType.EMAIL } &&
            firstName.isBlank() && lastName.isBlank() && company.isBlank()
        ) {
            return null
        }

        return ParsedVCard(
            contact = CrmContact(
                firstName = firstName,
                middleName = middleName,
                lastName = lastName,
                nickname = nickname,
                household = household,
                company = company,
                birthday = birthday,
                notes = notes,
                stage = stage,
                service = service,
                source = source,
                representative = representative,
                nextAction = nextAction,
                favorite = favorite,
                photoUri = photoUri,
                customFields = fields.ifEmpty {
                    listOf(CrmCustomField(type = CrmFieldType.PHONE, label = "Mobile"))
                },
            ),
            groupNames = groups,
            photoBytes = photoBytes,
        )
    }

    private data class Property(
        val group: String?,
        val name: String,
        val parameters: Map<String, List<String>>,
        val rawValue: String,
    ) {
        val types: List<String>
            get() = parameters["TYPE"].orEmpty().map { it.uppercase(Locale.ROOT) }
        val isBase64: Boolean
            get() = parameters["ENCODING"].orEmpty().any {
                it.equals("B", true) || it.equals("BASE64", true)
            }
    }

    private fun parseProperty(line: String): Property? {
        val colon = firstUnescapedIndex(line, ':')
        if (colon <= 0) return null
        val header = line.substring(0, colon)
        val rawValue = line.substring(colon + 1)
        val headerParts = header.split(';')
        val groupedName = headerParts.first().trim()
        val dot = groupedName.lastIndexOf('.')
        val group = groupedName.takeIf { dot > 0 }?.substring(0, dot)
        val name = groupedName.substring(dot + 1).uppercase(Locale.ROOT)
        val parameters = mutableMapOf<String, MutableList<String>>()
        headerParts.drop(1).forEach { parameter ->
            val equals = parameter.indexOf('=')
            val key = if (equals > 0) parameter.substring(0, equals) else "TYPE"
            val values = if (equals > 0) parameter.substring(equals + 1) else parameter
            parameters.getOrPut(key.uppercase(Locale.ROOT), ::mutableListOf)
                .addAll(values.split(',').map { it.trim().trim('"') })
        }
        return Property(group, name, parameters, rawValue)
    }

    private fun decodeText(property: Property): String {
        return unescape(decodeRawText(property))
    }

    private fun decodeRawText(property: Property): String {
        return if (property.parameters["ENCODING"].orEmpty().any {
                it.equals("QUOTED-PRINTABLE", true)
            }
        ) {
            val charsetName = property.parameters["CHARSET"]?.firstOrNull() ?: "UTF-8"
            val charset = runCatching { Charset.forName(charsetName) }.getOrDefault(Charsets.UTF_8)
            decodeQuotedPrintable(property.rawValue).toString(charset)
        } else {
            property.rawValue
        }
    }

    private fun unfold(text: String): List<String> {
        val physicalLines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val result = mutableListOf<String>()
        physicalLines.forEach { rawLine ->
            when {
                result.isNotEmpty() &&
                    result.last().endsWith("=") &&
                    result.last().substringBefore(':').contains(
                        "ENCODING=QUOTED-PRINTABLE",
                        ignoreCase = true,
                    ) -> {
                    result[result.lastIndex] = result.last().dropLast(1) + rawLine.trimStart()
                }
                result.isNotEmpty() && (rawLine.startsWith(' ') || rawLine.startsWith('\t')) -> {
                    result[result.lastIndex] += rawLine.drop(1)
                }
                else -> result += rawLine
            }
        }
        return result
    }

    private fun decodeQuotedPrintable(value: String): ByteArray {
        val output = ArrayList<Byte>(value.length)
        var index = 0
        while (index < value.length) {
            if (value[index] == '=' && index + 2 < value.length) {
                val hex = value.substring(index + 1, index + 3)
                val byte = hex.toIntOrNull(16)
                if (byte != null) {
                    output += byte.toByte()
                    index += 3
                    continue
                }
            }
            value[index].toString().toByteArray(Charsets.UTF_8).forEach(output::add)
            index++
        }
        return output.toByteArray()
    }

    private fun splitCountryCode(number: String): Pair<String, String> {
        val trimmed = number.trim()
        if (!trimmed.startsWith('+')) return "" to trimmed
        return runCatching {
            val parsed = PhoneNumberUtil.getInstance().parse(trimmed, "ZZ")
            val code = "+${parsed.countryCode}"
            code to trimmed.removePrefix(code).trim()
        }.getOrDefault("" to trimmed)
    }

    private fun custom(label: String, value: String, position: Int) = CrmCustomField(
        type = CrmFieldType.CUSTOM,
        label = label,
        value = value,
        position = position,
    )

    private fun firstUnescapedIndex(value: String, char: Char): Int {
        var escaped = false
        value.forEachIndexed { index, current ->
            if (current == char && !escaped) return index
            escaped = current == '\\' && !escaped
            if (current != '\\') escaped = false
        }
        return -1
    }

    private fun splitEscaped(value: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var escaped = false
        value.forEach { char ->
            when {
                escaped -> {
                    if (char == delimiter || char == '\\') {
                        current.append(char)
                    } else {
                        current.append('\\').append(char)
                    }
                    escaped = false
                }
                char == '\\' -> escaped = true
                char == delimiter -> {
                    result += unescape(current.toString())
                    current.clear()
                }
                else -> current.append(char)
            }
        }
        if (escaped) current.append('\\')
        result += unescape(current.toString())
        return result
    }

    private fun unescape(value: String): String = value
        .replace("\\n", "\n", ignoreCase = true)
        .replace("\\,", ",")
        .replace("\\;", ";")
        .replace("\\\\", "\\")

    private fun List<String>.toFieldLabel(fallback: String): String {
        val useful = firstOrNull {
            it !in setOf("VOICE", "INTERNET", "PREF")
        } ?: return fallback
        return useful.lowercase(Locale.ROOT).replace('-', ' ').titleCase()
    }

    private fun String.cleanAppleLabel(): String =
        removePrefix("_\$_!").removeSuffix("!\$_").ifBlank { "Other" }

    private fun decodeMacleanLabel(property: Property): String {
        property.parameters["X-MACLEAN-LABEL-B64"]?.firstOrNull()?.let { encoded ->
            return runCatching {
                String(Base64.getUrlDecoder().decode(encoded), Charsets.UTF_8)
            }.getOrDefault("")
        }
        return property.parameters["LABEL"]?.firstOrNull().orEmpty()
    }

    private fun String.titleCase(): String =
        lowercase(Locale.ROOT).split(' ').joinToString(" ") { token ->
            token.replaceFirstChar { it.titlecase(Locale.ROOT) }
        }

    private val IGNORED_EXTENSIONS = setOf(
        "X-PHONETIC-FIRST-NAME",
        "X-PHONETIC-MIDDLE-NAME",
        "X-PHONETIC-LAST-NAME",
        "X-ABUID",
        "X-MACLEAN-HOUSEHOLD",
        "X-MACLEAN-STAGE",
        "X-MACLEAN-SERVICE",
        "X-MACLEAN-SOURCE",
        "X-MACLEAN-REPRESENTATIVE",
        "X-MACLEAN-NEXT-ACTION",
        "X-MACLEAN-FAVORITE",
        "X-MACLEAN-CUSTOM",
    )
}

private fun InputStream.readUpTo(maxBytes: Int): ByteArray {
    val output = ByteArrayOutputStream(minOf(maxBytes, 64 * 1024))
    val buffer = ByteArray(16 * 1024)
    var remaining = maxBytes
    while (remaining > 0) {
        val read = read(buffer, 0, minOf(buffer.size, remaining))
        if (read < 0) break
        output.write(buffer, 0, read)
        remaining -= read
    }
    return output.toByteArray()
}
