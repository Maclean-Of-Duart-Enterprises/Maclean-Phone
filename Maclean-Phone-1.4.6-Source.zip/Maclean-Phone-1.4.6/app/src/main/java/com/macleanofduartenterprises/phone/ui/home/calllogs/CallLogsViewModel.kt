package com.macleanofduartenterprises.phone.ui.home.calllogs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import androidx.paging.insertSeparators
import androidx.paging.map
import com.macleanofduartenterprises.phone.data.CallLogsPagingSource
import com.macleanofduartenterprises.phone.domain.entity.CallLogData
import com.macleanofduartenterprises.phone.domain.entity.CallLogFilter
import com.macleanofduartenterprises.phone.domain.repo.CallLogRepository
import com.macleanofduartenterprises.phone.util.isSameDay
import com.macleanofduartenterprises.phone.util.startOfDay
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import java.util.Date


@HiltViewModel
@OptIn(ExperimentalCoroutinesApi::class)
class CallLogsViewModel @Inject constructor(
    private val callLogRepository: CallLogRepository,
) : ViewModel() {
    private val _selectedFilter = MutableStateFlow(CallLogFilter.ALL)
    val selectedFilter: StateFlow<CallLogFilter> = _selectedFilter.asStateFlow()

    val callLogs: Flow<PagingData<CallLogUiModel>> = selectedFilter
        .flatMapLatest { filter ->
            Pager(
                config = PagingConfig(pageSize = CallLogsPagingSource.PAGE_SIZE),
                initialKey = CallLogsPagingSource.FIRST_PAGE
            ) { CallLogsPagingSource(callLogRepository, filter) }.flow
                .map { pagingData ->
                    pagingData.map {
                        CallLogUiModel.Item(it)
                    }.insertSeparators { before, after ->
                        when {
                            after == null -> null
                            before == null -> {
                                CallLogUiModel.Header(after.log.time.startOfDay())
                            }

                            !before.log.time.isSameDay(after.log.time) -> {
                                CallLogUiModel.Header(after.log.time.startOfDay())
                            }

                            else -> null
                        }
                    }
                }
        }.cachedIn(viewModelScope)

    fun selectFilter(filter: CallLogFilter) {
        _selectedFilter.value = filter
    }
}

sealed interface CallLogUiModel {
    data class Header(val date: Date) : CallLogUiModel
    data class Item(val log: CallLogData) : CallLogUiModel
}
