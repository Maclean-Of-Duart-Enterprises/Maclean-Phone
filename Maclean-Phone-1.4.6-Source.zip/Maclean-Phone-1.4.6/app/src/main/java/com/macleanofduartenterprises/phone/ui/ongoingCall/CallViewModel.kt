package com.macleanofduartenterprises.phone.ui.ongoingCall

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.macleanofduartenterprises.phone.domain.entity.Contact
import com.macleanofduartenterprises.phone.domain.CallAction
import com.macleanofduartenterprises.phone.domain.CallOrchestrator
import com.macleanofduartenterprises.phone.domain.repo.ContactRepository
import com.macleanofduartenterprises.phone.ui.extensions.stateInScoped
import com.macleanofduartenterprises.phone.domain.entity.CallState
import com.macleanofduartenterprises.phone.core.CallAudioRouteState
import com.macleanofduartenterprises.phone.core.CallerAssessment
import com.macleanofduartenterprises.phone.core.LlamaCallerAssistant
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.mapLatest
import javax.inject.Inject

/**
 * Created by Muhammad Usman : msusman97@gmail.com on 11/17/2023.
 */

@HiltViewModel
class CallViewModel @Inject constructor(
    private val contactsRepository: ContactRepository,
    private val savedStateHandle: SavedStateHandle,
    private val callOrchestrator: CallOrchestrator,
    private val llamaCallerAssistant: LlamaCallerAssistant,
) : ViewModel() {

    val callState: StateFlow<CallState> = callOrchestrator.callState
    val groupCallState = callOrchestrator.groupCallState

    private val activePhone: StateFlow<String> = combine(
        savedStateHandle.getStateFlow("phone", ""),
        groupCallState,
    ) { launchPhone, group ->
        group.foregroundPhone.ifBlank { launchPhone }.trim()
    }.distinctUntilChanged().stateInScoped("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val contact: StateFlow<ContactWithCompanyName> =
        activePhone
            .mapLatest { number ->
                val normalizedNumber = number.trim()
                if (normalizedNumber.isEmpty()) {
                    return@mapLatest ContactWithCompanyName(Contact.unknown(""), "")
                }

                val realContact = contactsRepository.getContactByPhone(normalizedNumber)
                if (realContact != null) {
                    val companyName = contactsRepository.getCompanyName(realContact.id)
                    ContactWithCompanyName(realContact, companyName)
                } else {
                    ContactWithCompanyName(Contact.unknown(normalizedNumber), "")
                }
            }.stateInScoped(ContactWithCompanyName(Contact.unknown(""), ""))

    val availableAudioRoutes = CallAudioRouteState.availableRoutes
    val selectedAudioRouteId = CallAudioRouteState.selectedRouteId

    @OptIn(ExperimentalCoroutinesApi::class)
    val callerAssessment: StateFlow<CallerAssessment> =
        activePhone
            .mapLatest { number -> llamaCallerAssistant.assess(number) }
            .stateInScoped(CallerAssessment.Unavailable)

    fun onAction(action: CallAction) {
        callOrchestrator.onAction(action)
    }

    fun selectAudioRoute(routeId: String) {
        callOrchestrator.selectAudioRoute(routeId)
    }

}

data class ContactWithCompanyName(
    val contact: Contact,
    val companyName: String?
)
