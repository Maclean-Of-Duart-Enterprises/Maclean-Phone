package com.macleanofduartenterprises.phone.core

import android.content.Context
import com.macleanofduartenterprises.phone.domain.NotificationController
import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo
import com.macleanofduartenterprises.phone.ui.ongoingCall.CallActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

interface CallUiEffects {
    fun showIncoming(phone: String, calledLine: CalledLineInfo)
    fun showOutgoing(phone: String, callingLine: CalledLineInfo)
    fun showOngoing(phone: String, durationSeconds: Int, callingLine: CalledLineInfo)
    fun stopCallUi()
    fun launchCallScreen(phone: String)
    suspend fun showMissedCall(phone: String)
}

@Singleton
class CallUiEffectsHandler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val notificationController: NotificationController
) : CallUiEffects {

    override fun showIncoming(phone: String, calledLine: CalledLineInfo) {
        CallForegroundService.showIncoming(context, phone, calledLine)
    }

    override fun showOutgoing(phone: String, callingLine: CalledLineInfo) {
        CallForegroundService.showOutgoing(context, phone, callingLine)
    }

    override fun showOngoing(phone: String, durationSeconds: Int, callingLine: CalledLineInfo) {
        CallForegroundService.showOngoing(context, phone, durationSeconds, callingLine)
    }

    override fun stopCallUi() {
        CallForegroundService.stop(context)
    }

    override fun launchCallScreen(phone: String) {
        CallActivity.start(context, phone)
    }

    override suspend fun showMissedCall(phone: String) {
        notificationController.showMissedCallNotification(phone)
    }
}
