package com.macleanofduartenterprises.phone.ui.ongoingCall

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.macleanofduartenterprises.phone.App
import com.macleanofduartenterprises.phone.core.LockScreenController
import com.macleanofduartenterprises.phone.core.CallRecordingController
import com.macleanofduartenterprises.phone.core.PhoneSettingsPrefs
import com.macleanofduartenterprises.phone.core.ProxyController
import com.macleanofduartenterprises.phone.domain.RingToneController
import com.macleanofduartenterprises.phone.ui.theme.MacleanPhoneTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class CallActivity : ComponentActivity() {
    private val vm: CallViewModel by viewModels()
    private val recordingController by lazy {
        CallRecordingController(applicationContext)
    }

    @Inject
    lateinit var ringToneController: RingToneController

    private val sensorManager by lazy {
        getSystemService(SensorManager::class.java)
    }
    private var flipTriggered = false
    private val flipListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
            val zAxis = event.values.getOrNull(2) ?: return
            if (zAxis > -5f) {
                flipTriggered = false
                return
            }
            if (
                zAxis < -8f &&
                !flipTriggered &&
                PhoneSettingsPrefs.flipToSilenceEnabled(this@CallActivity) &&
                vm.callState.value.isIncomingCall()
            ) {
                flipTriggered = true
                ringToneController.stepCallRingTone()
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProxyController(this, lifecycle)
        LockScreenController.enable(this)
        setContent {
            val uiState by vm.callState.collectAsStateWithLifecycle()
            val groupCallState by vm.groupCallState.collectAsStateWithLifecycle()
            val contactDetail by vm.contact.collectAsStateWithLifecycle()
            val recordingState by recordingController.state.collectAsStateWithLifecycle()
            val callerAssessment by vm.callerAssessment.collectAsStateWithLifecycle()
            val audioRoutes by vm.availableAudioRoutes.collectAsStateWithLifecycle()
            val selectedAudioRouteId by vm.selectedAudioRouteId.collectAsStateWithLifecycle()
            MacleanPhoneTheme {
                CallScreen(
                    contact = contactDetail,
                    uiState = uiState,
                    groupCallState = groupCallState,
                    callerAssessment = callerAssessment,
                    availableAudioRoutes = audioRoutes,
                    selectedAudioRouteId = selectedAudioRouteId,
                    recordingState = recordingState,
                    onAction = { vm.onAction(it) },
                    onAudioRouteSelected = vm::selectAudioRoute,
                    onManualStartRecording = recordingController::startFromManualControl,
                    onManualStopRecording = recordingController::stopFromManualControl,
                    onCallEnded = recordingController::stopForCallEnd,
                    onFinish = { finishAndRemoveTask() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (PhoneSettingsPrefs.flipToSilenceEnabled(this)) {
            sensorManager
                ?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                ?.let {
                    sensorManager?.registerListener(
                        flipListener,
                        it,
                        SensorManager.SENSOR_DELAY_NORMAL,
                    )
                }
        }
    }

    override fun onPause() {
        sensorManager?.unregisterListener(flipListener)
        super.onPause()
    }

    override fun onDestroy() {
        if (isFinishing) recordingController.stopForCallEnd()
        super.onDestroy()
    }

    companion object {

        fun start(context: Context, phone: String) {
            val intent = Intent(context, CallActivity::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.putExtra("phone", phone)
            context.startActivity(intent)

        }
    }
}
