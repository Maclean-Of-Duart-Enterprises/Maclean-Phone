package com.macleanofduartenterprises.phone.ui.home

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class HomeRoutesTest {
    @Test
    fun `bottom navigation contains contacts left of recents and no favorites page`() {
        val routes = homeRoutes()

        assertEquals(listOf("Contacts", "Recents"), routes.map(BottomNavMenu::label))
        assertEquals(listOf(ContactsKey, RecentsKey), routes.map(BottomNavMenu::navKey))
        assertFalse(routes.any { it.navKey == FavouritesKey })
    }
}
