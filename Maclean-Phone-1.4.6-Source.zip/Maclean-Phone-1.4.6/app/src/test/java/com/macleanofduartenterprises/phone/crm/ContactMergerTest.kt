package com.macleanofduartenterprises.phone.crm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactMergerTest {
    @Test
    fun `merge preserves unique fields notes groups photo and favorite`() {
        val first = CrmContact(
            id = 1,
            firstName = "José",
            lastName = "García",
            notes = "First note",
            photoUri = "file:/photo",
            groupIds = setOf(1),
            favorite = false,
            customFields = listOf(
                CrmCustomField(type = CrmFieldType.PHONE, label = "Mobile", value = "555 123 4567", countryCode = "+1"),
                CrmCustomField(type = CrmFieldType.EMAIL, label = "Work", value = "JOSE@example.com"),
            ),
        )
        val second = CrmContact(
            id = 2,
            firstName = "José",
            company = "Empresa",
            notes = "Second note",
            groupIds = setOf(2),
            favorite = true,
            customFields = listOf(
                CrmCustomField(type = CrmFieldType.PHONE, label = "Other", value = "+1 (555) 123-4567"),
                CrmCustomField(type = CrmFieldType.EMAIL, label = "Other", value = "jose@example.com"),
                CrmCustomField(type = CrmFieldType.WEBSITE, label = "Site", value = "https://example.com"),
            ),
        )
        val plan = ContactMerger.merge(listOf(first, second))
        assertEquals(1, plan.merged.id)
        assertEquals("Empresa", plan.merged.company)
        assertEquals("First note\nSecond note", plan.merged.notes)
        assertEquals(setOf(1L, 2L), plan.merged.groupIds)
        assertEquals("file:/photo", plan.merged.photoUri)
        assertTrue(plan.merged.favorite)
        assertEquals(3, plan.merged.customFields.size)
        assertEquals(listOf(second), plan.sourcesToDelete)
    }

    @Test
    fun `similar names alone are not duplicate candidates`() {
        val contacts = listOf(
            CrmContact(id = 1, firstName = "Jon", lastName = "Smith"),
            CrmContact(id = 2, firstName = "John", lastName = "Smith"),
        )
        assertTrue(ContactMerger.findSuspectedDuplicates(contacts).isEmpty())
    }

    @Test
    fun `exact normalized email and phone identify candidates without auto merge`() {
        val contacts = listOf(
            CrmContact(id = 1, firstName = "A", customFields = listOf(
                CrmCustomField(type = CrmFieldType.EMAIL, value = "CASE@EXAMPLE.COM"),
                CrmCustomField(type = CrmFieldType.PHONE, value = "+44 7700 900123"),
            )),
            CrmContact(id = 2, firstName = "B", customFields = listOf(
                CrmCustomField(type = CrmFieldType.EMAIL, value = "case@example.com"),
                CrmCustomField(type = CrmFieldType.PHONE, value = "07700900123"),
            )),
        )
        val match = ContactMerger.findSuspectedDuplicates(contacts).single()
        assertEquals(2, match.contacts.size)
        assertTrue("same email" in match.reasons)
        assertFalse(match.contacts[0] === match.contacts[1])
    }
}
