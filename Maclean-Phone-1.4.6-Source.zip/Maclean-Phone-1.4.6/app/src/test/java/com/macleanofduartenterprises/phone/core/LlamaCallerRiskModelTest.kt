package com.macleanofduartenterprises.phone.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LlamaCallerRiskModelTest {
    @Test
    fun blockedNumberIsAlwaysHighConfidence() {
        val result = LlamaCallerRiskModel.assess(
            CallerSignals(isBlocked = true, digitCount = 10)
        )

        assertEquals(CallerCategory.BLOCKED, result.category)
        assertEquals(100, result.riskScore)
    }

    @Test
    fun savedContactIsTrusted() {
        val result = LlamaCallerRiskModel.assess(
            CallerSignals(isSavedContact = true, recentMissedCallCount = 5, digitCount = 10)
        )

        assertEquals(CallerCategory.KNOWN, result.category)
        assertEquals(0, result.riskScore)
        assertFalse(result.shouldSilence)
    }

    @Test
    fun repeatedAnonymousCallerCanBeSilenced() {
        val result = LlamaCallerRiskModel.assess(
            CallerSignals(isAnonymous = true, recentMissedCallCount = 3)
        )

        assertEquals(CallerCategory.LIKELY_SPAM, result.category)
        assertTrue(result.shouldSilence)
    }

    @Test
    fun unknownNumberIsNotAutomaticallySilenced() {
        val result = LlamaCallerRiskModel.assess(CallerSignals(digitCount = 10))

        assertEquals(CallerCategory.UNKNOWN, result.category)
        assertFalse(result.shouldSilence)
    }
}
