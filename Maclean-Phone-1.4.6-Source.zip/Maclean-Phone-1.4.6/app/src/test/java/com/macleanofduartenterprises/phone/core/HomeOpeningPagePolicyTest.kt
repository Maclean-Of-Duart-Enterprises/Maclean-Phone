package com.macleanofduartenterprises.phone.core

import org.junit.Assert.assertEquals
import org.junit.Test

class HomeOpeningPagePolicyTest {
    @Test
    fun `contacts preference always opens contacts`() {
        assertEquals(
            PhoneSettingsPrefs.HomeTab.CONTACTS,
            PhoneSettingsPrefs.resolveOpeningHomeTab(
                PhoneSettingsPrefs.HomeOpeningPage.CONTACTS,
                PhoneSettingsPrefs.HomeTab.RECENTS,
            ),
        )
    }

    @Test
    fun `recents preference always opens recents`() {
        assertEquals(
            PhoneSettingsPrefs.HomeTab.RECENTS,
            PhoneSettingsPrefs.resolveOpeningHomeTab(
                PhoneSettingsPrefs.HomeOpeningPage.RECENTS,
                PhoneSettingsPrefs.HomeTab.CONTACTS,
            ),
        )
    }

    @Test
    fun `last used preference restores either home tab`() {
        PhoneSettingsPrefs.HomeTab.entries.forEach { lastUsed ->
            assertEquals(
                lastUsed,
                PhoneSettingsPrefs.resolveOpeningHomeTab(
                    PhoneSettingsPrefs.HomeOpeningPage.LAST_USED,
                    lastUsed,
                ),
            )
        }
    }
}
