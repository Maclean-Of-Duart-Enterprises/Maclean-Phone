package com.macleanofduartenterprises.phone.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AppearancePreferencesTest {
    @Test
    fun parsesRgbHexWithOpaqueAlpha() {
        assertEquals(0xFF286C4D.toInt(), AppearancePreferences.parseHexColor("#286C4D"))
    }

    @Test
    fun rejectsMalformedHex() {
        assertNull(AppearancePreferences.parseHexColor("green"))
        assertNull(AppearancePreferences.parseHexColor("#12345"))
    }

    @Test
    fun opacitySupportsFullOneToOneHundredPercentRange() {
        assertEquals(0.01f, AppearancePreferences.normalizePanelOpacity(0f))
        assertEquals(0.50f, AppearancePreferences.normalizePanelOpacity(0.50f))
        assertEquals(1f, AppearancePreferences.normalizePanelOpacity(2f))
    }

    @Test
    fun textWindowOpacitySupportsFullOneToOneHundredPercentRange() {
        assertEquals(0.01f, AppearancePreferences.normalizeTextWindowOpacity(0f))
        assertEquals(0.50f, AppearancePreferences.normalizeTextWindowOpacity(0.50f))
        assertEquals(1f, AppearancePreferences.normalizeTextWindowOpacity(2f))
    }

    @Test
    fun textWindowCornersSupportSquareThroughRounded() {
        assertEquals(0f, AppearancePreferences.normalizeTextWindowCornerRadius(-5f))
        assertEquals(12f, AppearancePreferences.normalizeTextWindowCornerRadius(12f))
        assertEquals(32f, AppearancePreferences.normalizeTextWindowCornerRadius(50f))
    }
}
