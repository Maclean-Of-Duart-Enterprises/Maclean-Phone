package com.macleanofduartenterprises.phone.crm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VCardParserTest {
    @Test
    fun importsMultilingualNamesEmojiInternationalNumbersAndGroups() {
        val cards = VCardParser.parse(
            """
            BEGIN:VCARD
            VERSION:3.0
            N:Петров;José 😀;Александрович;;
            FN:José 😀 Александрович Петров
            NICKNAME:Хосе 🛠️
            ORG:Compañía Ñ;Operaciones
            TEL;TYPE=CELL:+34600111222
            TEL;TYPE=FAX,WORK:+74951234567
            EMAIL;TYPE=WORK:jose@example.com
            ADR;TYPE=HOME:;;Calle Mayor 1;Madrid;;28001;España
            URL:https://example.com/😀
            BDAY:1980-05-02
            NOTE:Cliente español y русский контакт 😀
            CATEGORIES:Clientes,Друзья,⭐ VIP
            X-FAVORITE-COLOR:Azul 💙
            END:VCARD
            """.trimIndent(),
        )

        assertEquals(1, cards.size)
        val card = cards.single()
        assertEquals("José 😀", card.contact.firstName)
        assertEquals("Александрович", card.contact.middleName)
        assertEquals("Петров", card.contact.lastName)
        assertEquals("Хосе 🛠️", card.contact.nickname)
        assertEquals("Compañía Ñ", card.contact.company)
        assertEquals(setOf("Clientes", "Друзья", "⭐ VIP"), card.groupNames)
        val phone = card.contact.customFields.first { it.type == CrmFieldType.PHONE }
        assertEquals("+34", phone.countryCode)
        assertEquals("600111222", phone.value)
        assertTrue(card.contact.customFields.any {
            it.type == CrmFieldType.FAX && it.completeValue() == "+74951234567"
        })
        assertTrue(card.contact.customFields.any {
            it.type == CrmFieldType.CUSTOM && it.value == "Azul 💙"
        })
    }

    @Test
    fun decodesQuotedPrintableAndFoldedLines() {
        val cards = VCardParser.parse(
            """
            BEGIN:VCARD
            VERSION:2.1
            N;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:Mu=C3=B1oz;Mar=C3=ADa;;;
            NOTE;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:L=C3=ADnea=20uno=0A=
             L=C3=ADnea=20dos
            TEL:+14155550100
            END:VCARD
            """.trimIndent(),
        )

        assertEquals("María", cards.single().contact.firstName)
        assertEquals("Muñoz", cards.single().contact.lastName)
        assertEquals("Línea uno\nLínea dos", cards.single().contact.notes)
    }

    @Test
    fun importsMoreThanOneCardAndKeepsArbitraryExtensionFields() {
        val text = (1..25).joinToString("\n") { index ->
            """
            BEGIN:VCARD
            VERSION:4.0
            FN:Contact $index 😀
            TEL:+1202555${index.toString().padStart(4, '0')}
            X-CUSTOM-$index:Value $index 🚀
            END:VCARD
            """.trimIndent()
        }
        val cards = VCardParser.parse(text)

        assertEquals(25, cards.size)
        assertEquals("Value 25 🚀", cards.last().contact.customFields.last().value)
    }
}
