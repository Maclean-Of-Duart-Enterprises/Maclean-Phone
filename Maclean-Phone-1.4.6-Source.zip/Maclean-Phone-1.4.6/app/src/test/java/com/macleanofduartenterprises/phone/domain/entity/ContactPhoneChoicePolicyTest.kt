package com.macleanofduartenterprises.phone.domain.entity

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactPhoneChoicePolicyTest {
    @Test
    fun `formatting duplicates are removed while distinct destinations remain`() {
        val choices = ContactPhoneChoicePolicy.choices(
            primaryPhone = "+1 (717) 555-0101",
            phones = listOf(
                ContactPhone("+1 717 555 0101", "Mobile"),
                ContactPhone("+1 717 555 0199", "Work"),
            ),
        )
        assertEquals(2, choices.size)
        assertEquals(setOf("17175550101", "17175550199"), choices.map {
            ContactPhoneChoicePolicy.normalizedKey(it.number)
        }.toSet())
    }

    @Test
    fun `primary number is first without losing its useful label`() {
        val choices = ContactPhoneChoicePolicy.choices(
            primaryPhone = "555-0200",
            phones = listOf(
                ContactPhone("555-0100", "Home"),
                ContactPhone("555 0200", "Работа"),
            ),
        )
        assertTrue(choices.first().isPrimary)
        assertEquals("Работа", choices.first().label)
    }

    @Test
    fun `blank numbers are ignored and emoji labels are preserved`() {
        val choices = ContactPhoneChoicePolicy.choices(
            primaryPhone = "",
            phones = listOf(
                ContactPhone("", "Blank"),
                ContactPhone("+34 600 123 456", "Familia 🏠"),
            ),
        )
        assertEquals(1, choices.size)
        assertEquals("Familia 🏠", choices.single().label)
    }
}
