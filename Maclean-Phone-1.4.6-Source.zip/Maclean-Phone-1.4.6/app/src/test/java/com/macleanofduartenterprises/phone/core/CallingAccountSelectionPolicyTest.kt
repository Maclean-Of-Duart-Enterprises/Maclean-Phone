package com.macleanofduartenterprises.phone.core

import android.content.ComponentName
import android.telecom.PhoneAccountHandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CallingAccountSelectionPolicyTest {
    @Test
    fun `stable key includes provider so equal handle IDs do not collide`() {
        val first = handle("carrier.one", "shared")
        val second = handle("voice.two", "shared")
        assertTrue(CallingAccountCatalog.accountKey(first) != CallingAccountCatalog.accountKey(second))
    }

    @Test
    fun `specific account selects only the exact registered provider`() {
        val first = account("carrier.one", "shared")
        val second = account("voice.two", "shared")
        val result = CallingAccountSelectionPolicy.select(
            CallingAccountPreferences.Snapshot(
                CallingAccountPreferences.Mode.SPECIFIC_ACCOUNT,
                second.key,
            ),
            listOf(first, second),
        )
        assertEquals(second, (result as CallingAccountSelection.Specific).account)
    }

    @Test
    fun `missing remembered account requires an explicit chooser`() {
        val result = CallingAccountSelectionPolicy.select(
            CallingAccountPreferences.Snapshot(
                CallingAccountPreferences.Mode.SPECIFIC_ACCOUNT,
                "missing",
            ),
            listOf(account("carrier.one", "one")),
        )
        assertEquals(CallingAccountSelection.ShowChooser, result)
    }

    @Test
    fun `legacy selected SIM ID migrates to collision safe account key`() {
        val registered = account("carrier.one", "legacy-id")
        val migrated = CallingAccountPreferences.migrate(
            modeName = "SPECIFIC_SIM",
            storedAccount = "legacy-id",
            accounts = listOf(registered),
        )
        assertEquals(CallingAccountPreferences.Mode.SPECIFIC_ACCOUNT, migrated.mode)
        assertEquals(registered.key, migrated.accountKey)
    }

    private fun account(packageName: String, id: String): CallingAccountInfo {
        val handle = handle(packageName, id)
        return CallingAccountInfo(
            key = CallingAccountCatalog.accountKey(handle),
            handle = handle,
            label = packageName,
            applicationLabel = packageName,
            fromNumber = "+15550100",
            kind = CallingAccountKind.CELLULAR,
            supportsTelephoneNumbers = true,
        )
    }

    private fun handle(packageName: String, id: String): PhoneAccountHandle =
        PhoneAccountHandle(ComponentName(packageName, "$packageName.CallService"), id)
}
