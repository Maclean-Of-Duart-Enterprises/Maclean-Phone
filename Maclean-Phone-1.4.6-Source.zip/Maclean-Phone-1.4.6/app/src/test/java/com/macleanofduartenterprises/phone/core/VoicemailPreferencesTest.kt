package com.macleanofduartenterprises.phone.core

import org.junit.Assert.assertEquals
import org.junit.Test

class VoicemailPreferencesTest {

    @Test
    fun activationCodeNormalizesFormattedPhoneNumber() {
        val snapshot = VoicemailPreferences.Snapshot(
            voicemailNumber = "",
            forwardingEnabled = true,
            forwardingNumber = "+1 (717) 500-6202",
            forwardingConditions = setOf(
                VoicemailPreferences.ForwardingCondition.UNANSWERED,
                VoicemailPreferences.ForwardingCondition.BUSY,
            ),
            forwardingAccountId = "1",
        )

        assertEquals(
            "**61*+17175006202#",
            VoicemailPreferences.activationCode(
                snapshot,
                VoicemailPreferences.ForwardingCondition.UNANSWERED,
            ),
        )
        assertEquals(
            "**67*+17175006202#",
            VoicemailPreferences.activationCode(
                snapshot,
                VoicemailPreferences.ForwardingCondition.BUSY,
            ),
        )
    }

    @Test
    fun deactivationCodeUsesSelectedCondition() {
        assertEquals(
            "##67#",
            VoicemailPreferences.deactivationCode(
                VoicemailPreferences.ForwardingCondition.BUSY,
            ),
        )
    }

    @Test
    fun selectedConditionsFollowCarrierCodeOrder() {
        val snapshot = VoicemailPreferences.Snapshot(
            voicemailNumber = "",
            forwardingEnabled = true,
            forwardingNumber = "7175006202",
            forwardingConditions = setOf(
                VoicemailPreferences.ForwardingCondition.BUSY,
                VoicemailPreferences.ForwardingCondition.UNANSWERED,
            ),
        )

        assertEquals(
            listOf(
                VoicemailPreferences.ForwardingCondition.UNANSWERED,
                VoicemailPreferences.ForwardingCondition.BUSY,
            ),
            VoicemailPreferences.selectedConditions(snapshot),
        )
    }

    @Test
    fun conditionalReasonsCanBeSelectedTogether() {
        val unanswered = VoicemailPreferences.ForwardingCondition.UNANSWERED
        val busy = VoicemailPreferences.ForwardingCondition.BUSY

        val selected = VoicemailPreferences.toggleCondition(setOf(unanswered), busy)

        assertEquals(setOf(unanswered, busy), selected)
    }

    @Test
    fun allCallsIsMutuallyExclusiveWithConditionalReasons() {
        val always = VoicemailPreferences.ForwardingCondition.ALWAYS
        val busy = VoicemailPreferences.ForwardingCondition.BUSY

        assertEquals(
            setOf(always),
            VoicemailPreferences.toggleCondition(setOf(busy), always),
        )
        assertEquals(
            setOf(busy),
            VoicemailPreferences.toggleCondition(setOf(always), busy),
        )
    }
}
