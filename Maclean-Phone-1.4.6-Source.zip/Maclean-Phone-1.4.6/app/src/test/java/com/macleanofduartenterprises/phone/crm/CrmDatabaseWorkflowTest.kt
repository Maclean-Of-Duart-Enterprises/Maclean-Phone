package com.macleanofduartenterprises.phone.crm

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.provider.ContactsContract
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CrmDatabaseWorkflowTest {
    private lateinit var context: Context
    private var database: CrmDatabase? = null

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase(DATABASE_NAME)
    }

    @After
    fun tearDown() {
        database?.close()
        context.deleteDatabase(DATABASE_NAME)
    }

    @Test
    fun `create edit restart favorite groups delete persists and cascades`() {
        var db = CrmDatabase(context)
        database = db
        val groupId = db.saveGroup(CrmGroup(name = "Клиенты 😀"))
        val id = db.saveContact(
            CrmContact(
                firstName = "Álvaro",
                notes = "Первичная заметка",
                groupIds = setOf(groupId),
                customFields = listOf(
                    CrmCustomField(type = CrmFieldType.PHONE, label = "Móvil", value = "5551234"),
                    CrmCustomField(type = CrmFieldType.CUSTOM, label = "Emoji ✨", value = "Sí"),
                ),
            ),
        )
        val created = db.getContact(id)!!
        db.saveContact(created.copy(lastName = "Muñoz", notes = "Изменено"))
        db.setFavorite(id, true)
        db.close()

        db = CrmDatabase(context)
        database = db
        val restarted = db.getContact(id)!!
        assertEquals("Muñoz", restarted.lastName)
        assertEquals("Изменено", restarted.notes)
        assertTrue(restarted.favorite)
        assertEquals(setOf(groupId), restarted.groupIds)
        assertEquals(2, restarted.customFields.size)

        db.deleteGroup(groupId)
        assertEquals("Álvaro Muñoz", db.getContact(id)!!.displayName)
        assertTrue(db.getContact(id)!!.groupIds.isEmpty())
        db.deleteContact(id)
        assertNull(db.getContact(id))
        assertEquals(0, count(db.writableDatabase, "crm_fields"))
        assertEquals(0, count(db.writableDatabase, "crm_contact_groups"))
    }

    @Test
    fun `version one migrates without data loss and repairs duplicate identity links`() {
        createVersionOneDatabase(context)
        val db = CrmDatabase(context)
        database = db
        assertEquals(2, db.readableDatabase.version)
        assertEquals(2, db.loadContacts().size)
        assertTrue(columnNames(db.readableDatabase, "crm_contacts").containsAll(setOf("favorite", "read_only")))
        assertEquals(1, scalar(db.readableDatabase, "SELECT COUNT(*) FROM crm_contacts WHERE system_contact_id=77"))
        assertEquals(1, scalar(db.readableDatabase, "SELECT COUNT(*) FROM crm_contacts WHERE raw_contact_id=88"))
        assertFalse(db.loadContacts().any(CrmContact::favorite))
    }

    @Test
    fun `raw contact account values always contain both keys even for local account`() {
        val values = rawContactAccountValues(ContactAccount(null, null, isSim = false))
        assertTrue(values.containsKey(ContactsContract.RawContacts.ACCOUNT_NAME))
        assertTrue(values.containsKey(ContactsContract.RawContacts.ACCOUNT_TYPE))
        assertNull(values.get(ContactsContract.RawContacts.ACCOUNT_NAME))
        assertNull(values.get(ContactsContract.RawContacts.ACCOUNT_TYPE))
    }

    @Test
    fun `bulk membership add remove and reorder persist without deleting contacts`() {
        var db = CrmDatabase(context)
        database = db
        val firstGroup = db.saveGroup(CrmGroup(name = "First custom"))
        val secondGroup = db.saveGroup(CrmGroup(name = "Second custom"))
        val first = db.saveContact(CrmContact(firstName = "One", customFields = emptyList()))
        val second = db.saveContact(CrmContact(firstName = "Two", customFields = emptyList()))
        db.updateGroupMembership(listOf(first, second), setOf(firstGroup), add = true)
        db.updateGroupMembership(listOf(first), setOf(secondGroup), add = true)
        db.moveGroup(secondGroup, -1)
        db.close()

        db = CrmDatabase(context)
        database = db
        assertEquals(setOf(firstGroup, secondGroup), db.getContact(first)!!.groupIds)
        assertEquals(setOf(firstGroup), db.getContact(second)!!.groupIds)
        db.updateGroupMembership(listOf(first, second), setOf(firstGroup), add = false)
        assertEquals(setOf(secondGroup), db.getContact(first)!!.groupIds)
        assertTrue(db.getContact(second)!!.groupIds.isEmpty())
        db.deleteGroup(secondGroup)
        assertEquals(2, db.loadContacts().count { it.id in setOf(first, second) })
    }

    @Test
    fun `local CRM storage remains available when contacts permission is denied`() {
        shadowOf(RuntimeEnvironment.getApplication()).denyPermissions(
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.WRITE_CONTACTS,
        )
        val options = SystemContactGateway(context).availableStorageOptions()
        assertTrue(options.single { it.storage == ContactStorage.APP }.enabled)
        assertFalse(options.single { it.storage == ContactStorage.PHONE }.enabled)
        assertTrue(SystemContactGateway(context).loadContacts().isEmpty())
    }

    private fun createVersionOneDatabase(context: Context) {
        context.openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null).use { db ->
            db.execSQL(
                """
                CREATE TABLE crm_contacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    system_contact_id INTEGER,
                    raw_contact_id INTEGER,
                    storage TEXT NOT NULL,
                    first_name TEXT NOT NULL DEFAULT '', middle_name TEXT NOT NULL DEFAULT '',
                    last_name TEXT NOT NULL DEFAULT '', nickname TEXT NOT NULL DEFAULT '',
                    household TEXT NOT NULL DEFAULT '', company TEXT NOT NULL DEFAULT '',
                    birthday TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', photo_uri TEXT,
                    stage TEXT NOT NULL DEFAULT 'New lead', service TEXT NOT NULL DEFAULT '',
                    source TEXT NOT NULL DEFAULT '', representative TEXT NOT NULL DEFAULT '',
                    next_action TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
                )
                """.trimIndent(),
            )
            db.execSQL(
                "CREATE TABLE crm_fields (id INTEGER PRIMARY KEY AUTOINCREMENT, contact_id INTEGER NOT NULL, field_type TEXT NOT NULL, label TEXT NOT NULL, value TEXT NOT NULL DEFAULT '', country_code TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(contact_id) REFERENCES crm_contacts(id) ON DELETE CASCADE)",
            )
            db.execSQL(
                "CREATE TABLE crm_groups (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL COLLATE NOCASE UNIQUE, color_argb INTEGER NOT NULL, position INTEGER NOT NULL DEFAULT 0)",
            )
            db.execSQL(
                "CREATE TABLE crm_contact_groups (contact_id INTEGER NOT NULL, group_id INTEGER NOT NULL, PRIMARY KEY(contact_id, group_id), FOREIGN KEY(contact_id) REFERENCES crm_contacts(id) ON DELETE CASCADE, FOREIGN KEY(group_id) REFERENCES crm_groups(id) ON DELETE CASCADE)",
            )
            repeat(2) { index ->
                db.execSQL(
                    "INSERT INTO crm_contacts(system_contact_id,raw_contact_id,storage,first_name,created_at,updated_at) VALUES(77,88,'APP',?,1,1)",
                    arrayOf("Legacy $index"),
                )
            }
            db.version = 1
        }
    }

    private fun count(db: SQLiteDatabase, table: String): Int = scalar(db, "SELECT COUNT(*) FROM $table")

    private fun scalar(db: SQLiteDatabase, sql: String): Int = db.rawQuery(sql, null).use {
        check(it.moveToFirst())
        it.getInt(0)
    }

    private fun columnNames(db: SQLiteDatabase, table: String): Set<String> =
        db.rawQuery("PRAGMA table_info($table)", null).use { cursor ->
            buildSet {
                val name = cursor.getColumnIndexOrThrow("name")
                while (cursor.moveToNext()) add(cursor.getString(name))
            }
        }

    companion object {
        private const val DATABASE_NAME = "maclean_phone_crm.db"
    }
}
