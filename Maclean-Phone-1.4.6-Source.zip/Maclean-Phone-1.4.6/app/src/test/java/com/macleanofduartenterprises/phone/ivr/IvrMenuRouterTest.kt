package com.macleanofduartenterprises.phone.ivr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IvrMenuRouterTest {
    private val config = IvrConfig(
        maxInvalidAttempts = 2,
        directory = listOf(
            DirectoryEntry(
                digit = "1",
                englishLabel = "Sales",
                russianLabel = "Отдел продаж",
                destination = "101"
            ),
            DirectoryEntry(
                digit = "9",
                englishLabel = "Repeat",
                russianLabel = "Повторить",
                action = DirectoryAction.REPEAT_MENU
            ),
            DirectoryEntry(
                digit = "0",
                englishLabel = "End call",
                russianLabel = "Завершить звонок",
                action = DirectoryAction.HANG_UP
            )
        )
    )

    @Test
    fun oneSelectsEnglishThenDirectoryOneTransfers() {
        val router = IvrMenuRouter(config)

        val language = router.accept('1')
        val transfer = router.accept('1')

        assertEquals(IvrRouteCommand.PLAY_DIRECTORY, language.command)
        assertEquals(IvrLanguage.ENGLISH, language.language)
        assertEquals(IvrRouteCommand.TRANSFER, transfer.command)
        assertEquals("101", transfer.destination)
    }

    @Test
    fun twoSelectsRussian() {
        val result = IvrMenuRouter(config).accept('2')

        assertEquals(IvrRouteCommand.PLAY_DIRECTORY, result.command)
        assertEquals(IvrLanguage.RUSSIAN, result.language)
    }

    @Test
    fun starRepeatsCurrentMenu() {
        val router = IvrMenuRouter(config)

        val languageRepeat = router.accept('*')
        router.accept('1')
        val directoryRepeat = router.accept('*')

        assertEquals(IvrRouteCommand.PLAY_LANGUAGE_MENU, languageRepeat.command)
        assertEquals(IvrRouteCommand.PLAY_DIRECTORY, directoryRepeat.command)
    }

    @Test
    fun invalidAttemptsUseFallback() {
        val router = IvrMenuRouter(config.copy(fallbackDestination = "operator"))

        val first = router.accept('7')
        val second = router.accept('7')

        assertTrue(first.invalidSelection)
        assertEquals(IvrRouteCommand.PLAY_LANGUAGE_MENU, first.command)
        assertTrue(second.invalidSelection)
        assertEquals(IvrRouteCommand.TRANSFER, second.command)
        assertEquals("operator", second.destination)
    }

    @Test
    fun invalidAttemptsHangUpWithoutFallback() {
        val router = IvrMenuRouter(config)

        router.noInput()
        val result = router.noInput()

        assertEquals(IvrRouteCommand.HANG_UP, result.command)
    }

    @Test
    fun repeatEntryDoesNotFinishMenu() {
        val router = IvrMenuRouter(config)
        router.accept('1')

        val repeat = router.accept('9')
        val transfer = router.accept('1')

        assertEquals(IvrRouteCommand.PLAY_DIRECTORY, repeat.command)
        assertFalse(repeat.invalidSelection)
        assertEquals(IvrRouteCommand.TRANSFER, transfer.command)
    }
}
