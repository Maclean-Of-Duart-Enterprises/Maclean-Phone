package com.macleanofduartenterprises.phone.ivr

import org.junit.Assert.assertTrue
import org.junit.Test

class IvrPromptBuilderTest {
    private val config = IvrConfig(
        englishGreeting = "Welcome.",
        russianGreeting = "Добро пожаловать.",
        directory = listOf(
            DirectoryEntry("1", "Sales", "Отдел продаж", destination = "101")
        )
    )

    @Test
    fun languagePromptContainsRequiredSelections() {
        assertTrue("Press 1 for English" in IvrPromptBuilder.languageEnglish(config))
        assertTrue("нажмите 2" in IvrPromptBuilder.languageRussian(config))
    }

    @Test
    fun directoryUsesLocalizedLabels() {
        assertTrue("Sales" in IvrPromptBuilder.directory(config, IvrLanguage.ENGLISH))
        assertTrue("Отдел продаж" in IvrPromptBuilder.directory(config, IvrLanguage.RUSSIAN))
    }
}
