package com.macleanofduartenterprises.phone.ui.settings

import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class AppLicenseTextTest {
    @Test
    fun `complete attached AGPLv3 text is packaged for offline reading`() {
        val text = AppLicenseText.load(RuntimeEnvironment.getApplication()).getOrThrow()

        assertTrue(text.startsWith("GNU AFFERO GENERAL PUBLIC LICENSE\n\nVersion 3, 19 November 2007"))
        (0..17).forEach { section ->
            assertTrue("Missing AGPLv3 section $section", Regex("(?m)^$section\\. ").containsMatchIn(text))
        }
        assertTrue(text.contains("13. Remote Network Interaction; Use with the GNU General Public License."))
        assertTrue(text.contains("END OF TERMS AND CONDITIONS"))
        assertTrue(text.contains("How to Apply These Terms to Your New Programs"))
        assertEquals(
            "80c0bc7925f08bdbbbb276369b738ab880a63087d011b4c375a813ff9bd845f7",
            text.toByteArray(Charsets.UTF_8).sha256(),
        )
    }

    private fun ByteArray.sha256(): String = MessageDigest.getInstance("SHA-256")
        .digest(this)
        .joinToString(separator = "") { byte ->
            (byte.toInt() and 0xff).toString(16).padStart(2, '0')
        }
}
