package com.macleanofduartenterprises.phone.crm

import android.content.Context
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CrmRepositoryWorkflowTest {
    private lateinit var context: Context

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("maclean_phone_crm.db")
        context.cacheDir.resolve("crm_exports").deleteRecursively()
        context.filesDir.resolve("crm_contact_photos").deleteRecursively()
    }

    @After
    fun tearDown() {
        context.deleteDatabase("maclean_phone_crm.db")
        context.cacheDir.resolve("crm_exports").deleteRecursively()
        context.filesDir.resolve("crm_contact_photos").deleteRecursively()
    }

    @Test
    fun `select copy secure share round trip import and bulk delete`() = runBlocking {
        val repository = CrmRepository(context)
        val groupId = repository.saveGroup(CrmGroup(name = "Clientes 😀"))
        val first = repository.saveContact(
            CrmContact(
                firstName = "Ana",
                lastName = "Muñoz",
                groupIds = setOf(groupId),
                customFields = listOf(
                    CrmCustomField(type = CrmFieldType.PHONE, label = "Móvil", value = "5550001", countryCode = "+34"),
                    CrmCustomField(type = CrmFieldType.CUSTOM, label = "Idioma", value = "Español"),
                ),
            ),
        )
        val second = repository.saveContact(
            CrmContact(
                firstName = "Ирина",
                notes = "Заметка ✨",
                customFields = listOf(CrmCustomField(type = CrmFieldType.EMAIL, label = "Работа", value = "irina@example.com")),
            ),
        )
        val copy = repository.copyContacts(listOf(first, second), ContactStorage.APP)
        assertEquals(2, copy.succeeded)
        assertEquals(0, copy.failed)
        assertEquals(4, repository.loadSnapshot().contacts.size)

        val shared = repository.createShareFile(listOf(first, second), repository.loadSnapshot().groups)
        assertEquals("content", shared.uri.scheme)
        assertTrue(shared.uri.authority!!.endsWith(".fileprovider"))
        val parsed = context.contentResolver.openInputStream(shared.uri)!!.use(VCardParser::parse)
        assertEquals(2, parsed.size)
        assertEquals(setOf("Ana Muñoz", "Ирина"), parsed.map { it.contact.displayName }.toSet())

        val imported = repository.importVCard(shared.uri, ContactStorage.APP)
        assertEquals(2, imported.imported)
        assertEquals(0, imported.failed)
        assertEquals(6, repository.loadSnapshot().contacts.size)

        val deleted = repository.deleteContacts(listOf(first, second))
        assertEquals(2, deleted.succeeded)
        assertEquals(0, deleted.failed)
        assertEquals(4, repository.loadSnapshot().contacts.size)
    }

    @Test
    fun `merge saves all unique data before source deletion`() = runBlocking {
        val repository = CrmRepository(context)
        val groupOne = repository.saveGroup(CrmGroup(name = "One"))
        val groupTwo = repository.saveGroup(CrmGroup(name = "Two"))
        val first = repository.saveContact(
            CrmContact(
                firstName = "Merge",
                notes = "First",
                groupIds = setOf(groupOne),
                customFields = listOf(CrmCustomField(type = CrmFieldType.PHONE, label = "Mobile", value = "5551234567")),
            ),
        )
        val second = repository.saveContact(
            CrmContact(
                firstName = "Merge",
                company = "Maclean",
                notes = "Second",
                favorite = true,
                groupIds = setOf(groupTwo),
                customFields = listOf(CrmCustomField(type = CrmFieldType.EMAIL, label = "Email", value = "merge@example.com")),
            ),
        )
        val result = repository.mergeContacts(listOf(first, second))
        assertEquals(1, result.deletedSources)
        assertEquals(0, result.failedDeletes)
        val remaining = repository.loadSnapshot().contacts.single()
        assertEquals("Maclean", remaining.company)
        assertEquals("First\nSecond", remaining.notes)
        assertTrue(remaining.favorite)
        assertEquals(setOf(groupOne, groupTwo), remaining.groupIds)
        assertEquals(setOf(CrmFieldType.PHONE, CrmFieldType.EMAIL), remaining.customFields.map(CrmCustomField::type).toSet())
    }

    @Test
    fun `favorites folder uses persisted CRM favorite state`() = runBlocking {
        val repository = CrmRepository(context)
        val favorite = repository.saveContact(
            CrmContact(firstName = "Favorite", favorite = true),
        )
        repository.saveContact(CrmContact(firstName = "Regular"))

        assertEquals(
            listOf(favorite.id),
            repository.loadSnapshot(favoritesOnly = true).contacts.map(CrmContact::id),
        )

        repository.setFavorite(favorite, false)
        assertTrue(repository.loadSnapshot(favoritesOnly = true).contacts.isEmpty())
    }
}
