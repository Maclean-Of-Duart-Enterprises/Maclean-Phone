package com.macleanofduartenterprises.phone.core

import android.media.MediaRecorder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CallRecordingAudioPolicyTest {
    @Test
    fun microphoneIsFirstToAvoidSilentCommunicationSource() {
        assertEquals(
            MediaRecorder.AudioSource.MIC,
            CallRecordingAudioPolicy.candidates().first().audioSource,
        )
    }

    @Test
    fun compatibilitySourcesRemainAvailable() {
        val sources = CallRecordingAudioPolicy.candidates().map { it.audioSource }

        assertTrue(MediaRecorder.AudioSource.VOICE_RECOGNITION in sources)
        assertTrue(MediaRecorder.AudioSource.VOICE_COMMUNICATION in sources)
    }
}
