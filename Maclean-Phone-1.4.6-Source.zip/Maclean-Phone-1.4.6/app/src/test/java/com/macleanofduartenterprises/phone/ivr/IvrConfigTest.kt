package com.macleanofduartenterprises.phone.ivr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IvrConfigTest {
    @Test
    fun completeConfigValidates() {
        val config = IvrConfig(
            sipServer = "sip.example.com",
            sipDomain = "example.com",
            username = "ivr",
            directory = listOf(
                DirectoryEntry("1", "Sales", "Продажи", destination = "101")
            )
        )

        assertTrue(config.validationErrors("secret").isEmpty())
    }

    @Test
    fun duplicateDigitsAndMissingTransferAreRejected() {
        val config = IvrConfig(
            sipServer = "sip.example.com",
            sipDomain = "example.com",
            username = "ivr",
            directory = listOf(
                DirectoryEntry("1", "Sales", "Продажи", destination = ""),
                DirectoryEntry("1", "Support", "Поддержка", destination = "102")
            )
        )

        val errors = config.validationErrors("secret")

        assertTrue(errors.any { "unique" in it })
        assertTrue(errors.any { "transfer entry" in it })
    }

    @Test
    fun normalizedConfigTrimsAndSortsDirectory() {
        val normalized = IvrConfig(
            sipServer = " sip:sip.example.com/ ",
            sipDomain = " sips:example.com/ ",
            username = " ivr ",
            directory = listOf(
                DirectoryEntry(" 9 ", " Repeat ", " Повтор ", DirectoryAction.REPEAT_MENU),
                DirectoryEntry(" 1 ", " Sales ", " Продажи ", destination = " 101 ")
            )
        ).normalized()

        assertEquals("sip.example.com", normalized.sipServer)
        assertEquals("example.com", normalized.sipDomain)
        assertEquals("ivr", normalized.username)
        assertEquals(listOf("1", "9"), normalized.directory.map { it.digit })
        assertEquals("101", normalized.directory.first().destination)
    }

    @Test
    fun phoneForwardingValidatesWithoutDirectoryAndNormalizesNumber() {
        val config = IvrConfig(
            sipServer = "sip.example.com",
            sipDomain = "example.com",
            username = "ivr",
            callForwardingEnabled = true,
            callForwardingTargetType = CallForwardingTargetType.PHONE_NUMBER,
            callForwardingPhoneNumber = "+1 (212) 555-0199",
        ).normalized()

        assertTrue(config.validationErrors("secret").isEmpty())
        assertEquals("+12125550199", config.forwardingDestination())
    }

    @Test
    fun enabledSipForwardingRequiresADestination() {
        val config = IvrConfig(
            sipServer = "sip.example.com",
            sipDomain = "example.com",
            username = "ivr",
            callForwardingEnabled = true,
            callForwardingTargetType = CallForwardingTargetType.SIP_DESTINATION,
        )

        assertTrue(config.validationErrors("secret").any { "SIP forwarding" in it })
    }
}
