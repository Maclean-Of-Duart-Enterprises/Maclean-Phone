package com.macleanofduartenterprises.phone.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GroupCallPolicyTest {
    @Test
    fun `two calls are not mergeable until Telecom reports the relationship`() {
        val calls = listOf(
            call("active", GroupCallPolicy.State.ACTIVE),
            call("held", GroupCallPolicy.State.HELD),
        )

        assertNull(GroupCallPolicy.mergeOperation(calls))
    }

    @Test
    fun `conference uses the owner and candidate reported by Telecom`() {
        val calls = listOf(
            call("first", GroupCallPolicy.State.ACTIVE, conferenceableIds = setOf("second")),
            call("second", GroupCallPolicy.State.HELD),
        )

        assertEquals(
            GroupCallPolicy.MergeOperation.ConferenceCalls("first", "second"),
            GroupCallPolicy.mergeOperation(calls),
        )
    }

    @Test
    fun `existing conference merge capability takes precedence`() {
        val calls = listOf(
            call("conference", GroupCallPolicy.State.ACTIVE, canMergeConference = true),
            call("other", GroupCallPolicy.State.HELD),
        )

        assertEquals(
            GroupCallPolicy.MergeOperation.MergeExistingConference("conference"),
            GroupCallPolicy.mergeOperation(calls),
        )
    }

    @Test
    fun `active and held calls can swap only when active call supports hold`() {
        val unsupported = listOf(
            call("active", GroupCallPolicy.State.ACTIVE),
            call("held", GroupCallPolicy.State.HELD),
        )
        val supported = unsupported.map {
            if (it.id == "active") it.copy(canHold = true) else it
        }

        assertFalse(GroupCallPolicy.canSwap(unsupported))
        assertTrue(GroupCallPolicy.canSwap(supported))
    }

    @Test
    fun `conference participant list contains stable leaf call ids`() {
        val calls = listOf(
            call("root", GroupCallPolicy.State.ACTIVE, childIds = setOf("a", "b")),
            call("a", GroupCallPolicy.State.ACTIVE, parentId = "root"),
            call("b", GroupCallPolicy.State.ACTIVE, parentId = "root"),
        )

        assertEquals(listOf("a", "b"), GroupCallPolicy.participantIds(calls))
        assertTrue(GroupCallPolicy.isConference(calls))
    }

    @Test
    fun `direct participant add requires active root capability`() {
        val calls = listOf(
            call("owner", GroupCallPolicy.State.ACTIVE, canAddParticipant = true),
            call(
                "child",
                GroupCallPolicy.State.ACTIVE,
                parentId = "owner",
                canAddParticipant = true,
            ),
        )

        assertEquals("owner", GroupCallPolicy.directAddOwner(calls))
    }

    @Test
    fun `incoming call becomes foreground before an active call`() {
        val calls = listOf(
            call("active", GroupCallPolicy.State.ACTIVE),
            call("incoming", GroupCallPolicy.State.RINGING),
        )

        assertEquals("incoming", GroupCallPolicy.preferredForeground(calls))
    }

    private fun call(
        id: String,
        state: GroupCallPolicy.State,
        parentId: String? = null,
        childIds: Set<String> = emptySet(),
        conferenceableIds: Set<String> = emptySet(),
        canMergeConference: Boolean = false,
        canAddParticipant: Boolean = false,
        canHold: Boolean = false,
    ) = GroupCallPolicy.CallInfo(
        id = id,
        state = state,
        parentId = parentId,
        childIds = childIds,
        conferenceableIds = conferenceableIds,
        canMergeConference = canMergeConference,
        canAddParticipant = canAddParticipant,
        canHold = canHold,
    )
}
