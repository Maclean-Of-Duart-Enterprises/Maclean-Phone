package com.macleanofduartenterprises.phone.crm

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class VCardRoundTripTest {
    @Test
    fun `all supported fields groups photo unicode and labels survive round trip`() {
        val groups = listOf(CrmGroup(7, "Familia 👨‍👩‍👧; Семья"))
        val photo = byteArrayOf(1, 2, 3, 4, 5)
        val original = CrmContact(
            id = 42,
            firstName = "José 😀",
            middleName = "Ильич",
            lastName = "O;Connor",
            nickname = "Pepe, Пепе",
            household = "Casa 🏡",
            company = "Compañía; ООО",
            birthday = "1980-12-31",
            notes = "Línea uno\nСтрока два  ",
            photoUri = "file:/photo.img",
            stage = "Client",
            service = "Consultoría",
            source = "Рекомендация",
            representative = "Zoë",
            nextAction = "Call 📞",
            favorite = true,
            groupIds = setOf(7),
            customFields = listOf(
                CrmCustomField(type = CrmFieldType.PHONE, label = "Móvil 📱", value = "5551234567", countryCode = "+34"),
                CrmCustomField(type = CrmFieldType.FAX, label = "Fax; oficina", value = "2125550000", countryCode = "+1"),
                CrmCustomField(type = CrmFieldType.EMAIL, label = "Correo 😀", value = "JOSÉ@example.com"),
                CrmCustomField(type = CrmFieldType.ADDRESS, label = "Dirección", value = "Calle 1; Madrid, España"),
                CrmCustomField(type = CrmFieldType.WEBSITE, label = "Сайт", value = "https://example.test/a,b;c"),
                CrmCustomField(type = CrmFieldType.CUSTOM, label = "Любимое emoji ✨", value = "Да; sí, yes"),
            ),
        )
        val output = ByteArrayOutputStream()
        val result = VCardWriter.write(listOf(original), groups, output) { photo }
        assertEquals(1, result.exported)
        assertEquals(0, result.failed)

        val parsed = VCardParser.parse(ByteArrayInputStream(output.toByteArray())).single()
        val restored = parsed.contact
        assertEquals(original.firstName, restored.firstName)
        assertEquals(original.middleName, restored.middleName)
        assertEquals(original.lastName, restored.lastName)
        assertEquals(original.nickname, restored.nickname)
        assertEquals(original.household, restored.household)
        assertEquals(original.company, restored.company)
        assertEquals(original.birthday, restored.birthday)
        assertEquals(original.notes, restored.notes)
        assertEquals(original.stage, restored.stage)
        assertEquals(original.service, restored.service)
        assertEquals(original.source, restored.source)
        assertEquals(original.representative, restored.representative)
        assertEquals(original.nextAction, restored.nextAction)
        assertTrue(restored.favorite)
        assertEquals(groups.map(CrmGroup::name).toSet(), parsed.groupNames)
        assertArrayEquals(photo, parsed.photoBytes)
        assertEquals(
            original.customFields.map { listOf(it.type, it.label, it.value, it.countryCode) },
            restored.customFields.map { listOf(it.type, it.label, it.value, it.countryCode) },
        )
    }

    @Test
    fun `base64 padding does not consume END VCARD`() {
        val output = ByteArrayOutputStream()
        VCardWriter.write(
            listOf(CrmContact(firstName = "Photo", photoUri = "file:/x")),
            emptyList(),
            output,
        ) { byteArrayOf(1, 2) }
        val text = output.toString(Charsets.UTF_8)
        assertTrue(text.contains("END:VCARD"))
        assertEquals(1, VCardParser.parse(text).size)
    }

    @Test
    fun `folded lines remain at most 75 octets and never split unicode`() {
        val line = "NOTE:" + "😀РусскийEspañol".repeat(20)
        val folded = VCardWriter.foldUtf8(line)
        folded.split("\r\n").forEach { physical ->
            assertTrue(physical.toByteArray(Charsets.UTF_8).size <= 75)
        }
        val card = "BEGIN:VCARD\r\nVERSION:3.0\r\n${folded}\r\nFN:Unicode\r\nEND:VCARD\r\n"
        assertEquals(line.removePrefix("NOTE:"), VCardParser.parse(card).single().contact.notes)
    }
}
