package com.macleanofduartenterprises.phone.core

import com.macleanofduartenterprises.phone.domain.entity.CalledLineInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CalledLinePolicyTest {
    @Test
    fun `subscription address takes precedence over account address`() {
        assertEquals(
            "+1 202 555 0101",
            CalledLinePolicy.firstNonBlank(
                "  +1 202 555 0101  ",
                "+1 202 555 0199",
            ),
        )
    }

    @Test
    fun `blank subscription address falls back to account address`() {
        assertEquals(
            "sales@example.test",
            CalledLinePolicy.firstNonBlank("", "sales@example.test"),
        )
    }

    @Test
    fun `account label is not repeated when it equals the number`() {
        assertEquals(
            "",
            CalledLinePolicy.withoutDuplicateLabel("+12025550101", "+12025550101"),
        )
    }

    @Test
    fun `notification keeps called number and provider separate from caller id`() {
        assertEquals(
            "Called +12025550101 via Google Voice",
            CalledLinePolicy.notificationSummary(
                CalledLineInfo(
                    number = "+12025550101",
                    accountLabel = "Google Voice",
                ),
            ),
        )
    }

    @Test
    fun `provider label remains useful when provider withholds number`() {
        assertEquals(
            "Called line: Google Voice",
            CalledLinePolicy.notificationSummary(
                CalledLineInfo(accountLabel = "Google Voice"),
            ),
        )
    }

    @Test
    fun `unknown destination never invents a number`() {
        assertNull(CalledLinePolicy.notificationSummary(CalledLineInfo.Unknown))
    }

    @Test
    fun `outgoing summary keeps calling number and provider separate from callee`() {
        assertEquals(
            "From +12025550199 via Work SIM",
            CalledLinePolicy.outgoingSummary(
                CalledLineInfo(number = "+12025550199", accountLabel = "Work SIM"),
            ),
        )
    }
}
