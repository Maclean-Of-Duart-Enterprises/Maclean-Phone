# Maclean Phone 1.4.0

## Telecom call-audio routing

- Replaced the Android 14+ in-call `AudioManager` override with Telecom's
  authoritative `CallEndpoint` APIs.
- The Speaker button still toggles speaker on a short press and reliably opens
  the interactive endpoint list after a three-second hold.
- The endpoint picker tracks the exact Bluetooth device, hearing device,
  wired headset, phone earpiece, speaker, or streaming endpoint reported by
  Android. Android 8–13 retain the compatible `CallAudioState` route path.
- Fixed the Compose press gesture restarting during recomposition, which could
  cancel the three-second hold before the route picker appeared.

## Password-free CRM Contacts tab

- Replaced the old read-only Contacts list with an integrated Maclean CRM
  contact center based on the supplied native CRM's branding, pipeline, and
  local-database design. No CRM PIN or password screen is included.
- Existing Android contacts and Maclean app-only contacts appear together.
  App-only phone matches also participate in local caller identification and
  contact search.
- Added editable contact photos with choose, replace, preview, and remove
  controls.
- Added first, middle, and last names; nickname; household/organization;
  company; birthday; notes; pipeline stage; service/interest; lead source;
  representative; and follow-up fields.
- Added unlimited ordered fields. Every field has an editable label and can be
  a phone number, email, mailing address, fax, website, or arbitrary custom
  value. Phone and fax entries include a separate international dial code.
- Text entry is unrestricted Unicode and accepts English, Spanish, Russian,
  mixed scripts, combining characters, and emoji.
- Added persistent sorting by first name, last name, company, date added, or
  recently updated, in ascending or descending order.
- Added unlimited custom groups, group filters, renaming, deletion without
  deleting contacts, and editable group ordering.

## Storage and VCF import

- Added explicit storage choices for Maclean Phone app storage, Android phone
  contacts, and a device-exposed SIM contacts account.
- Android phone contacts receive supported standard fields through
  `ContactsContract`; Maclean-specific and arbitrary fields stay in the local
  CRM extension so they are not lost.
- SIM is selectable only when the manufacturer exposes a writable SIM account.
  SIM hardware/providers may retain only a name and limited phone fields.
- Added local multi-contact `.vcf` import for vCard 2.1, 3.0, and 4.0, including
  folded and quoted-printable text, names, international phones, fax, email,
  addresses, websites, company, birthday, notes, categories/groups, common
  extensions, Unicode, emoji, and embedded photos.

## Compatibility and identity

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version code is 11 and version name is 1.4.0.
- Google Voice remains free to hold Android's separate outgoing Call
  redirecting role; incoming carrier-forwarding corrections from 1.3.1 remain
  unchanged.
- The release uses the existing Maclean Phone update signing identity.

