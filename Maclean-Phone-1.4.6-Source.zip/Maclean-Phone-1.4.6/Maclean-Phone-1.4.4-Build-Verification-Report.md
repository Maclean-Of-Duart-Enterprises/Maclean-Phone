# Maclean Phone 1.4.4 Build Verification Report

Verification date: 2026-09-21

## Release identity

| Check | Result |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version name | `1.4.4` |
| Version code | `15` |
| Minimum SDK | `26` |
| Target / compile SDK | `36` / `36` |
| Architectures | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |
| APK size | 173,782,174 bytes |
| Signing | APK Signature Scheme v2 verified |
| Signer | `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises` |
| Signer certificate SHA-256 | `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136` |
| Alignment | `zipalign -c -P 16 -v 4` passed |

The unchanged package name, increased version code, and unchanged signer
identity meet Android's requirements for installing this release over a
correctly signed Maclean Phone 1.4.3 installation without clearing app data.

## Toolchain and automated checks

| Check | Result |
|---|---|
| JDK | Temurin 21.0.12.1 |
| Gradle | 9.4.0 |
| Android SDK / Build Tools | 36 / 36.0.0 |
| `testDebugUnitTest` | Passed: 60 tests, 0 failures, 0 errors, 0 skipped |
| `lintRelease` | Passed: 0 errors, 58 warnings, 1 hint |
| `assembleRelease` | Passed |
| `aapt dump badging` | Package, version code/name, min SDK, and target SDK verified |
| `apksigner verify --verbose --print-certs` | Passed |
| `zipalign` verification | Passed |

The non-blocking lint findings remain available in the generated lint report
and primarily concern existing compatibility, deprecation, and modernization
guidance. No blocking lint issue was suppressed for this release.

## Upgrade and data-integrity review

- The application ID and release signing identity are unchanged.
- The CRM database remains at schema version 2.
- No database table, migration, backup rule, or storage format was changed in
  1.4.4.
- The AGPLv3 license asset and Settings → Legal → License screen remain present.
- Release-signing credentials are not embedded in this report or Gradle source.

## Device-test boundary

No physical Android device or active carrier, Google Voice, or SIP account was
connected to this build environment. Installation over 1.4.3 and the exact
called number exposed by each provider require final acceptance testing on the
intended phone. Automated unit tests, release lint, signed packaging, package
metadata, certificate, ABI, and alignment verification all passed.
