# Maclean Phone 1.1.3

## Call-forwarding correction

- Carrier forwarding activation and deactivation codes are now sent through an
  explicitly selected physical cellular SIM.
- Google Voice, SIP, and other internet-calling accounts are excluded from the
  carrier-SIM selector and can no longer intercept the forwarding code.
- Maclean Phone now explains that it must be the default phone app before
  Android permits it to send a call-forwarding MMI code.
- A confirmation dialog displays the exact carrier code and selected SIM before
  anything is sent.
- Phone-number formatting is removed from the forwarding destination before the
  carrier code is built.
- Missing default-phone status, phone permissions, SIM access, and unsupported
  device settings now produce clear recovery instructions instead of silently
  failing.

## Installation

Install version 1.1.3 directly over Maclean Phone 1.1.2. Do not uninstall first
if you want to retain SIP/VoIP and app settings. The package name and signing
identity are unchanged.

## Carrier limitation

Maclean Phone routes the code to the selected physical SIM, but forwarding
codes remain carrier-specific. If the carrier rejects the displayed code, use
the carrier's own call-forwarding settings or carrier-specific activation code.
