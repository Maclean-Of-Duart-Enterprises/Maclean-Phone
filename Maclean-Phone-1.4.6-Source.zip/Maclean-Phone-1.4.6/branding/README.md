# Maclean Phone artwork

- `maclean-phone-artwork-original.jpg` is the supplied text-free tartan phone artwork used for launcher, splash, onboarding, and store artwork.
- `company-logo-original.jpg` is the supplied Maclean Of Duart Enterprises Corp logo.
- `company-logo-transparent.png` removes only the surrounding black field. The diamond, gold border, lettering, colors, and crest are retained from the supplied original.

Run `python3 tools/generate_brand_assets.py` from the project root to rebuild all Android density variants, the monochrome notification mark, and store artwork.
