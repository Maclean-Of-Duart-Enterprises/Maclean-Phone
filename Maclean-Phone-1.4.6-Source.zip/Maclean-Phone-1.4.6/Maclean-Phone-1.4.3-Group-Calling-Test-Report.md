# Maclean Phone 1.4.3 Group Calling Test Report

Test date: 2026-09-15

## Automated coverage

The release includes seven pure group-call policy tests. All passed as part of
the full 54-test suite.

| Scenario | Expected behavior | Result |
|---|---|---|
| Two unassociated calls | Merge remains unavailable until Telecom reports capability | Passed |
| Conferenceable pair | Uses the exact owner/candidate relationship reported by Telecom | Passed |
| Existing conference | Uses the conference owner's merge operation | Passed |
| Active plus held call | Swap is allowed only when the active call supports hold | Passed |
| Conference parent and children | UI participant list uses stable leaf-call IDs | Passed |
| Direct participant add | Requires an active root call with add-participant capability | Passed |
| Incoming call during active call | Ringing call receives foreground priority | Passed |

## Wiring and behavior review

| Feature | Verification |
|---|---|
| Add call button | Wired to an additional Telecom call through the live call's exact phone account; direct participant add is used when exposed |
| Merge calls button | Enabled from live Telecom conferenceability/capabilities and wired to `conference` or `mergeConference` |
| Multiple-call lifetime | Every Telecom `Call` remains registered until `onCallRemoved`; one disconnected participant does not close the entire UI |
| Conference confirmation | “Conference connected” appears only after a conference parent/child relationship is observed |
| Swap/switch | Supports conference swap or active/held hold-unhold switching where available |
| Participant management | Uses stable generated IDs and exposes switch, separate, and end only when appropriate |
| Audio controls | Existing mute, speaker, named audio-endpoint picker, and manual recording controls remain on the in-call screen |
| Error handling | Unsupported add/merge/swap/separate/end requests show explanatory or failure status instead of false success |
| Redirected numbers | Caller address extraction prefers the gateway's original number and handles missing addresses safely |
| Permissions | Selected-account lookup and call placement fail safely when runtime permissions are absent |

## Manual acceptance procedure

These steps require a physical phone and a calling account that supports carrier
conference calls:

1. Install 1.4.3 over the existing Maclean Phone installation and confirm CRM
   contacts, groups, settings, and call history remain available.
2. Place a normal call and confirm **Add call** and **Merge calls** are visible.
3. Tap **Add call**, dial a second number, and confirm the first call is held or
   otherwise retained by the account.
4. After the second party answers, confirm **Merge calls** becomes enabled only
   if the calling account reports conference support.
5. Merge and confirm the screen reports **Group call** with the correct
   participant count only after the carrier connects it.
6. Open **Manage**, test participant switching, separation, and individual end
   actions when enabled by the carrier.
7. Test **Swap calls** before merge, then verify speaker, phone, Bluetooth, mute,
   keypad, hold, and hang-up behavior during the conference.
8. Repeat with each intended SIM, Google Voice configuration, Wi-Fi calling
   route, and SIP/VoIP connection service. Record unsupported capabilities as
   account/network limitations rather than app failures when Android Telecom
   does not expose them.

No physical device was connected during this build, so this carrier acceptance
procedure is documented but not represented as completed.

