# Maclean Phone 1.4.2 Build Verification Report

Verification completed: 2026-08-28 UTC

## Result

The Maclean Phone 1.4.2 release build completed successfully. The APK is signed, aligned, universal, and identifies itself with the requested application ID and new version. The complete AGPLv3 license embedded in the signed APK exactly matches the license included with the source.

## Release identity

| Property | Verified value |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version name | `1.4.2` |
| Version code | `13` |
| Previous release version code | `12` |
| Compile SDK | `36` |
| Minimum SDK | `26` |
| Target SDK | `36` |
| Architectures | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |
| APK size | 173,749,406 bytes |

## APK verification

| Check | Result |
|---|---|
| Release build | PASS |
| APK Signature Scheme v2 | PASS |
| Signers | 1 |
| Certificate SHA-256 | `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136` |
| ZIP/APK 4-byte and 16-KiB alignment | PASS |
| APK SHA-256 | `4224c203b935c4113e19bc23c307d3df1a2cb955ca43143f3e126062af056a15` |

The application ID and signing certificate match the 1.4.1 release, and the version code increases from 12 to 13. No database version or schema change was made for 1.4.2. These facts establish Android update-package compatibility without a destructive data migration.

## License verification

| Check | Result |
|---|---|
| Settings entry wired to license screen | PASS |
| License loads from a bundled offline asset | PASS |
| Complete sections 0 through 17 present | PASS |
| AGPLv3 network-interaction section 13 present | PASS |
| End-of-terms and application instructions present | PASS |
| APK license SHA-256 | `80c0bc7925f08bdbbbb276369b738ab880a63087d011b4c375a813ff9bd845f7` |
| Source license SHA-256 | `80c0bc7925f08bdbbbb276369b738ab880a63087d011b4c375a813ff9bd845f7` |
| APK/source byte comparison | PASS |

The license screen reads the asset on an I/O dispatcher, supports scrolling and text selection, and has explicit loading and failure states.

## Automated quality gates

| Gate | Result |
|---|---|
| Unit/Robolectric suites | 14 suites |
| Tests | 47 passed |
| Failures/errors/skips | 0 / 0 / 0 |
| Release lint errors | 0 |
| Release lint warnings | 59 |
| Release lint hints | 1 |
| Placeholder scan in source | No `TODO`, `FIXME`, `Not implemented`, or `Coming soon` matches |

The remaining lint findings are non-release-blocking modernization and packaging observations inherited from the working application, including KTX suggestions, unused resources, launcher artwork suggestions, guarded newer-API constants, and dependency-update notices.

## Build command

```text
:app:testDebugUnitTest :app:lintRelease :app:assembleRelease
BUILD SUCCESSFUL
```

## Device-test limitation

No physical Android device or emulator was connected to the build environment. Consequently, the actual tap-through of **Settings → Legal → License** and an install-over of a populated 1.4.1 device were not represented as completed physical-device tests. Package identity, certificate identity, increasing version code, unchanged database schema, compiled navigation wiring, packaged-asset equality, unit tests, lint, alignment, and signature were verified.

Recommended final device acceptance check:

1. Back up a device running the signed 1.4.1 release.
2. Install the 1.4.2 APK as an update and confirm existing data and settings remain present.
3. Open **Settings → Legal → License**, scroll to the end, select a passage, and repeat with the device offline.
4. Make one carrier or SIP test call and confirm the existing in-call controls remain available.

