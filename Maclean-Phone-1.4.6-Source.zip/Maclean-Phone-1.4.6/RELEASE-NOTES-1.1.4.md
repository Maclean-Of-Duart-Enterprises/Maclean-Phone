# Maclean Phone 1.1.4

## Multiple carrier-forwarding reasons

- **When unanswered**, **When busy**, and **When unavailable** can now be
  selected together instead of behaving like a single-choice list.
- The existing forward-to number is applied to every selected conditional
  reason.
- Activation and deactivation present each carrier code in a guided sequence,
  because cellular networks configure each condition independently.
- The app identifies the current reason and sequence position before each code
  is sent through the selected physical SIM.
- **All calls** remains mutually exclusive with the conditional reasons so it
  cannot silently override them.
- Existing 1.1.3 forwarding settings migrate automatically to the new
  multiple-selection format.

## Preserved behavior

- Physical-SIM selection, default-phone checks, permission checks, carrier-code
  confirmation, and phone-number normalization are unchanged.
- Google Voice and other internet-calling accounts remain excluded from the SIM
  selector. If Google Voice is configured as Android's call-redirecting app,
  set **Settings → Apps → Default apps → Call redirecting app → None** before
  changing carrier forwarding.

## Installation

Install version 1.1.4 directly over Maclean Phone 1.1.3. Do not uninstall first
if you want to retain SIP/VoIP and app settings. The package name and signing
identity are unchanged.

## Carrier limitation

Forwarding codes remain carrier-specific. Return to Maclean Phone after each
carrier response to send the next selected condition. A displayed code is not
proof of activation; confirm the carrier's response for every reason.
