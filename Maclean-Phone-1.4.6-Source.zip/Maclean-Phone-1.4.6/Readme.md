# Maclean Phone for Android

Maclean Phone is a phone app with sip/VoIP integration for Home and Business.
It combines an Android dialer with a local bilingual SIP/VoIP automated
directory. Incoming SIP calls can be answered on the phone, prompted to press
`1` for English or `2` for Russian, and routed using directory entries created
in Settings.

## Release signing

The user-supplied update keystore is included at
`signature/release.keystore`. Keep the source archive private. To create an
update-compatible signed release, provide these environment variables before
running `./gradlew assembleRelease`:

- `MACLEAN_RELEASE_STORE_FILE`
- `MACLEAN_RELEASE_STORE_PASSWORD`
- `MACLEAN_RELEASE_KEY_ALIAS`
- `MACLEAN_RELEASE_KEY_PASSWORD`

Without them, Gradle produces an unsigned release APK. Debug builds do not need
release-signing credentials.

## Included features

- Provider-neutral SIP registration using TLS, TCP, or UDP
- Automatic answering after a configurable delay
- Native Android ringing for SIP calls during the answer delay
- Looping ringtone for ordinary incoming SIM calls until answer, decline, or disconnect
- English and Russian prompts generated locally with Android text-to-speech
- Caller DTMF input using RFC 2833/telephone-event or SIP INFO
- Editable directory entries for digits `0`–`9` and `#`
- SIP transfer, repeat-menu, hang-up, timeout, retry, and fallback actions
- On-screen caller-menu simulator
- Foreground SIP service that restarts after reboot
- SIP password encryption using Android Keystore AES/GCM
- VoIP-only setup; becoming the default Android phone app is optional
- Grouped phone settings and working Android system-setting links
- All, missed, contacts, non-spam, and spam call-history filters
- Eligibility and guided setup for Android's Caller ID & spam role while
  leaving the outgoing Call redirecting role available for Google Voice
- Llama Local Caller Intelligence 1.0, using only contacts, the local blocked
  list, and on-device call history without uploading caller data
- Assisted dialing, theme selection, swipe-to-answer, caller announcement,
  flip-to-silence, and editable quick responses
- In-app ringtone, incoming-call vibration, missed-call sound, and missed-call
  vibration controls, plus a shortcut to Android's notification controls
- Manual-only in-call start/stop recording control with microphone-first audio,
  a speaker-assisted two-voice option, compatibility fallbacks, a consent
  reminder, and M4A storage; recording never begins automatically
- Three-second Speaker hold to choose a named Bluetooth, hearing, wired, USB,
  speaker, or phone audio endpoint
- Carrier group-call controls with separate **Add call** and **Merge calls**
  buttons, active/held call switching, conference-participant management, and
  capability-aware feedback from Android Telecom
- Incoming-call destination display that keeps the remote caller ID unchanged
  while separately showing the called Google Voice, SIP/VoIP, or personal line
  number and its calling-account label when Android Telecom supplies them
- SIP/VoIP forwarding to either a phone number or SIP destination
- Carrier voicemail number and incoming phone-number forwarding for all calls,
  busy, unanswered, or unavailable conditions, with direct physical-SIM code
  submission that does not take over Google Voice outgoing call redirection
- Light, dark, and system themes; selectable or custom accent/background colors;
  automatic or custom letter-and-word colors; clear or colored text windows with
  separate 1% through 100% opacity; square-through-rounded text-highlight
  corners; app-panel opacity from 1% through 100%; and user-selected background
  photos
- In-app accessibility and call-audio controls for TalkBack semantics, additional
  text scaling, large controls, high contrast, visual incoming-call alerts,
  caller announcements, Simplified Mode, SIP echo reduction, and preferred
  hearing-device routing
- In-app calling-account selection with system-default, ask-every-time, and
  specific physical-SIM choices, plus direct access to the SIP/VoIP account
- The supplied Maclean Of Duart ancient dress tartan as the default background

## Phone setup

1. Install the release APK.
2. Open Maclean Phone and choose **Use SIP IVR only**, or make it the default
   phone app if you also want its cellular dialer features. Android will ask
   separately before granting the Phone and Caller ID & spam roles. Maclean
   Phone does not request the outgoing Call redirecting role, so Google Voice
   can remain selected for that role.
3. Allow microphone and notification access. Android requires the microphone
   permission for VoIP audio even when the automated directory mutes the local
   microphone.
4. In Android text-to-speech settings, install English (United States) and
   Russian voices.
5. Open **Settings → Business IVR (SIP/VoIP)**.
6. Enter the SIP registration values supplied by the VoIP provider.
7. Create each directory entry with its digit, English and Russian labels, and
   transfer extension or SIP address.
8. Use **Test menu** to exercise the directory locally.
9. Tap **Save & start** and wait for
   **REGISTERED — Registered and ready for incoming calls**.
10. Remove battery restrictions for Maclean Phone so Android can keep the SIP
    line registered.

See [Provider setup](docs/PROVIDER_SETUP.md) for number forwarding and SIP
requirements.

## Branding

The supplied Maclean Phone artwork is used for the launcher, adaptive icon,
splash screen, onboarding, and store graphics. The supplied Maclean Of Duart
Enterprises Corp logo is shown in Settings with only its surrounding black
field removed. The supplied Maclean Of Duart ancient dress tartan is embedded
unchanged and is the default in-app background. All density variants can be
regenerated with:

```bash
python3 tools/generate_brand_assets.py
```

The source originals and transparent company logo are in `branding/`.

## Building

Requirements:

- JDK 17
- Android SDK 36 and Build Tools 36
- Gradle 9.4
- Python 3 with Pillow, NumPy, and SciPy only when regenerating artwork

Run:

```bash
./gradlew testDebugUnitTest lintRelease assembleRelease
```

Maclean Phone 1.4.4 uses the separate application ID
`com.macleanofduartenterprises.phone`, so it can coexist with the original app.
The installable APK is signed with the existing Maclean Phone update identity.
The included signing key is private production material and must not be shared.

## Operational notes

- One incoming IVR call is handled at a time. Additional calls receive a busy
  response and should follow the provider's overflow policy.
- Transfers use SIP REFER. The provider must allow REFER to the configured
  extension or destination. Forwarding a SIP call to a telephone number also
  requires the provider to permit PSTN breakout for that account.
- Carrier forwarding codes vary by carrier. Maclean Phone shows only physical
  cellular SIM accounts, asks for confirmation, and sends each configured code
  directly through the selected SIM using Android's subscription-bound
  telephony service. Conditional reasons can be selected together; the app
  presents each carrier code in sequence and displays the network response.
  Google Voice can remain the outgoing Call redirecting app. The carrier's
  response determines whether each condition is active.
- Third-party Android apps cannot directly capture both sides of ordinary
  cellular calls on every device. Maclean Phone records the microphone first;
  selecting **Use speaker & record both voices** lets that microphone hear the
  remote caller acoustically. Android or the phone manufacturer may still
  block concurrent capture. Confirm consent and applicable law before
  recording. Recording begins only after the user presses **Start recording**
  and confirms the consent reminder. Ending a call automatically stops and
  saves an active recording so its file is not damaged.
- Android does not expose ordinary cellular-modem noise processing to a
  third-party dialer. Maclean Phone's in-app noise and echo reduction switch
  controls its SIP/VoIP engine. Hearing-device preference is applied to calls
  when Android exposes a compatible communication device and route.
- Android 14 and later call-audio changes use Telecom's live call endpoints.
  Hold the in-call Speaker control for three seconds to choose an individual
  Bluetooth device, hearing device, wired output, phone earpiece, or speaker.
- Group calls use Android Telecom and the selected calling account. The carrier
  or VoIP connection service must permit a second call and expose conference
  capability before **Merge calls** is enabled. Emergency calls and some
  Google Voice, SIP, prepaid, roaming, or Wi-Fi calling routes may not support
  adding or merging calls. Maclean Phone never claims a merge succeeded until
  Telecom reports a conference.
- Incoming calls show the remote caller identity and the called line as separate
  values. Android Telecom supplies the line through the routed PhoneAccount.
  If a carrier or VoIP provider withholds its number, Maclean Phone identifies
  the calling account (for example, Google Voice) and states that the number was
  not provided instead of showing the caller's number as the destination.
- The Contacts tab is a password-free, on-device CRM. App-only records remain
  inside Maclean Phone; phone records are also written to Android Contacts.
  SIM storage is offered only when the device exposes a writable SIM account,
  and the SIM/provider decides which fields it can retain. Maclean CRM fields,
  photos, custom fields, and custom groups remain in the local CRM extension.
- The app needs Wi-Fi or mobile data and shows a persistent notification while
  the SIP line is active.
- SIP account details and directory settings remain on the phone. The password
  is encrypted with a non-exportable Android Keystore key and excluded from
  Android cloud backup.
- Registration, incoming audio, DTMF, and transfers must be tested against the
  selected provider before production use.

## Licensing

Maclean Phone is distributed under the GNU Affero General Public License,
version 3. The complete text is bundled in the application under
**Settings → Legal → License** and is included in the source as
[LICENSE-AGPL-3.0.txt](LICENSE-AGPL-3.0.txt).

Maclean Phone is derived from the Amadz Android dialer, whose Apache License
2.0 terms remain in [LICENSE.txt](LICENSE.txt). This application also links the
GPL-3.0 Linphone SDK. Those components retain their applicable notices and
license terms. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and
[COPYING.GPL-3.0](COPYING.GPL-3.0).
