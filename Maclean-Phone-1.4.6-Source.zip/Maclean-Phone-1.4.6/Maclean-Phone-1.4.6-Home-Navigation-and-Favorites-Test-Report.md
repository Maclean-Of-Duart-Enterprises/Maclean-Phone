# Maclean Phone 1.4.6 Home Navigation and Favorites Test Report

Test date: 2026-10-01

## Automated results

| Area | Result | Evidence |
|---|---|---|
| Full unit/Robolectric suite | Pass | 73 tests; 0 failures, errors, or skips |
| Visible bottom destinations | Pass | Route test requires exactly `Contacts`, then `Recents` |
| Favorites bottom page removed | Pass | Route test rejects `FavouritesKey` from the visible home routes |
| Contacts-first ordering | Pass | Route keys are required in `ContactsKey`, `RecentsKey` order |
| Contacts opening preference | Pass | Policy test resolves Contacts regardless of previous tab |
| Recents opening preference | Pass | Policy test resolves Recents regardless of previous tab |
| Last-used opening preference | Pass | Policy test restores either remembered home tab |
| CRM Favorites persistence/filter | Pass | Repository test saves a favorite, filters to it, removes the star, and confirms the filter becomes empty |
| Full release lint | Pass | 0 errors, 62 warnings, 1 hint |

## Code-path verification

- The bottom-bar model exposes only Contacts and Recents, in that order.
- Contacts has a directly wired Settings button with an accessibility content description.
- The Contacts filter row exposes All, Favorites, and every custom group.
- Selecting Favorites clears the group filter while preserving search and sort behavior.
- Selecting All or a group exits Favorites filtering.
- The repository applies Favorites filtering to its combined CRM/linked-Android result using the existing persisted CRM favorite value.
- Toggling a favorite performs the database update off the main thread, reloads the list only after success, and reports failures through the existing snackbar path.
- The selected default opening page is stored persistently. Navigation to Contacts or Recents updates the remembered tab; Settings and detail pages do not.
- The default remains Recents for users who have never selected an opening preference.
- The VoIP-only first-run configuration guard remains higher priority than the normal opening-page preference so required setup is not bypassed.

## Physical-device acceptance checklist

No device or emulator was attached. Complete these short checks on the target phone before broad deployment:

1. Install 1.4.6 directly over the correctly signed 1.4.5 app without uninstalling it. Confirm CRM contacts, custom groups, call history, preferences, SIP/VoIP configuration, and photos remain present.
2. Confirm the bottom bar shows **Contacts** on the left and **Recents** on the right, with no separate Favorites page.
3. Open Contacts, tap the Settings gear, and confirm the main Settings page opens and Back returns to Contacts.
4. Star an app-stored CRM contact and an Android-linked contact. Confirm both appear under the Contacts **Favorites** filter after leaving and reopening the app.
5. While viewing Favorites, remove a star. Confirm the contact disappears immediately without being deleted from All or from Android Contacts.
6. Set each **Default opening page** value in turn, fully close/reopen the app, and verify Contacts, Recents, and Last used behave as labeled.
7. With **Last used** selected, leave the app from Contacts and Recents in turn. Open Settings before closing once and confirm Settings does not replace the remembered home page.
8. Recheck a carrier/Google Voice/VoIP call and the speaker/Bluetooth controls to confirm the navigation-only update did not regress existing call behavior.
