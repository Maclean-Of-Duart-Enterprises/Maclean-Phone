# Maclean Phone 1.3.1

## Google Voice and incoming-forwarding correction

- Removed Maclean Phone's outgoing `CallRedirectionService`, Android
  Call redirecting role request, onboarding prompt, and settings control.
- Google Voice can now remain Android's default **Call redirecting app** for
  outbound Google Voice carrier calls.
- Maclean Phone remains eligible for the separate **Phone app** and
  **Caller ID & spam app** roles.

## Direct physical-SIM forwarding

- Preserved incoming carrier forwarding for all calls, unanswered, busy, and
  unavailable conditions, including multiple conditional selections.
- Carrier forwarding codes are now sent directly through the chosen physical
  SIM with Android's subscription-bound telephony API instead of being placed
  as outgoing Telecom calls.
- Direct SIM submission does not take over or change Google Voice's outgoing
  redirection role.
- Added carrier response and failure reporting, sequential confirmation for
  multiple forwarding conditions, and a carrier-settings fallback.
- Renamed the controls to **Voicemail & incoming forwarding** and added clear
  Google Voice compatibility guidance.

## Compatibility

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version code is 10 and version name is 1.3.1.
- The release APK uses the same Maclean Phone update certificate as versions
  1.2.1 and 1.3.0.
