#!/usr/bin/env python3
"""Build the Maclean Phone Android artwork from the supplied brand originals."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps
from scipy import ndimage


ROOT = Path(__file__).resolve().parents[1]
BRANDING = ROOT / "branding"
RES = ROOT / "app" / "src" / "main" / "res"
FASTLANE_IMAGES = ROOT / "fastlane" / "metadata" / "android" / "en-US" / "images"

COMPANY_LOGO_SOURCE = BRANDING / "company-logo-original.jpg"
PHONE_ART_SOURCE = BRANDING / "maclean-phone-artwork-original.jpg"

LANCZOS = Image.Resampling.LANCZOS
PINE = (19, 61, 43, 255)
SKY_BLUE = (185, 220, 241, 255)
GOLD = (213, 171, 70, 255)
CREAM = (249, 242, 220, 255)


def save_png(image: Image.Image, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    image.save(destination, format="PNG", optimize=True)


def extract_company_logo() -> Image.Image:
    """Remove only the connected exterior black field from the supplied JPEG."""
    source = Image.open(COMPANY_LOGO_SOURCE).convert("RGB")
    rgb = np.asarray(source)
    pad = 24
    padded = np.pad(rgb, ((pad, pad), (pad, pad), (0, 0)), constant_values=0)

    # The pale-blue diamond and gold border form the largest connected area that
    # is distinct from the black field. Filling its holes retains every dark
    # letter and crest detail rather than treating those pixels as background.
    bright = padded.max(axis=2) > 24
    labels, count = ndimage.label(bright)
    if count == 0:
        raise RuntimeError("No foreground component found in company logo")
    sizes = np.bincount(labels.ravel())
    sizes[0] = 0
    diamond = labels == int(sizes.argmax())
    diamond = ndimage.binary_fill_holes(diamond)

    # Preserve the opaque interior and recover a soft antialiased outer edge.
    core = ndimage.binary_erosion(diamond, iterations=1)
    edge_zone = ndimage.binary_dilation(diamond, iterations=2)
    intensity = padded.max(axis=2).astype(np.float32)
    edge_alpha = np.clip((intensity - 2.0) / 90.0, 0.0, 1.0) * 255.0
    alpha = np.where(core, 255.0, np.where(edge_zone, edge_alpha, 0.0)).astype(np.uint8)

    rgba = np.dstack((padded, alpha))
    return Image.fromarray(rgba, mode="RGBA")


def round_icon(source: Image.Image, size: int) -> Image.Image:
    icon = source.resize((size, size), LANCZOS).convert("RGBA")
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
    icon.putalpha(mask)
    return icon


def notification_icon(size: int = 96) -> Image.Image:
    """Create the required one-color Android notification glyph."""
    scale = 4
    canvas_size = size * scale
    image = Image.new("RGBA", (canvas_size, canvas_size), (255, 255, 255, 0))
    draw = ImageDraw.Draw(image)
    white = (255, 255, 255, 255)

    def arc(box: tuple[int, int, int, int], start: int, end: int, width: int) -> None:
        scaled = tuple(value * scale for value in box)
        draw.arc(scaled, start=start, end=end, fill=white, width=width * scale)

    # Horizontal handset above three downward signal waves.
    arc((17, 10, 79, 50), 198, 342, 9)
    arc((35, 32, 61, 53), 20, 160, 5)
    arc((27, 38, 69, 68), 20, 160, 6)
    arc((18, 44, 78, 84), 20, 160, 7)
    return image.resize((size, size), LANCZOS)


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf" if bold
        else "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSerif-Bold.ttf" if bold
        else "/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size=size)
    return ImageFont.load_default()


def feature_graphic(phone_art: Image.Image, icon: Image.Image) -> Image.Image:
    width, height = 1024, 500
    # A text-free strip at the left edge of the supplied artwork supplies the
    # authentic tartan texture without re-drawing the clan pattern.
    tartan_strip = phone_art.crop((0, 180, 300, 1360)).convert("RGB")
    tile = ImageOps.fit(tartan_strip, (256, height), method=LANCZOS)
    background = Image.new("RGB", (width, height))
    for index, x in enumerate(range(0, width, 256)):
        part = ImageOps.mirror(tile) if index % 2 else tile
        background.paste(part, (x, 0))
    background = background.filter(ImageFilter.GaussianBlur(radius=1.2)).convert("RGBA")
    background = Image.alpha_composite(
        background,
        Image.new("RGBA", (width, height), (9, 43, 30, 150)),
    )

    draw = ImageDraw.Draw(background)
    card_box = (64, 72, 420, 428)
    draw.rounded_rectangle(card_box, radius=64, fill=(245, 249, 252, 242), outline=GOLD, width=5)
    app_icon = icon.resize((324, 324), LANCZOS)
    background.alpha_composite(app_icon, (80, 88))

    title_font = load_font(62, bold=True)
    body_font = load_font(28)
    draw.text((470, 138), "Maclean Phone", font=title_font, fill=CREAM)
    draw.line((472, 220, 930, 220), fill=GOLD, width=4)
    draw.multiline_text(
        (474, 252),
        "Phone app with sip/VoIP integration\nfor Home and Business.",
        font=body_font,
        fill=(229, 239, 234, 255),
        spacing=12,
    )
    return background.convert("RGB")


def main() -> None:
    if not COMPANY_LOGO_SOURCE.exists() or not PHONE_ART_SOURCE.exists():
        raise FileNotFoundError("Place both supplied originals in branding/ before running")

    company_logo = extract_company_logo()
    phone_art = ImageOps.fit(Image.open(PHONE_ART_SOURCE).convert("RGB"), (1536, 1536), method=LANCZOS)
    phone_rgba = phone_art.convert("RGBA")

    save_png(company_logo, BRANDING / "company-logo-transparent.png")
    save_png(company_logo, RES / "drawable-nodpi" / "company_logo.png")
    save_png(company_logo, RES / "drawable-nodpi" / "app_logo_long.png")
    # The original app's onboarding artwork referenced app_logo_short. Keep that
    # resource name for compatibility, but replace its content with the exact
    # transparent company logo requested by the user.
    save_png(company_logo, RES / "drawable-nodpi" / "app_logo_short.png")
    save_png(notification_icon(), RES / "drawable-nodpi" / "app_logo_short_notification.png")

    densities = {
        "mipmap-mdpi": (48, 108),
        "mipmap-hdpi": (72, 162),
        "mipmap-xhdpi": (96, 216),
        "mipmap-xxhdpi": (144, 324),
        "mipmap-xxxhdpi": (192, 432),
    }
    for directory_name, (legacy_size, foreground_size) in densities.items():
        directory = RES / directory_name
        directory.mkdir(parents=True, exist_ok=True)
        for old_name in ("ic_launcher.webp", "ic_launcher_round.webp", "ic_launcher_foreground.webp"):
            (directory / old_name).unlink(missing_ok=True)
        save_png(phone_rgba.resize((legacy_size, legacy_size), LANCZOS), directory / "ic_launcher.png")
        save_png(round_icon(phone_rgba, legacy_size), directory / "ic_launcher_round.png")
        # Android masks the adaptive foreground. Keeping the full supplied art
        # places its phone button in the standard 66/108 safe zone.
        save_png(
            phone_rgba.resize((foreground_size, foreground_size), LANCZOS),
            directory / "ic_launcher_foreground.png",
        )

    store_icon = phone_rgba.resize((512, 512), LANCZOS)
    save_png(store_icon, ROOT / "app" / "src" / "main" / "ic_launcher-playstore.png")
    save_png(store_icon, FASTLANE_IMAGES / "icon.png")
    save_png(feature_graphic(phone_art, store_icon), FASTLANE_IMAGES / "featureGraphic.png")


if __name__ == "__main__":
    main()
