# Maclean Phone 1.3.0

## Android call roles

- Added a system-bound `CallScreeningService`, making Maclean Phone eligible
  for Android's **Caller ID & spam app** role.
- Added a system-bound `CallRedirectionService`, making Maclean Phone eligible
  for Android's **Call redirecting app** role.
- Added guided role requests during full-phone onboarding and role controls in
  **Settings → Call Assist**. Android always requires the device owner to
  confirm each default role.
- Outgoing calls remain unchanged unless Assisted dialing safely formats a
  local number. Carrier conditional forwarding remains separate.

## Llama Local caller assistant

- Added **Llama Local Caller Intelligence 1.0**, a compact on-device risk model
  for incoming caller identification and spam assistance.
- The model uses only the phone's contacts, Maclean Phone blocked list, and
  local call history. It performs no network request and uploads no caller data.
- Saved contacts and previously connected callers receive trusted labels;
  blocked, Android-labeled spam, anonymous, and repeated unanswered callers are
  evaluated conservatively.
- Unknown callers are not automatically blocked. Optional auto-silence applies
  only to a local risk score of 80 or higher.
- Llama Local labels now appear in incoming-call notifications and on the
  in-call screen.

## Three-second call audio chooser

- A normal Speaker tap still toggles the speaker.
- Pressing and holding Speaker for three seconds opens an interactive list of
  currently available phone, speaker, wired, USB, hearing, and Bluetooth audio
  endpoints.
- On Android 12 and later, individual Bluetooth product names are shown when
  the device exposes them.

## Call recording audibility

- Changed the first recording source from `VOICE_COMMUNICATION`, which can
  create silent recordings on some devices, to the microphone.
- Added microphone compatibility fallbacks and higher-quality mono AAC output.
- Added a **Use speaker & record both voices** choice. This lets the microphone
  hear both the local speaker and the remote caller acoustically where Android
  blocks direct cellular downlink capture.
- The active capture method is shown while recording and after saving.

## Editable text-highlight shape

- Added a 0–32 dp text-highlight corner slider.
- Added Square, Soft, and Rounded presets.
- Replaced the fixed square typography background with a shaped app-wide text
  window so the setting is visible throughout Maclean Phone.

## Compatibility

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version code is 9 and version name is 1.3.0.
- The release APK is signed with the same Maclean Phone certificate as the
  supplied 1.2.1 APK, so it can install as an in-place update.
