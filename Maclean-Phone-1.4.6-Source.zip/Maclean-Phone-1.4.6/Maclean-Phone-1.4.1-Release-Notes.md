# Maclean Phone 1.4.1 Release Notes

Release date: 2026-08-27

Maclean Phone 1.4.1 is a corrective release focused on completing the Contacts/CRM experience, repairing VCF import and export, and preserving the working telephone, SIP/VoIP, caller ID, voicemail, forwarding, appearance, accessibility, Google Voice, and call-audio features from 1.4.0.

## Release identity

- Application ID: `com.macleanofduartenterprises.phone`
- Version name: `1.4.1`
- Version code: `12` (1.4.0 used code 11)
- Minimum Android SDK: 26
- Target Android SDK: 36
- Universal APK architectures: `arm64-v8a`, `armeabi-v7a`, `x86`, and `x86_64`
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- APK SHA-256: `441f24282af1e86a514527c617cb28a02a84f96710561839ef998cf4469352f8`

## Contacts and CRM corrections

- Completed individual edit, delete, duplicate/copy, VCF export, secure VCF sharing, favorite, group membership, photo, call, message, and email actions.
- Added long-press bulk selection using stable namespaced contact IDs, selected count, Select All, and immediate list refresh after successful operations.
- Completed bulk delete, duplicate/copy, export, share, storage copy, add/remove groups, and merge actions with per-item failure reporting.
- Repaired local, Android, and writable-SIM identity handling. Local CRM IDs, Android Contact IDs, and Android RawContact IDs are now treated as separate identities.
- Local CRM remains usable when Android Contacts permission is denied. Android and SIM actions clearly report permission, read-only, or device limitations.
- Contact and group changes use database transactions. Contact fields, memberships, and owned photos cascade or clean up without leaving orphans.
- Added a non-destructive CRM schema migration from version 1 to version 2. Existing data is retained while favorite/read-only state and identity integrity are added.
- Completed persistent group creation, rename, deletion, reorder, membership editing, bulk membership changes, export, and sharing. Deleting a group removes only memberships, never contacts.
- Search covers names, phones, email, company, notes, CRM fields, representative, action, birthday, and other useful fields. Sorting is persistent.
- Unicode data is retained, including English, Spanish, Russian, international numbers, and emoji.
- Large imports, exports, copies, deletes, group operations, and merges run away from the main UI thread.

## VCF import, export, and sharing

- Replaced the incomplete VCF path with a UTF-8 vCard 3.0 reader/writer.
- Added Save As export for one contact, selected contacts, a group, the current filtered result, or all contacts.
- Export preserves supported names, phone numbers and country codes, email, postal addresses, fax, websites, company, birthday, notes, groups, photos, favorite state, labels, Unicode, emoji, and Maclean CRM extension fields.
- Fixed the import crash shown as `ContentValues.keySet() on a null object reference` by always supplying both Android RawContact account keys, including for local phone accounts.
- Fixed Base64 photo parsing so padding ending in `=` cannot consume the following `END:VCARD` line.
- Added 75-octet line folding that does not split multibyte Unicode characters.
- Sharing now uses a private Android FileProvider and temporary read-only `content://` access instead of exposing file paths.

## Duplicate and merge corrections

- Duplicate candidates use normalized phone numbers, normalized email addresses, and exact normalized names.
- Similar-looking names alone are never merged automatically.
- Merge retains unique fields, groups, photos, notes, company data, and favorite state while removing exact duplicates.
- The merged contact is saved successfully before any source contact is deleted. Source deletion failures are reported instead of being hidden.

## Phone and app-wide audit corrections

- Preserved short-press speaker routing and the three-second speaker-button hold that opens the available phone, speaker, wired, hearing-aid, and individual Bluetooth endpoint list.
- Preserved Android 14+ CallEndpoint routing and the compatible legacy routing path for older supported Android versions.
- Preserved microphone-first call recording policy and compatible alternate sources; the in-call speaker option remains available to improve both-side capture where Android/device policy permits it.
- Preserved Google Voice as a separate call-redirection role so Maclean Phone can remain the phone app without impersonating Google Voice's carrier-routing role.
- Corrected pre-Android-10 call-log filtering so it does not query an Android 10-only block-reason column.
- Corrected system-settings launch fallback behavior on devices affected by package-visibility checks.
- Added a fail-safe timeout to the proximity-screen wake lock while retaining immediate normal lifecycle release.
- Removed/repaired identified placeholder or dead Contacts controls; operation success is shown only after the repository reports completion.

## Upgrade behavior

This APK is built with the same application ID and signing certificate and a higher version code, so Android can install it directly over the matching signed 1.4.0 release. The CRM database migration is non-destructive; no destructive migration or uninstall step is used.

Back up important contacts before any app upgrade. Android account providers and SIM implementations can impose their own write restrictions. Call recording and audio routing also remain subject to Android version, handset firmware, carrier policy, active endpoints, and local law.

## Verification summary

- Release build: passed
- APK signature and alignment: passed
- Automated tests: 46 passed, 0 failed, 0 skipped
- Release lint: 0 errors; 59 non-blocking warnings and 1 hint
- Physical-device carrier/SIM/Bluetooth/Google Voice execution: not available in the build environment; see the build and test reports for the required device acceptance checks
