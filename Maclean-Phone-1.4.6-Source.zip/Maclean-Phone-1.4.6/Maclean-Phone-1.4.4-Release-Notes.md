# Maclean Phone 1.4.4 Release Notes

Release date: 2026-09-21

## Incoming called-number display

- Added a dedicated **Called number** panel for incoming calls. The existing
  caller name, caller number, contact lookup, and Llama Local caller assessment
  remain unchanged above it.
- The called number is resolved from the exact Android Telecom `PhoneAccount`
  routing the call. This distinguishes personal SIM, Google Voice, and
  compatible SIP/VoIP lines without confusing the remote caller number with the
  receiving number.
- Added the calling-account label beneath the called number so similarly named
  lines and providers are easier to distinguish.
- Preserved the receiving-line display after an incoming call is answered or
  placed on hold. Its direction is captured when Telecom first adds the call,
  rather than inferred only from the current ringing state.
- Added called-line context to the incoming-call notification without replacing
  its existing caller identity.
- Added a graceful fallback when a provider withholds its number: Maclean Phone
  identifies the routed calling account and clearly says that the number was
  not provided. It never substitutes the caller's number as the destination.

## Compatibility and preservation

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version is `1.4.4` with version code `15`.
- Signed with the existing Maclean Phone release identity, allowing an in-place
  update from a correctly signed 1.4.3 installation without clearing app data.
- No CRM database schema or migration changed; contacts, groups, preferences,
  custom fields, photos, and other app data remain intact during upgrade.
- Existing calling, group calling, Google Voice redirection compatibility,
  SIP/VoIP, caller ID, Llama Local, voicemail, forwarding, recording, audio
  routing, accessibility, appearance, Contacts/CRM, and AGPLv3 license features
  are retained.

## Provider limitation

Android Telecom controls which receiving-line metadata a carrier or VoIP
connection service exposes. Maclean Phone checks the account's display
subscription address and account address, then shows its account/provider label
as a fallback. A third-party dialer cannot recover a number that the active
connection service does not publish to Android Telecom.
