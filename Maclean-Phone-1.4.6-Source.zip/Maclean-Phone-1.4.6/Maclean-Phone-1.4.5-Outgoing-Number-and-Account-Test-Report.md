# Maclean Phone 1.4.5 Outgoing Number and Account Test Report

Test date: 2026-09-22

## Automated results

| Area | Result | Evidence |
|---|---|---|
| Full unit/workflow suite | Pass | 68 tests; 0 failures, errors, or skips |
| Multi-number normalization | Pass | Blank and formatting-only duplicates are removed; distinct international numbers remain |
| Primary/label retention | Pass | Primary choice is ordered first and useful Unicode/emoji labels are retained |
| Account identity | Pass | Provider component plus handle ID prevents cross-provider ID collisions |
| Specific-account routing policy | Pass | Exact enabled registered account is selected |
| Missing-account handling | Pass | Falls back to an explicit chooser |
| 1.4.4 preference migration | Pass | Legacy `SPECIFIC_SIM` ID migrates to the stable account key |
| Outgoing display policy | Pass | Number and provider form a separate `From … via …` summary |
| Release lint | Pass | 0 errors, 58 warnings, 1 hint |

## Code-path verification

- Android Contacts queries load all phone rows, system/custom labels, and primary status instead of retaining only one number.
- CRM phone fields become labeled destination options, including separate international dial-code composition.
- Contacts, Favorites, frequent-contact lookup, and search receive the complete number list.
- Raw keypad calls and Recent redials retain their exact entered or historical destination.
- `Ask every time` always includes **Phone / system default**, even when no separate account is readable.
- Only enabled accounts from Android Telecom's call-capable account list that advertise `tel` support are presented.
- A selected account is passed with `TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE`.
- Account preferences store a collision-safe provider component plus handle ID.
- Incoming **Called number**, outgoing **Calling from**, and the remote caller/callee identity remain separate.
- Group-call **Add call** continues to use the account that owns the live call so existing merge behavior is preserved.

## Physical-device acceptance tests still required

No device or emulator was attached. Run these checks on the target phone before broad deployment:

1. Install 1.4.5 over the correctly signed 1.4.4 APK and verify CRM contacts, groups, preferences, voicemail, and SIP settings remain intact.
2. Create a contact with Mobile, Work, Spanish, Russian, emoji, and international-number fields. Call it from Contacts, Favorites, and search and verify every labeled destination is offered.
3. Select **Phone / system default**, place a carrier call, and compare **Calling from** with the active line Android reports.
4. Select **Ask every time**, choose each visible SIM/account, and verify that account owns the Telecom call.
5. Configure Google Voice as Android's call-redirection app, select the system route, and test Google Voice's own ask-each-call, Voice-only, and carrier policies. If Google Voice registers a direct calling account, verify it also appears separately.
6. Configure a third-party VoIP app that registers a telephone-capable `PhoneAccount`; select it and verify identity and audio.
7. Deny `READ_PHONE_NUMBERS`; verify calls and local CRM remain usable and withheld numbers are reported honestly. Grant it and refresh accounts; verify exposed addresses appear.
8. Background an outgoing call and verify both the in-call panel and notification retain the calling-from identity without changing the callee/caller-ID display.
9. Use **Add call** and **Merge calls** on a supported carrier and confirm the second leg stays on the live account.

## Platform boundary

Maclean Phone can select only identities Android exposes as enabled telephone-capable `PhoneAccount`s. Android call redirection may change the destination or account after submission, and a provider may withhold its public number. The app reports the account metadata Android supplies; it does not invent or guarantee outbound caller ID.

