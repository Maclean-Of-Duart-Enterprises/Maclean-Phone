# SIP provider and existing-number setup

The app answers calls delivered to its SIP account. A normal cellular call
forwarded directly to the phone's SIM cannot expose caller DTMF to a third-party
Android app, so the public number must ultimately terminate at a SIP/VoIP
provider.

## Required provider capabilities

Ask the provider to confirm all of the following:

| Capability | Required setting |
|---|---|
| SIP registration | Username/password registration from an Android endpoint |
| Incoming audio | G.711 µ-law or A-law is the safest baseline |
| DTMF | RFC 2833 / RTP `telephone-event`; SIP INFO can also be enabled |
| Transfers | SIP REFER to local extensions or permitted external destinations |
| Concurrent calls | One app call, with provider-side busy/overflow handling |
| NAT keepalive | Provider-supported registration and keepalive over mobile/Wi-Fi |

TLS on port `5061` is the recommended starting point. Use TCP or UDP on port
`5060` only when the provider requires it.

## Forward an existing number

There are two common arrangements:

1. **Port the number to the SIP provider.** The provider sends incoming calls
   directly to the SIP account registered by Maclean Phone.
2. **Keep the current carrier number.** Buy a DID from the SIP provider, then
   configure unconditional, after-hours, or no-answer forwarding from the
   existing carrier number to that DID.

Forward to the provider's public telephone number (DID), not directly to an
unreachable private SIP extension. Carrier forwarding charges may apply.

## Values to collect

Before configuring the app, obtain:

- SIP registrar/server hostname
- SIP domain, if different from the registrar
- TLS/TCP/UDP transport and port
- SIP username or extension
- Authorization username, if different
- SIP password
- Outbound proxy, if required
- Valid transfer extensions or full SIP addresses

Do not send credentials through chat or place them in source code. Enter them
directly on the phone.

## Acceptance test

1. Start the IVR and confirm **REGISTERED**.
2. Call the SIP DID from an unrelated phone.
3. Confirm the call answers and both language prompts play.
4. Press `1`, then each English directory digit.
5. Repeat with `2` for Russian.
6. Verify transfers connect with two-way audio.
7. Test `*`, invalid input, no input, fallback, and hang-up behavior.
8. Turn off the screen and repeat over Wi-Fi and mobile data.
9. Reboot the Android phone and confirm registration returns.
10. Confirm the provider's overflow rule handles a second simultaneous call.

If digits are not detected, set the provider to RFC 2833/`telephone-event` and
disable in-band-only DTMF. If transfers fail, ask the provider to enable SIP
REFER for the account and verify the destination format it expects.
