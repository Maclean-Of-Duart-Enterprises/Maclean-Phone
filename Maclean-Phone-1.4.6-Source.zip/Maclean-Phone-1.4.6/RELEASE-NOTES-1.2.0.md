# Maclean Phone 1.2.0

## Accessibility and call audio

- Added an in-app **Accessibility & audio** page.
- Added TalkBack labels, roles, headings, live call-state announcements, keypad
  letter announcements, and recording-state announcements.
- Added app-level text scaling from 100% to 200%, in addition to Android's
  system font size.
- Added **Large controls**, including larger keypad and primary call controls.
- Added **High contrast** with opaque panels and stronger light/dark contrast.
- Added opt-in visual incoming-call alerts.
- Added caller announcements using a saved contact name when available, with
  **Never**, **Headset only**, and **Always** choices.
- Added **Simplified Mode** with large Favorites, Keypad, Recent calls,
  Voicemail, and Settings actions.
- Added an in-app SIP/VoIP noise and echo reduction switch.
- Added an in-app **Prefer hearing aid** option that routes call audio to a
  compatible hearing device when Android exposes one.

## Calling accounts

- Added an in-app **Calling accounts** page.
- Outgoing calls can use Android's system default, ask for a SIM every time, or
  use a selected physical SIM.
- The page also shows SIP/VoIP registration status and opens the SIP account
  setup directly.
- Calls received through Android dial intents now honor the same in-app calling
  account choice.

## Color and background

- Panel opacity now covers the complete **1% through 100%** range in one-percent
  increments.

## Platform limits

- Android does not expose cellular-modem noise processing to third-party dialer
  apps. The in-app noise and echo reduction switch therefore controls Maclean
  Phone's SIP/VoIP engine; cellular noise processing remains device-managed.
- Hearing-device routing is requested by Maclean Phone, but the connected
  device and available call route are ultimately exposed and enforced by
  Android and the phone hardware.

## Installation

Install version 1.2.0 directly over Maclean Phone 1.1.4. Do not uninstall first
if you want to retain SIP/VoIP, calling-account, appearance, and phone settings.
The package name and signing identity are unchanged.
