# Maclean Phone 1.4.5 Build Verification Report

Build date: 2026-09-22

## Release identity

| Property | Verified value |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version name | `1.4.5` |
| Version code | `16` |
| Minimum SDK | `26` |
| Target / compile SDK | `36` / `36` |
| APK type | Universal |
| Packaged ABIs | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |
| APK size | 173,798,582 bytes |
| APK SHA-256 | `7bc05f9668335f51de3173dbe4cf174ab282ee6cf451afbc108e85e2800d7797` |

## Build environment and tasks

- Eclipse Temurin JDK 21.0.12.1
- Gradle 9.4.0
- Android SDK Platform 36 / Build Tools 36.0.0
- `testDebugUnitTest`: passed — 68 tests, 0 failures, 0 errors, 0 skipped
- `lintRelease`: passed — 0 errors, 58 warnings, 1 hint
- `assembleRelease`: passed

The remaining lint findings are non-blocking inherited API/deprecation, manifest-merge, resource, and dependency-modernization guidance. No lint baseline or error suppression was added to make this build pass.

## APK verification

- `aapt dump badging` confirms the package, version, minimum SDK, target SDK, and `CALL_PHONE`, `READ_PHONE_STATE`, and `READ_PHONE_NUMBERS` declarations.
- `apksigner verify --verbose --print-certs` passes with one APK Signature Scheme v2 signer.
- Signer subject: `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises`
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- `zipalign -c -P 16 -v 4` reports verification successful.
- Universal native libraries are present for all four declared ABIs.

The unchanged application ID, increased version code, and existing signer meet Android's package-level requirements for an in-place update over the correctly signed 1.4.4 release.

## Upgrade and data-integrity review

- No destructive database migration was introduced.
- CRM schema, contact IDs, groups, photos, custom fields, and memberships are unchanged.
- Calling-account preference loading explicitly migrates the 1.4.4 `SPECIFIC_SIM` value and legacy account ID.
- A missing or ambiguous migrated account opens the chooser instead of silently falling back to an unintended provider.
- Existing incoming called-number state and caller ID are separate from the new outgoing calling-from state.

## Verification boundary

Static review, JVM/Robolectric workflow tests, lint, signed packaging, package metadata, certificate, ABI, permission, and alignment checks were completed. `adb devices` reported no attached device, so installation over a populated 1.4.4 device and live carrier, Google Voice, Bluetooth, and third-party VoIP behavior were not falsely marked as passed.

