# Maclean Phone 1.1.2

## Changes

- Call recording is manual-only. It can start only after the user presses
  **Start recording** during an active or held call and confirms the consent
  reminder.
- The same in-call control changes to **Stop recording**, allowing the user to
  finish and save the recording at any time.
- Ending a call safely stops and saves an active recording, but no call event,
  answer event, app launch, or setting can start recording automatically.
- The launcher, round, adaptive, splash, and store icons now use the supplied
  text-free tartan phone photograph.
- The full-color icon remains in use even when the device enables themed app
  icons, preserving the supplied photograph rather than substituting a
  monochrome launcher mark.

## Installation

Install version 1.1.2 directly over Maclean Phone 1.1.1. The package name and
release-signing identity are unchanged, so existing SIP/VoIP and app settings
should remain.

## Call-recording limitation

Android may block call-audio capture or record only the local microphone on
some devices and call paths. Obtain consent from everyone on the call and
follow applicable law before manually starting a recording.
