# Maclean Phone 1.2.1

## Letter and word colors

- Added an app-wide **Letter and word color** setting.
- Added black, white, Maclean green, dress blue, tartan red, heritage gold, and
  silver palette choices.
- Added a custom hexadecimal color field for manually entering any desired text
  color.
- Added an **Automatic** option that continues to follow the selected light,
  dark, or system theme.

## Text windows

- Added optional colored windows directly behind standard app text.
- Added **Clear** and **Colored** text-window choices.
- Added warm white, black, pale blue, pale green, soft gold, and charcoal
  text-window palette choices.
- Added a custom hexadecimal color field for manually entering any desired
  text-window color.
- Added a separate text-window opacity slider covering every whole percentage
  from **1% through 100%**.
- High Contrast mode continues to use its protected automatic colors while it
  is enabled.

## Compatibility and installation

- Existing appearance settings remain compatible and keep their saved values.
- The application ID remains `com.macleanofduartenterprises.phone`.
- To install directly over version 1.2.0 without losing settings, the release
  APK must be signed with the same private Maclean Phone release key used for
  version 1.2.0.
