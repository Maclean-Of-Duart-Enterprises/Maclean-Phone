# Maclean Phone

Maclean Phone is an AGPLv3 Android dialer and CRM from Maclean of Duart Enterprises.

Version 1.4.6 consolidates Favorites into CRM Contacts, places Contacts before Recents in the bottom navigation, adds Contacts-page Settings access, and adds a persistent default-opening-page choice for Contacts, Recents, or the last-used page. The application ID remains `com.macleanofduartenterprises.phone`.

See `Maclean-Phone-1.4.6-Release-Notes.md` and the verification reports included with the release for details and device-test boundaries.
