# Maclean Phone 1.4.4 Incoming Called-Number Test Report

Test date: 2026-09-21

## Automated results

The full unit suite passed with 60 tests and no failures. Six focused tests were
added for the incoming called-line policy.

| Scenario | Expected behavior | Result |
|---|---|---|
| Subscription and account addresses both exist | Use the display subscription address | Passed |
| Subscription address is blank | Fall back to the PhoneAccount address | Passed |
| Account label duplicates the number | Do not render duplicate information | Passed |
| Number and provider are available | Preserve both as separate called-line metadata | Passed |
| Provider withholds the number | Show the provider/account label without inventing a number | Passed |
| No destination metadata exists | Return an unknown destination and never reuse caller ID | Passed |

## Wiring and regression review

| Area | Verification |
|---|---|
| Incoming direction | Captured when Telecom adds the call and retained after answer/hold |
| Number source | Uses the routed call's `accountHandle` and matching `PhoneAccount` only |
| Resolution order | Display subscription address, account address, then account/provider label fallback |
| Caller ID preservation | Existing remote `Call.Details.handle` / gateway extraction is unchanged |
| Contact and Llama lookup | Existing foreground caller-number flow is unchanged |
| Call screen | Separate **Called number** panel is shown for calls that originated as incoming |
| Missing provider data | Shows “Not provided by this calling account” and any available account label |
| Notification | Appends called-line context while preserving the existing caller title and number |
| Multiple calls | Destination metadata follows the foreground call's stable call identity |
| Permissions | Missing Phone-state access fails safely to the connection-service app label |
| Existing suite | CRM, VCF, merge, group-call, recording, IVR, appearance, and license tests passed |

## Physical-device acceptance procedure

1. Install 1.4.4 directly over the correctly signed 1.4.3 release and confirm
   existing contacts, groups, settings, and call history remain available.
2. Call the personal cellular number. Confirm the remote caller name/number is
   unchanged and the new panel shows the receiving personal line separately.
3. Call the Google Voice number. Confirm the panel shows that number and its
   Google Voice/Voice account label when Google Voice publishes both values.
4. Call each configured SIP/VoIP number. Confirm its published account address
   and provider label are shown separately from the caller.
5. Answer each incoming call and confirm its receiving line remains visible
   during the active call and on hold.
6. While another call is active, receive a second call and switch between them.
   Confirm the panel follows the foreground incoming call and never shows the
   other party's caller number as the called number.
7. Check the incoming notification and full-screen call UI for the same caller
   and called-line distinction.
8. If a provider does not publish its number, confirm the UI explicitly reports
   that condition and still identifies the routed provider/account when known.

## Platform boundary

Android Telecom obtains receiving-line metadata from the carrier or VoIP
connection service. The automated tests verify selection, separation from
caller ID, fallback behavior, persistence through call-state changes, and UI
wiring. A physical device and live accounts are required to verify which number
each specific provider publishes.
