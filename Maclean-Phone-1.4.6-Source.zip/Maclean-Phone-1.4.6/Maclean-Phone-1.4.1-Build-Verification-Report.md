# Maclean Phone 1.4.1 Build Verification Report

Verification completed: 2026-08-27 11:25 UTC

## Result

The 1.4.1 release build completed successfully. The resulting APK is signed, aligned, universal, and internally identifies itself as the requested application and version. Source-level compatibility for an install over the matching signed 1.4.0 release is verified by application ID, signing certificate, increasing version code, and non-destructive database migration.

## Build configuration

| Property | Verified value |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version name | `1.4.1` |
| Version code | `12` |
| Previous source version code | `11` |
| Compile SDK | `36` |
| Minimum SDK | `26` |
| Target SDK | `36` |
| Java/Kotlin bytecode target | `17` |
| Android Gradle Plugin | `9.1.0` |
| Gradle | `9.4.0` |
| Kotlin | `2.3.10` |
| Build JDK | `21` |
| Release minification | Disabled, matching the project release configuration |

Command result:

```text
:app:testDebugUnitTest :app:lintRelease :app:assembleRelease
BUILD SUCCESSFUL
```

## APK verification

| Check | Result |
|---|---|
| APK filename | `Maclean-Phone-1.4.1-universal.apk` |
| APK size | 173,737,568 bytes |
| Package manifest | PASS — requested application ID, version name, and code |
| APK Signature Scheme v2 | PASS |
| Signers | 1 |
| Certificate subject | `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises` |
| Certificate SHA-256 | `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136` |
| APK SHA-256 | `441f24282af1e86a514527c617cb28a02a84f96710561839ef998cf4469352f8` |
| ZIP/APK 4-byte and 16-KiB alignment check | PASS |
| Architectures | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |

## Automated quality gates

| Gate | Result |
|---|---|
| Unit/Robolectric suites | 13 suites |
| Tests | 46 passed |
| Failures/errors/skips | 0 / 0 / 0 |
| Release lint errors | 0 |
| Release lint warnings | 59 |
| Release lint hints | 1 |
| Placeholder scan (`TODO`, `FIXME`, `Not implemented`, `Coming soon`) | No matches in main or test source |

The remaining lint findings are non-release-blocking modernization or packaging observations: KTX suggestions, unused resources, launcher artwork shape/monochrome suggestions, guarded inlined newer-API constants, dependency-update notices, and style hints. The high-priority indefinite wake-lock warning found during the audit was fixed and is absent from the final report.

## Data-upgrade verification

- Database schema advances from version 1 to version 2 through `onUpgrade`; it does not drop or recreate user tables.
- Migration adds favorite and read-only state, repairs duplicate identity links, creates identity indexes, and retains legacy contacts.
- Foreign keys and transactional cleanup prevent orphan CRM fields and memberships.
- Application ID and signing certificate are unchanged; version code increases from 11 to 12.

These checks establish Android update compatibility. An actual install-over was not executed because no Android device or emulator was connected in the build environment.

## Preserved call-function audit

Source wiring was reviewed for the existing dialer, call service, SIP/VoIP, caller ID and spam role, voicemail and forwarding settings, Google Voice redirection compatibility, appearance/accessibility preferences, call recording policy, and in-call endpoint routing. The speaker button retains short-press routing and a three-second hold route selector. Android 14+ uses CallEndpoint routing, while supported older versions retain the legacy CallAudioState path.

No physical carrier, SIP server, Google Voice account, SIM, Bluetooth headset, or live two-party call was available in this environment. Those hardware/service-dependent behaviors require the device acceptance pass below.

## Required device acceptance pass

Before broad deployment, install over a backed-up 1.4.0 device and verify:

1. Existing CRM data, settings, groups, photos, call history, and accounts remain present.
2. Place and receive a carrier call; short-press speaker and hold it for three seconds, then test phone, speaker, and each connected Bluetooth endpoint.
3. Place a Google Voice carrier call with Google Voice selected as the call-redirecting app and Maclean Phone selected as the phone app.
4. Place a SIP call and confirm media, mute, DTMF, and hang-up.
5. Record a lawful test call and verify the expected microphone/remote-side level on that handset and Android build.
6. Test local CRM with Contacts permission denied, then grant permission and test a writable phone account and, if the device exposes one, a writable SIM account.

The absence of a connected device is recorded as a test-environment limitation, not represented as a physical-device pass.
