# Maclean Phone 1.4.5 Release Notes

Release date: 2026-09-22

## Choose which contact number to call

- Calling a contact with more than one distinct phone field now opens a labeled destination picker.
- The picker is wired into CRM Contacts, Favorites, frequent contacts, and contact search.
- Mobile, home, work, custom, Russian, Spanish, Unicode, and emoji labels are preserved.
- Formatting-only duplicates are removed while genuinely different local and international numbers remain available.
- Recent-call redial and manually entered keypad calls continue to use the exact displayed number.

## Choose which number/account calls from

**Settings → Calling accounts** now provides:

- **Phone / system default** — uses Android's normal phone/SIM route and permits a configured call-redirection service to apply its policy.
- **Ask every time** — shows the outgoing account chooser for every call.
- A persistent choice for every enabled telephone-capable cellular or VoIP `PhoneAccount` Android exposes.

The per-call chooser includes the system route and all visible registered accounts. Each row shows the provider and calling-from address when the provider supplies one. Full provider component identity plus account ID is retained so similarly named accounts cannot collide. If a saved account is removed or disabled, Maclean Phone asks again instead of silently using a different provider.

The former 1.4.4 **Selected SIM** preference migrates to the matching registered account without clearing other app settings.

## Calling-from visibility

- Outgoing calls now have a separate **Calling from** panel while the existing callee/caller-ID display remains unchanged.
- The foreground call notification also shows `From … via …` when Android Telecom provides that metadata.
- If a provider withholds its public address, the app states that the number was not provided and still displays the available account/provider label.
- Added `READ_PHONE_NUMBERS` to improve account-address visibility. Denial does not prevent local CRM use and fails gracefully.

## Compatibility

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version name is `1.4.5`; version code is `16`.
- The release is signed with the existing Maclean Phone identity and is intended to install directly over the correctly signed 1.4.4 release without clearing data.
- No destructive database migration or CRM schema change was introduced.
- Existing calling, group calls, add/merge call controls, speaker/Bluetooth routing, caller ID, incoming called-number display, Google Voice redirection compatibility, SIP/VoIP IVR, voicemail, forwarding, call recording, CRM, accessibility, appearance, and AGPLv3 license features remain present.

## Provider behavior

Google Voice is a direct Maclean Phone account choice only when it registers an enabled telephone-capable Android `PhoneAccount`. When Google Voice is configured as Android's call-redirection app, select **Phone / system default** so Google Voice can apply its own account or per-call policy.

The built-in Maclean SIP feature remains an incoming automated IVR/directory and is not presented as an ordinary outbound handset identity. Other VoIP apps appear when they register a compatible Android calling account. A carrier or VoIP provider ultimately controls the caller ID presented to the recipient.

## Verification summary

- 68 unit/workflow tests passed with no failures, errors, or skips.
- Release lint passed with zero errors, 58 non-blocking warnings, and one informational hint.
- Release assembly, signature verification, zip alignment, package/version inspection, permission inspection, and ABI inspection passed.
- No physical Android device was attached; provider- and device-specific acceptance cases remain listed in the test report.

