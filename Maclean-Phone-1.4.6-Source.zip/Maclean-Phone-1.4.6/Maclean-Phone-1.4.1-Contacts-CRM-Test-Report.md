# Maclean Phone 1.4.1 Contacts/CRM Test Report

Test run completed: 2026-08-27

## Result

All 46 automated project tests passed with no failures, errors, or skips. The Contacts/CRM corrective suite exercises persistence, migration, groups, multilingual VCF round-trip, secure sharing, copying, bulk deletion, duplicate detection, and save-before-delete merging against the real CRM repository/database code under Robolectric Android SDK 35.

## Requested workflow coverage

| Requested workflow | Automated evidence | Result |
|---|---|---|
| Create → edit → save → restart → delete | Creates a Unicode CRM contact with fields/groups, edits it, favorites it, closes/reopens the database, verifies values, deletes it, and verifies field/membership cascade | PASS |
| Select multiple → copy → share → export → bulk delete | Creates two multilingual contacts, copies both, generates a secure `content://` VCF, reads it through ContentResolver, imports it, bulk-deletes originals, and checks counts/failures after each committed operation | PASS |
| Create group → rename → reorder → add/remove members → restart → delete group without deleting contacts | Database workflow covers create, reorder, bulk add/remove, restart persistence, and safe delete; rename uses the same transactional `saveGroup` path and the UI invokes it with the stable group ID | PASS (automated repository/database plus wiring audit) |
| Create duplicates → merge → verify all unique data survives | Candidate tests verify normalized phone/email and exact-name rules; merge tests preserve unique phone/email/company/notes/groups/photo/favorite, save target first, then remove sources | PASS |
| Export all contacts → import exported VCF → compare data | Full supported-field writer/parser round-trip plus repository share/import round-trip verifies names, labels, international codes, Unicode, emoji, groups, photos, and Maclean extension fields | PASS |

## Contacts/CRM-specific test cases

### Database, migration, permissions, and integrity

- Version 1 migrates to version 2 without data loss and repairs duplicate Android identity links.
- Create/edit/restart/favorite/group/delete state persists and cascades.
- Bulk group membership add/remove and group reorder persist after reopen.
- Deleting a group leaves its contacts intact.
- Local CRM storage remains available when Android READ/WRITE_CONTACTS permissions are denied.
- Android RawContact account ContentValues always include both account keys, including null local-account values; this guards the reported OEM `ContentValues.keySet()` crash.

### VCF import/export

- English, Spanish, Russian, emoji, international numbers, and groups import correctly.
- Multiple cards and arbitrary Maclean extension fields import correctly.
- Quoted-printable values and folded lines decode correctly.
- Names, middle/nickname, phones and country codes, email, address, fax, website, company, birthday, notes, CRM attributes, favorite, groups, photo bytes, Unicode, emoji, and custom labels survive export/import.
- Folded lines stay within 75 octets and do not split Unicode.
- Base64 photo padding does not swallow `END:VCARD` or the next card.

### Duplicate and merge behavior

- Normalized equal phone numbers and email addresses identify candidates.
- Similar names alone do not identify duplicates.
- Merge preserves all unique values, groups, photo choice, notes, and favorite state.
- Repository workflow verifies the merged target exists before any source is deleted and reports source-delete failures.

### Bulk copy, secure share, and delete

- Two selected contacts copy to app storage and create distinct stable records.
- Shared VCF URI uses the `content` scheme and the private application FileProvider authority.
- Shared VCF can be reopened by ContentResolver and parsed as readable contacts.
- Re-import completes with per-card success/failure totals.
- Bulk delete removes the requested stable records and refreshes the repository snapshot.

## UI/state wiring audit

The Contacts screen and ViewModel were traced together for every exposed operation:

- Long press enters stable-ID selection; tap toggles; Select All uses the current filtered result; selection count is derived from selected IDs.
- Individual detail actions connect to repository operations for edit/copy/delete/export/share/favorite/groups/merge and platform intents for call/message/email.
- Bulk actions connect to delete/copy/storage/export/share/groups/merge repository functions.
- Save As supports one, selected, group, filtered, and all-contact scopes.
- Group create/rename/reorder/member add/member remove/export/share/delete actions use group IDs; deleting a group never invokes contact deletion.
- Duplicate candidates require normalized phone/email or exact normalized name evidence; merging remains user-confirmed.
- Repository work runs on IO/default dispatchers and completion messages are emitted after results return, including partial-failure counts.
- Local CRM launch no longer depends on Android Contacts permission; Android/SIM actions expose permission/read-only failures.

The source scan found no `TODO`, `FIXME`, `Not implemented`, or `Coming soon` placeholders in main or test source.

## Test-environment boundary

No Android device or emulator was connected, so Compose touch automation and OEM Contacts/SIM provider behavior could not be executed. The automated tests verify database/repository behavior and the UI/state wiring audit verifies that exposed controls call those paths, but the following remain required on a real device:

- Touch and long-press behavior at the device's display/font scale.
- Android system Save As and share-sheet interaction with third-party receiving apps.
- Provider-specific writable/read-only phone and SIM behavior.
- Photo picker behavior and very large real-world VCF imports on the target handset.
- Process-kill/reboot persistence under the target OEM firmware.

Back up contacts, install over 1.4.0, and run those device checks before relying on SIM writes or deleting the only copy of production contact data.
