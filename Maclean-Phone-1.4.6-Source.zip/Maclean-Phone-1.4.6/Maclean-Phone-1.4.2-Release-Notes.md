# Maclean Phone 1.4.2 Release Notes

Release date: 2026-08-28

## Overview

Maclean Phone 1.4.2 is a licensing and disclosure update to the working 1.4.1 release. It adds the complete GNU Affero General Public License version 3 text inside the application while preserving the existing package identity, signing identity, user data, settings, calling features, and Contacts/CRM behavior.

## Changes

- Added **Settings → Legal → License**.
- Added a dedicated, scrollable license screen containing the complete GNU AGPLv3 text supplied for this release.
- Made the license available without a network connection.
- Made the license text selectable for accessibility and copying.
- Added clear attribution that Maclean Phone is distributed under GNU AGPLv3 and that bundled third-party components retain their own applicable terms.
- Added the complete AGPLv3 text to the source archive as `LICENSE-AGPL-3.0.txt`.
- Retained the existing Apache 2.0, GPLv3, and third-party notice files.
- Updated the application version to `1.4.2` and version code to `13`.
- Updated Maclean Phone VCF metadata to identify version 1.4.2.

## Update compatibility

- Application ID remains `com.macleanofduartenterprises.phone`.
- The release is signed by the existing Maclean Phone update certificate.
- Version code advances from 12 to 13.
- No database schema or destructive migration change was introduced.

The APK is therefore configured to install directly over the matching signed 1.4.1 release without removing application data.

## Preserved functionality

No calling, SIP/VoIP, caller ID, spam handling, voicemail, forwarding, Google Voice compatibility, audio routing, accessibility, appearance, recording, Contacts/CRM, group, import/export, or persistence behavior was intentionally changed in this licensing update.

