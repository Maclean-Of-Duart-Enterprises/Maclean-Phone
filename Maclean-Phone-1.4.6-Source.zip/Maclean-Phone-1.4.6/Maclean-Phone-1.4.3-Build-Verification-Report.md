# Maclean Phone 1.4.3 Build Verification Report

Verification date: 2026-09-15

## Release identity

| Check | Result |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version name | `1.4.3` |
| Version code | `14` |
| Minimum SDK | `26` |
| Target / compile SDK | `36` / `36` |
| Architectures | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |
| APK size | 173,782,174 bytes |
| Signing | APK Signature Scheme v2 verified |
| Signer | `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises` |
| Signer certificate SHA-256 | `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136` |
| Alignment | `zipalign -c -P 16 -v 4` passed |

The package name, increased version code, and existing signer identity satisfy
the Android requirements for installing this APK over an existing correctly
signed Maclean Phone 1.4.1 or 1.4.2 installation without clearing app data.

## Toolchain and automated checks

| Check | Result |
|---|---|
| JDK | Temurin 21.0.12.1 |
| Gradle | 9.4.0 |
| Android SDK / Build Tools | 36 / 36.0.0 |
| `testDebugUnitTest` | Passed: 54 tests, 0 failures, 0 errors, 0 skipped |
| `lintRelease` | Passed: 0 errors, 56 warnings, 1 hint |
| `assembleRelease` | Passed |
| `apksigner verify --verbose --print-certs` | Passed |
| `zipalign` verification | Passed |

The non-blocking lint findings are retained in the generated lint report and
primarily concern compatibility/deprecation guidance in existing code. The one
blocking finding encountered during this release—calling-account access without
an explicit runtime permission check—was corrected before the successful final
lint run.

## Upgrade and data integrity review

- The application ID is unchanged.
- The CRM database remains at schema version 2.
- No database table, upgrade path, or destructive migration was added or
  changed in 1.4.3.
- The AGPLv3 license asset and Settings → Legal → License screen remain present.
- The release was assembled with the supplied private release keystore through
  environment-provided signing values; credentials are not embedded in this
  report.

## Device-test boundary

No physical Android device or active carrier/Google Voice account was connected
to this build environment. Therefore installation, account-specific second-call
behavior, carrier conference audio, emergency-call restrictions, and modem-side
participant management require final acceptance testing on the intended phone
and network. Automated policy tests and Android release-tool verification passed.

