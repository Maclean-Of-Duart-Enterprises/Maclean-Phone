pluginManagement {
    repositories {
        System.getenv("MACLEAN_OFFLINE_MAVEN_REPO")
            ?.takeIf(String::isNotBlank)
            ?.let { localRepository ->
                maven { url = uri(localRepository) }
            }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        System.getenv("MACLEAN_OFFLINE_MAVEN_REPO")
            ?.takeIf(String::isNotBlank)
            ?.let { localRepository ->
                maven { url = uri(localRepository) }
            }
        google()
        mavenCentral()
        maven {
            url = uri("https://download.linphone.org/releases/android/maven_repository")
        }
    }
}

rootProject.name = "MacleanPhone"
include(":app")
