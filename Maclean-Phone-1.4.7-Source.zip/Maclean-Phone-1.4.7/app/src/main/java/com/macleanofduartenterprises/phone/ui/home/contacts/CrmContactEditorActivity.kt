package com.macleanofduartenterprises.phone.ui.home.contacts

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.macleanofduartenterprises.phone.crm.CrmContact
import com.macleanofduartenterprises.phone.crm.CrmCustomField
import com.macleanofduartenterprises.phone.crm.CrmFieldType
import com.macleanofduartenterprises.phone.ui.theme.MacleanPhoneTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Explicit in-app destination for creating a CRM contact from Recents or search.
 *
 * Keeping this activity non-exported prevents other applications from injecting contact drafts,
 * and using an explicit component prevents Android from displaying an app chooser.
 */
@AndroidEntryPoint
class CrmContactEditorActivity : ComponentActivity() {
    private val viewModel: ContactsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initialContact = newCrmContactForPhone(intent.getStringExtra(EXTRA_PHONE).orEmpty())

        setContent {
            MacleanPhoneTheme {
                val state by viewModel.state.collectAsStateWithLifecycle()
                var editorContact by remember { mutableStateOf(initialContact) }
                var photoDraft by remember { mutableStateOf<CrmContact?>(null) }
                val photoLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument(),
                ) { uri ->
                    if (uri != null) {
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION,
                            )
                        }
                        editorContact = (photoDraft ?: editorContact).copy(photoUri = uri.toString())
                    }
                    photoDraft = null
                }

                LaunchedEffect(state.error) {
                    val error = state.error ?: return@LaunchedEffect
                    Toast.makeText(this@CrmContactEditorActivity, error, Toast.LENGTH_LONG).show()
                    viewModel.clearNotice()
                }

                CrmContactEditor(
                    original = editorContact,
                    groups = state.snapshot.groups,
                    storageOptions = state.snapshot.storageOptions,
                    working = state.working,
                    onPickPhoto = { draft ->
                        photoDraft = draft
                        photoLauncher.launch(arrayOf("image/*"))
                    },
                    onDismiss = { finish() },
                    onSave = { draft ->
                        viewModel.saveContact(draft) {
                            setResult(RESULT_OK)
                            finish()
                        }
                    },
                )
            }
        }
    }

    companion object {
        internal const val EXTRA_PHONE =
            "com.macleanofduartenterprises.phone.extra.CONTACT_PHONE"

        fun createIntent(context: Context, phone: String): Intent =
            Intent(context, CrmContactEditorActivity::class.java)
                .putExtra(EXTRA_PHONE, phone)
    }
}

internal fun newCrmContactForPhone(phone: String): CrmContact {
    val trimmedPhone = phone.trim()
    return CrmContact(
        customFields = listOf(
            CrmCustomField(
                type = CrmFieldType.PHONE,
                label = "Mobile",
                value = trimmedPhone,
                position = 0,
            ),
            CrmCustomField(
                type = CrmFieldType.EMAIL,
                label = "Email",
                position = 1,
            ),
        ),
    )
}
