package com.macleanofduartenterprises.phone.ui.extensions

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import com.macleanofduartenterprises.phone.ui.home.contacts.CrmContactEditorActivity

fun Context.openContactDetailScreen(contactId: Long) {
    val intent = Intent(Intent.ACTION_VIEW)
    val contactUri = ContactsContract.Contacts.CONTENT_URI.buildUpon()
        .appendPath(contactId.toString())
        .build()
    intent.data = contactUri
    startActivity(intent)
}

fun Context.openContactAddScreen(phone: String) {
    val intent = CrmContactEditorActivity.createIntent(this, phone).apply {
        if (this@openContactAddScreen !is Activity) {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    startActivity(intent)
}
