package com.macleanofduartenterprises.phone.ui.home.contacts

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.macleanofduartenterprises.phone.crm.CrmFieldType
import com.macleanofduartenterprises.phone.ui.extensions.openContactAddScreen
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CrmContactEditorActivityTest {
    private val context: Context = RuntimeEnvironment.getApplication()

    @Test
    fun `add contact intent explicitly targets the private Maclean CRM editor`() {
        val phone = "+1 (717) 537-1951"

        val intent = CrmContactEditorActivity.createIntent(context, phone)

        assertEquals(
            ComponentName(context, CrmContactEditorActivity::class.java),
            intent.component,
        )
        assertEquals(phone, intent.getStringExtra(CrmContactEditorActivity.EXTRA_PHONE))
        assertNull(intent.action)
        assertNull(intent.type)
        assertTrue(intent.action != Intent.ACTION_INSERT)
    }

    @Test
    fun `shared add contact helper starts only the Maclean CRM editor`() {
        val application = RuntimeEnvironment.getApplication()

        application.openContactAddScreen("+17175371951")
        val started = shadowOf(application).nextStartedActivity

        assertEquals(
            ComponentName(application, CrmContactEditorActivity::class.java),
            started.component,
        )
        assertEquals("+17175371951", started.getStringExtra(CrmContactEditorActivity.EXTRA_PHONE))
        assertTrue(started.flags and Intent.FLAG_ACTIVITY_NEW_TASK != 0)
    }

    @Test
    fun `recent number is prefilled without changing its international formatting`() {
        val phone = "+7 (777) 097-24-19"

        val draft = newCrmContactForPhone("  $phone  ")
        val phoneField = draft.customFields.single { it.type == CrmFieldType.PHONE }

        assertEquals(phone, phoneField.value)
        assertEquals(phone, draft.primaryPhone)
        assertEquals(1, draft.customFields.count { it.type == CrmFieldType.EMAIL })
    }
}
