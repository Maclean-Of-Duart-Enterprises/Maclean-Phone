# Maclean Phone

Maclean Phone is an AGPLv3 Android dialer and CRM from Maclean of Duart Enterprises.

Version 1.4.7 corrects **Add Contact** from Recents and search so it opens Maclean Phone's own CRM editor directly, with the selected phone number prefilled and no Android app chooser. The application ID remains `com.macleanofduartenterprises.phone`.

See `Maclean-Phone-1.4.7-Release-Notes.md` and the verification reports included with the release for details and device-test boundaries.
