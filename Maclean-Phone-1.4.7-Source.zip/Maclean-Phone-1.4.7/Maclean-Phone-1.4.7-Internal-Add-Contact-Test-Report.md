# Maclean Phone 1.4.7 Internal Add Contact Test Report

Test date: 2026-10-14

## Corrected workflow

The former implementation sent an implicit `Intent.ACTION_INSERT` request for an Android contact. Because Android was free to resolve that request to any matching application, the device displayed **Complete action using** and offered unrelated apps.

Version 1.4.7 sends an explicit internal intent to the non-exported `CrmContactEditorActivity`. That activity displays the same Maclean CRM editor used by the Contacts page and prefills the selected recent number.

## Automated results

| Check | Result | Evidence |
|---|---|---|
| Explicit destination | Pass | The generated intent component is exactly Maclean Phone's `CrmContactEditorActivity`. |
| No generic insert request | Pass | The intent has no `ACTION_INSERT`, MIME type, or Android Contacts insert contract. |
| Shared helper behavior | Pass | Calling the helper used by Recents starts only the explicit Maclean component. |
| Non-Activity context safety | Pass | The shared helper adds `FLAG_ACTIVITY_NEW_TASK` when required. |
| Phone-number prefill | Pass | `+7 (777) 097-24-19` round-trips into the primary phone field without losing its prefix or formatting. |
| Full editor integration | Pass | Debug and release Kotlin, Compose, Hilt, manifest, and Java compilation completed. |
| Save error behavior | Pass by code path | The activity finishes only in the repository success callback; failures display an error and keep the draft open. |
| Draft photo behavior | Pass by code path | Current unsaved fields are captured before opening the picker and restored with the chosen URI. |
| Existing regression suite | Pass | 76 total tests; 0 failures, 0 errors, 0 skipped. |

The shared helper has three production callers, all audited to use the corrected route:

1. Call-history detail / Recents **Add Contact**.
2. Add an unknown number from search results.
3. Add the number entered in the expanded dialer/search panel.

## Physical-device acceptance checklist

These steps require an Android phone and were not executed in the build environment:

1. Install 1.4.7 over the currently installed, correctly signed Maclean Phone release without uninstalling it.
2. Open **Recents**, open an unknown caller's history, and tap the add-contact icon.
3. Confirm Maclean Phone's **Add CRM contact** editor opens immediately and no **Complete action using** chooser appears.
4. Confirm the recent number is already in the **Mobile** phone field.
5. Enter English, Spanish, Russian, and emoji text; choose a photo; confirm the entered fields remain unchanged after returning from the picker.
6. Save, open **Contacts**, search for the new contact, restart the app, and verify the contact and photo persist.
7. Repeat with Android Contacts permission denied while leaving storage set to **Maclean Phone app**.
8. Cancel a second draft and confirm no contact is created.

## Result

Automated and packaged-code verification passed. Physical touch/UI acceptance remains the final device-side check because no device or emulator was connected during this build.
