# Maclean Phone 1.4.7 Release Notes

Release date: 2026-10-14

## Corrected Add Contact behavior

- **Add Contact** from a recent caller or call-history detail now opens Maclean Phone's own CRM contact editor directly.
- The selected phone number is prefilled exactly as displayed, including international prefixes and formatting.
- Removed the generic Android `ACTION_INSERT` contact request that caused the **Complete action using** chooser and could route the operation to unrelated applications.
- The destination is an explicit, non-exported Maclean Phone activity, so Android cannot substitute another application for this action.
- The same correction applies to every existing Maclean Phone entry point that uses the shared Add Contact action: call history, contact search results, and a number entered in the dialer/search panel.
- The full Maclean CRM editor remains available in this flow, including names, unlimited custom fields, storage choice, groups, CRM data, notes, and contact photo selection.
- Choosing a photo now preserves the unsaved contact draft instead of reverting fields entered before the picker opened.
- Saving waits for the CRM repository operation to succeed. A failed save leaves the editor open and displays the error.

## Compatibility and data preservation

- Application ID remains `com.macleanofduartenterprises.phone`.
- Version name is `1.4.7`; version code is `18`.
- The release is signed with the existing Maclean Phone signing identity and is intended to install directly over correctly signed earlier releases, including 1.4.1 through 1.4.6, without uninstalling or clearing data.
- No CRM database schema, contact record, group, preference, or calling configuration is removed or rewritten by this update.
- Local Maclean CRM contact creation remains available without Android Contacts permission. Android Phone/SIM storage choices continue to report permission or write limitations through the existing CRM storage layer.
- Existing calling, SIP/VoIP, caller ID, called-number display, Google Voice compatibility, group calls, speaker/Bluetooth routing, voicemail, forwarding, accessibility, appearance, Favorites, navigation, and AGPLv3 license functionality are retained.

## Verification summary

- 76 unit and Robolectric tests passed with no failures, errors, or skips.
- Three focused tests verify explicit Maclean editor routing, actual shared-helper behavior, new-task handling outside an Activity, and exact international-number prefilling.
- Release lint passed with zero errors, 68 non-blocking warnings, and one informational hint.
- Signed release assembly, package/version inspection, manifest inspection, signature verification, zip alignment, permission inspection, and universal ABI inspection passed.
- No Android phone or emulator was attached to the build environment. The included focused test report separates completed automated verification from the short physical-device acceptance checklist.
