# Maclean Phone 1.4.7 Build Verification Report

Build date: 2026-10-14

## Release identity

| Property | Verified value |
|---|---|
| Application ID | `com.macleanofduartenterprises.phone` |
| Version name | `1.4.7` |
| Version code | `18` |
| Minimum SDK | `26` |
| Target / compile SDK | `36` / `36` |
| APK type | Universal |
| Packaged ABIs | `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64` |
| APK size | 173,798,662 bytes |
| APK SHA-256 | `57fb04461849930a3dc1037f4669eaf9ffc51d88876a0c751035ba09be59bdc7` |

## Build environment and tasks

- Eclipse Temurin JDK 21.0.12.1
- Gradle 9.4.0
- Android SDK Platform 36 / Build Tools 36.0.0
- `testDebugUnitTest`: passed — 76 tests, 0 failures, 0 errors, 0 skipped
- `lintRelease`: passed — 0 errors, 68 warnings, 1 hint
- `assembleRelease`: passed

The lint findings are non-blocking inherited API/deprecation, resource, icon, KTX-style, and dependency-modernization guidance. No lint baseline, error suppression, or dependency downgrade was introduced to obtain a passing result.

## APK verification

- `aapt dump badging` confirms package `com.macleanofduartenterprises.phone`, version code `18`, version name `1.4.7`, minimum SDK 26, and target SDK 36.
- Packaged manifest inspection confirms `CrmContactEditorActivity` is registered with `android:exported="false"` and uses the Maclean Phone theme.
- `apksigner verify --verbose --print-certs` passes with one APK Signature Scheme v2 signer.
- Signer subject: `CN=Maclean Phone, OU=Mobile Applications, O=Maclean of Duart Enterprises`
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- `zipalign -c -P 16 -v 4` reports verification successful.
- Universal native libraries are present for `arm64-v8a`, `armeabi-v7a`, `x86`, and `x86_64`.

The unchanged application ID, increased version code, and unchanged signer satisfy Android's package-level requirements for an in-place update over correctly signed previous Maclean Phone releases. Android will still reject an in-place update if the installed APK was signed with a different certificate.

## Corrective implementation review

- Removed the implicit Android Contacts insertion intent from the shared Add Contact helper.
- All three current callers resolve through an explicit component targeting Maclean Phone's private CRM editor.
- The recent/dialed number is passed only as an internal intent extra and becomes the draft's primary phone field.
- The editor delegates persistence to the existing transactional CRM repository and closes only after a successful save callback.
- Local CRM behavior does not depend on Android Contacts permission.
- Photo selection carries forward the current draft fields before applying the returned photo URI.
- No database version or schema changed, and no destructive migration or data-clearing operation was added.

## Verification boundary

Static review, JVM/Robolectric tests, Compose/Kotlin/Hilt compilation, release lint, signed packaging, manifest metadata, certificate, ABI, permission, and alignment checks were completed. No Android phone or emulator was attached, so installation over a populated device and touch-level chooser behavior are not falsely marked as physically tested. The focused device checklist is in the Internal Add Contact Test Report.
